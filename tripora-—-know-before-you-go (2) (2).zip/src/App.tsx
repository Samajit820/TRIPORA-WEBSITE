import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SearchableHeroTitle } from './components/SearchableHeroTitle';
import { EarthExplorer } from './components/EarthExplorer';
import { CountriesSection } from './components/CountriesSection';
import { HistoricalTimeline } from './components/HistoricalTimeline';
import { CountryDetailModal } from './components/CountryDetailModal';
import { CitiesSection } from './components/CitiesSection';
import { CityDetailModal } from './components/CityDetailModal';
import { DestinationsSection } from './components/DestinationsSection';
import { LandmarksSection } from './components/LandmarksSection';
import { LandmarkDetailModal } from './components/LandmarkDetailModal';
import { NatureWildlifeSection } from './components/NatureWildlifeSection';
import { FoodCultureSection } from './components/FoodCultureSection';
import { ExperiencesSection } from './components/ExperiencesSection';
import { TravelToolkit } from './components/TravelToolkit';
import { ArticlesSection } from './components/ArticlesSection';
import { NewsletterSubscribe } from './components/NewsletterSubscribe';
import { Footer } from './components/Footer';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { SavedBucketListModal } from './components/SavedBucketListModal';
import { SupportedLanguage, ContinentCode } from './types';

export default function App() {
  const [currentLang, setCurrentLang] = useState<SupportedLanguage>('en');
  const [selectedContinent, setSelectedContinent] = useState<ContinentCode | 'all'>('all');
  const [activeSection, setActiveSection] = useState<string>('earth');

  // Modal States
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchInitialQuery, setSearchInitialQuery] = useState('');
  const [isBucketListOpen, setIsBucketListOpen] = useState(false);
  const [selectedCountryId, setSelectedCountryId] = useState<string | null>(null);
  const [selectedCityId, setSelectedCityId] = useState<string | null>(null);
  const [selectedLandmarkId, setSelectedLandmarkId] = useState<string | null>(null);

  // Saved Bucket List items state
  const [savedCountries, setSavedCountries] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tripora_saved_countries');
      return stored ? JSON.parse(stored) : ['Japan', 'Iceland', 'Italy'];
    } catch {
      return ['Japan', 'Iceland', 'Italy'];
    }
  });

  const [savedCities, setSavedCities] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tripora_saved_cities');
      return stored ? JSON.parse(stored) : ['Tokyo', 'Paris'];
    } catch {
      return ['Tokyo', 'Paris'];
    }
  });

  const [savedLandmarks, setSavedLandmarks] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tripora_saved_landmarks');
      return stored ? JSON.parse(stored) : ['Taj Mahal', 'Machu Picchu'];
    } catch {
      return ['Taj Mahal', 'Machu Picchu'];
    }
  });

  const [savedDestinations, setSavedDestinations] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tripora_saved_destinations');
      return stored ? JSON.parse(stored) : ['Santorini Caldera'];
    } catch {
      return ['Santorini Caldera'];
    }
  });

  const [savedExperiences, setSavedExperiences] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('tripora_saved_experiences');
      return stored ? JSON.parse(stored) : ['Northern Lights Hunting'];
    } catch {
      return ['Northern Lights Hunting'];
    }
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('tripora_saved_countries', JSON.stringify(savedCountries));
  }, [savedCountries]);

  useEffect(() => {
    localStorage.setItem('tripora_saved_cities', JSON.stringify(savedCities));
  }, [savedCities]);

  useEffect(() => {
    localStorage.setItem('tripora_saved_landmarks', JSON.stringify(savedLandmarks));
  }, [savedLandmarks]);

  useEffect(() => {
    localStorage.setItem('tripora_saved_destinations', JSON.stringify(savedDestinations));
  }, [savedDestinations]);

  useEffect(() => {
    localStorage.setItem('tripora_saved_experiences', JSON.stringify(savedExperiences));
  }, [savedExperiences]);

  // Section scroll spy to update active navigation tab in Header
  useEffect(() => {
    const sectionIds = [
      'earth',
      'countries',
      'history',
      'cities',
      'destinations',
      'landmarks',
      'nature-wildlife',
      'food-culture',
      'experiences',
      'planners',
      'articles'
    ];

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 180;
      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const sectionEl = document.getElementById(sectionIds[i]);
        if (sectionEl) {
          const top = sectionEl.offsetTop;
          if (scrollPosition >= top) {
            setActiveSection(sectionIds[i]);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Toggle Handlers
  const toggleSaveCountry = (countryName: string) => {
    setSavedCountries((prev) =>
      prev.includes(countryName) ? prev.filter((c) => c !== countryName) : [...prev, countryName]
    );
  };

  const toggleSaveCity = (cityName: string) => {
    setSavedCities((prev) =>
      prev.includes(cityName) ? prev.filter((c) => c !== cityName) : [...prev, cityName]
    );
  };

  const toggleSaveLandmark = (landmarkName: string) => {
    setSavedLandmarks((prev) =>
      prev.includes(landmarkName) ? prev.filter((l) => l !== landmarkName) : [...prev, landmarkName]
    );
  };

  const toggleSaveDestination = (destName: string) => {
    setSavedDestinations((prev) =>
      prev.includes(destName) ? prev.filter((d) => d !== destName) : [...prev, destName]
    );
  };

  const toggleSaveExperience = (expTitle: string) => {
    setSavedExperiences((prev) =>
      prev.includes(expTitle) ? prev.filter((e) => e !== expTitle) : [...prev, expTitle]
    );
  };

  const handleRemoveBucketListItem = (itemType: string, name: string) => {
    if (itemType === 'country') toggleSaveCountry(name);
    else if (itemType === 'city') toggleSaveCity(name);
    else if (itemType === 'landmark') toggleSaveLandmark(name);
    else if (itemType === 'destination') toggleSaveDestination(name);
    else if (itemType === 'experience') toggleSaveExperience(name);
  };

  const handleClearAllBucketList = () => {
    setSavedCountries([]);
    setSavedCities([]);
    setSavedLandmarks([]);
    setSavedDestinations([]);
    setSavedExperiences([]);
  };

  const totalSavedCount =
    savedCountries.length +
    savedCities.length +
    savedLandmarks.length +
    savedDestinations.length +
    savedExperiences.length;

  return (
    <div className="min-h-screen bg-[#fcfbf7] text-[#1a1a1a] flex flex-col font-sans selection:bg-[#1a1a1a] selection:text-white">
      {/* Header */}
      <Header
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
        onOpenSearch={() => {
          setSearchInitialQuery('');
          setIsSearchOpen(true);
        }}
        onOpenBucketList={() => setIsBucketListOpen(true)}
        savedCount={totalSavedCount}
        activeSection={activeSection}
      />

      {/* Hero Header with Searchable Title and Logo */}
      <SearchableHeroTitle
        onOpenSearch={(query) => {
          setSearchInitialQuery(query || '');
          setIsSearchOpen(true);
        }}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Explore Earth Section */}
        <section id="earth">
          <EarthExplorer
            onSelectContinent={(continentId) => {
              setSelectedContinent(continentId);
              const element = document.getElementById('countries');
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        </section>

        {/* 2. Countries Section */}
        <section id="countries">
          <CountriesSection
            selectedContinent={selectedContinent}
            onSelectContinent={setSelectedContinent}
            onSelectCountry={(countryId) => setSelectedCountryId(countryId)}
            savedCountries={savedCountries}
            onToggleSaveCountry={toggleSaveCountry}
          />
        </section>

        {/* 3. Historical Timeline Atlas (Interactive D3 Chronology) */}
        <section id="history">
          <HistoricalTimeline
            initialCountryId={selectedCountryId || 'india'}
            onSelectCountryDetails={(countryId) => setSelectedCountryId(countryId)}
          />
        </section>

        {/* 4. Cities Section */}
        <section id="cities">
          <CitiesSection
            onSelectCity={(cityId) => setSelectedCityId(cityId)}
            savedCities={savedCities}
            onToggleSaveCity={toggleSaveCity}
          />
        </section>

        {/* 4. Destinations & Hidden Gems Section */}
        <section id="destinations">
          <DestinationsSection
            savedItems={savedDestinations}
            onToggleSave={toggleSaveDestination}
          />
        </section>

        {/* 5. Landmarks Section */}
        <section id="landmarks">
          <LandmarksSection
            onSelectLandmark={(landmarkId) => setSelectedLandmarkId(landmarkId)}
            savedLandmarks={savedLandmarks}
            onToggleSaveLandmark={toggleSaveLandmark}
          />
        </section>

        {/* 6. Nature & Wildlife Section */}
        <section id="nature-wildlife">
          <NatureWildlifeSection />
        </section>

        {/* 7. Food & Culture Section */}
        <section id="food-culture">
          <FoodCultureSection />
        </section>

        {/* 8. Experiences Section */}
        <section id="experiences">
          <ExperiencesSection
            savedItems={savedExperiences}
            onToggleSave={toggleSaveExperience}
          />
        </section>

        {/* 9. Travel Toolkit & Planners */}
        <section id="planners">
          <TravelToolkit />
        </section>

        {/* 10. Articles & Travel Guides */}
        <section id="articles">
          <ArticlesSection />
        </section>

        {/* 11. Newsletter Subscribe */}
        <NewsletterSubscribe />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals & Drawers */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        initialQuery={searchInitialQuery}
        onClose={() => {
          setIsSearchOpen(false);
          setSearchInitialQuery('');
        }}
        onSelectCountry={(id) => {
          setSelectedCountryId(id);
          setIsSearchOpen(false);
        }}
        onSelectCity={(id) => {
          setSelectedCityId(id);
          setIsSearchOpen(false);
        }}
        onSelectLandmark={(id) => {
          setSelectedLandmarkId(id);
          setIsSearchOpen(false);
        }}
        onSelectArticle={() => {
          setIsSearchOpen(false);
          const el = document.getElementById('articles');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        currentLang={currentLang}
      />

      <SavedBucketListModal
        isOpen={isBucketListOpen}
        onClose={() => setIsBucketListOpen(false)}
        savedCountries={savedCountries}
        savedCities={savedCities}
        savedLandmarks={savedLandmarks}
        savedDestinations={savedDestinations}
        savedExperiences={savedExperiences}
        onRemoveItem={handleRemoveBucketListItem}
        onClearAll={handleClearAllBucketList}
      />

      {/* Country Detail Modal */}
      {selectedCountryId && (
        <CountryDetailModal
          countryId={selectedCountryId}
          onClose={() => setSelectedCountryId(null)}
          onToggleSave={toggleSaveCountry}
          isSaved={savedCountries.includes(selectedCountryId)}
          onSelectCity={(cityId) => {
            setSelectedCountryId(null);
            setSelectedCityId(cityId);
          }}
          onSelectLandmark={(landmarkId) => {
            setSelectedCountryId(null);
            setSelectedLandmarkId(landmarkId);
          }}
        />
      )}

      {/* City Detail Modal */}
      {selectedCityId && (
        <CityDetailModal
          cityId={selectedCityId}
          onClose={() => setSelectedCityId(null)}
          onToggleSave={toggleSaveCity}
          isSaved={savedCities.includes(selectedCityId)}
        />
      )}

      {/* Landmark Detail Modal */}
      {selectedLandmarkId && (
        <LandmarkDetailModal
          landmarkId={selectedLandmarkId}
          onClose={() => setSelectedLandmarkId(null)}
          onToggleSave={toggleSaveLandmark}
          isSaved={savedLandmarks.includes(selectedLandmarkId)}
        />
      )}
    </div>
  );
}
