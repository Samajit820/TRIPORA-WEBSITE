export type ContinentCode = 'asia' | 'europe' | 'africa' | 'north-america' | 'south-america' | 'oceania' | 'antarctica';

export type HistoricalEra = 'Ancient' | 'Classical' | 'Medieval' | 'Early Modern' | 'Modern' | 'Contemporary';

export type HistoricalCategory = 'Politics & Empires' | 'Culture & Arts' | 'Science & Innovation' | 'Conflict & Peace' | 'Architecture & Wonders' | 'Milestone';

export interface HistoricalEvent {
  id: string;
  year: number; // e.g. -2500 for 2500 BCE, 1947 for 1947 CE
  yearDisplay: string; // e.g. "c. 2500 BCE", "1947 CE"
  era: HistoricalEra;
  title: string;
  category: HistoricalCategory;
  significance: 'Turning Point' | 'Cultural Zenith' | 'Monumental' | 'Key Milestone';
  summary: string;
  detailedDescription: string;
  keyFigures?: string[];
  historicalImpact: string;
  image?: string;
  quoteOrExcerpt?: string;
  location?: string;
}

export interface CountryHistoricalProfile {
  countryId: string;
  countryName: string;
  flag: string;
  region: string;
  historicalSpan: string;
  foundationalQuote: string;
  keyCivilizations: string[];
  majorEras: {
    era: HistoricalEra;
    timeframe: string;
    description: string;
    color: string;
  }[];
  events: HistoricalEvent[];
}

export interface Continent {
  id: ContinentCode;
  name: string;
  tagline: string;
  countriesCount: number;
  population: string;
  area: string;
  highestPoint: string;
  lowestPoint: string;
  largestCity: string;
  majorOceans: string[];
  climateSummary: string;
  image: string;
  overview: string;
  highlights: string[];
}

export interface OceanSea {
  id: string;
  name: string;
  type: 'Ocean' | 'Sea' | 'Gulf' | 'Bay';
  area: string;
  averageDepth: string;
  deepestPoint: string;
  borderingContinents: string[];
  keyFacts: string[];
  image: string;
}

export interface GeographicFeature {
  id: string;
  name: string;
  type: 'Mountain Range' | 'Trench' | 'Desert' | 'River' | 'Rainforest' | 'Plateau' | 'Rift Valley' | 'Canal';
  location: string;
  continent: string;
  keyMetric: string; // e.g. "8,848m high", "6,400km long"
  description: string;
  image: string;
}

export type CityType = 'Metropolis' | 'Historical Capital' | 'Coastal Hub' | 'Cultural Center' | 'Alpine Town' | 'Island Port' | 'Desert Oasis' | string;

export type TripType = 'General' | 'Beach' | 'Hiking' | 'Winter' | 'City' | 'Rainy' | 'Backpacking';

export type LandmarkCategory = 'Architectural' | 'Natural Wonder' | 'Ancient Monument' | 'Religious' | 'Engineering Marvel' | 'Historical Site' | string;

export interface CountryFact {
  id: string;
  name: string;
  officialName?: string;
  code?: string; // ISO 3166-1 alpha-2 or alpha-3
  isoCode?: string;
  flag: string; // Emoji flag or SVG
  capital: string;
  continent: ContinentCode;
  region: string;
  subregion?: string;
  population: string;
  area?: string;
  languages: string[];
  language?: string;
  currency: {
    name: string;
    code: string;
    symbol: string;
    rateToUSD?: number;
  };
  currencyCode?: string;
  currencySymbol?: string;
  timeZone?: string;
  timeZones?: string[];
  callingCode: string;
  drivingSide: any;
  government?: string;
  governmentType?: string;
  nationalSymbols?: {
    animal?: string;
    flower?: string;
    bird?: string;
    motto?: string;
  };
  heroImage?: string;
  gallery?: string[];
  overview: string;
  interestingFacts: string[];
  mapCoords?: { lat: number; lng: number };
  popularCities?: string[];
  topLandmarks?: string[];
  famousFoods?: string[];
  bestTimeToVisit?: any;
  visaSummary?: {
    difficulty: 'Visa-Free / VoA' | 'Easy eVisa' | 'Embassy Visa' | 'Varies by Passport';
    note: string;
    officialPortalUrl?: string;
  };
  budgetTier?: 'Budget ($)' | 'Moderate ($$)' | 'Upper-Mid ($$$)' | 'Luxury ($$$$)';
  averageDailyCostUSD?: {
    budget: number;
    midRange: number;
    luxury: number;
  };
  safetyScore?: number; // 1-10
  plugTypes?: string[];
  isFeatured?: boolean;
  travelInfo?: any;
}

export type CountryDetail = CountryFact;

export type DestinationCategory = 
  | 'World-Famous' 
  | 'Hidden Gem' 
  | 'Mountain & Valley' 
  | 'Waterfall & Lake' 
  | 'Canyon & Cave' 
  | 'Desert & Dune' 
  | 'Glacier & Ice' 
  | 'Volcano' 
  | 'Island & Beach' 
  | 'Rainforest & Jungle'
  | string;

export interface Destination {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  continent: ContinentCode;
  category: DestinationCategory;
  type: 'Famous' | 'Hidden' | 'Natural' | string;
  subType: string;
  overview: string;
  highlights: string[];
  whyVisit: string;
  bestSeason: string;
  idealFor: string[];
  image: string;
  rating: number;
  locationDetails: string;
}

export interface CityItem {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  continent: ContinentCode;
  region: string;
  cityType: CityType;
  population: string;
  overview: string;
  historySnippet?: string;
  history?: string;
  tagline?: string;
  famousPlaces: string[];
  attractions: string[];
  localFood?: string[];
  famousFood?: string[];
  cultureHighlights?: string;
  architectureStyle?: string;
  natureSpots?: string[];
  activities?: string[];
  shoppingAreas?: string[];
  photoSpots?: string[];
  nearbyDestinations?: string[];
  dayTrips?: string[];
  travelTips?: string[];
  secretTip?: string;
  image: string;
  gallery?: string[];
  interestingFacts?: string[];
  idealStayDays?: number;
  idealDurationDays?: number;
  bestMonths?: string;
  bestMonthsToVisit?: string;
}

export interface Landmark {
  id: string;
  name: string;
  location: string;
  country: string;
  countryCode: string;
  cityOrRegion: string;
  continent: ContinentCode;
  category: LandmarkCategory;
  overview: string;
  highlights: string[];
  whatMakesItSpecial?: string;
  bestFor?: string[];
  nearbyPlaces?: string[];
  nearbyAttractions?: string[];
  image: string;
  gallery?: string[];
  interestingFacts?: string[];
  entryTip?: string;
  visitorTips?: string[];
  unescoYear?: number;
  unescoWorldHeritage?: boolean;
  rating?: number;
}

export type LandmarkItem = Landmark;

export interface FoodItem {
  id: string;
  name: string;
  nativeName?: string;
  country: string;
  countryCode: string;
  region: string;
  type: 'Traditional Dish' | 'Street Food' | 'Dessert' | 'Beverage' | 'Snack' | 'Signature Feast';
  description: string;
  ingredientsOverview: string[];
  culturalImportance: string;
  isVegetarianFriendly: boolean;
  flavorProfile: string;
  whereToFind: string;
  image: string;
}

export interface CultureItem {
  id: string;
  title: string;
  country: string;
  continent: ContinentCode;
  category: 'Traditions & Customs' | 'Music & Dance' | 'Art & Craft' | 'Traditional Clothing' | 'Architecture' | 'Social Etiquette';
  description: string;
  culturalEtiquetteTips: string[];
  historicalContext: string;
  image: string;
}

export interface FestivalItem {
  id: string;
  name: string;
  nativeName?: string;
  country: string;
  region: string;
  timeOfYear: string;
  monthIndex: number; // 0-11
  category: 'Cultural' | 'National' | 'Religious' | 'Seasonal' | 'Arts & Music' | 'Culinary';
  historyBackground: string;
  culturalSignificance: string;
  visitorExperience: string;
  image: string;
}

export interface ActivityExperience {
  id: string;
  title: string;
  country: string;
  location: string;
  continent: ContinentCode;
  category: 'Adventure' | 'Hiking & Trekking' | 'Wildlife Safari' | 'Photography' | 'Culinary Journey' | 'Scenic Train' | 'Road Trip' | 'Water & Cruise' | 'Cultural Immersion';
  difficulty: 'Easy' | 'Moderate' | 'Challenging' | 'Expert';
  duration: string;
  description: string;
  highlights: string[];
  bestMonths: string;
  tips: string;
  image: string;
}

export interface WildlifeItem {
  id: string;
  name: string;
  scientificName: string;
  category: 'Mammals' | 'Birds' | 'Marine Life' | 'Reptiles' | 'Endangered Species';
  primaryHabitats: string[];
  countriesFound: string[];
  conservationStatus: 'Least Concern' | 'Vulnerable' | 'Endangered' | 'Critically Endangered';
  bestPlacesToSpot: string[];
  interestingFacts: string[];
  image: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  author: string;
  publishedDate: string;
  readTime: string;
  category: 'Destination Guide' | 'Hidden Gems' | 'Budget Travel' | 'Culture & Food' | 'Nature Wonders' | 'Travel Tips';
  heroImage: string;
  country?: string;
  continent?: ContinentCode;
  tags: string[];
  contentSections: {
    heading: string;
    body: string;
    image?: string;
    bullets?: string[];
  }[];
}

export interface TravelFAQ {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'Visa' | 'Budget' | 'Packing' | 'Safety' | 'Best Time';
  countryCode?: string;
}

export interface PackingItem {
  id: string;
  name: string;
  category: 'Clothing' | 'Footwear' | 'Documents' | 'Electronics' | 'Toiletries' | 'Health & Safety' | 'Outdoor Gear' | 'Custom' | string;
  tripTypes: ('General' | 'Beach' | 'Hiking' | 'Winter' | 'City' | 'Rainy' | 'Backpacking')[];
  essential: boolean;
}

export interface SavedItem {
  id: string;
  type: 'country' | 'city' | 'destination' | 'landmark' | 'food' | 'activity' | 'article';
  title: string;
  subtitle: string;
  image: string;
  savedAt: string;
  notes?: string;
}

export type SupportedLanguage = 'en' | 'hi' | 'bn' | 'es' | 'fr';
