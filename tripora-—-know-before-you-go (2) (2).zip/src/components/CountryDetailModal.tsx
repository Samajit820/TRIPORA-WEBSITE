import React, { useState } from 'react';
import {
  X, Bookmark, Share2, MapPin, Globe, Shield, DollarSign, Calendar,
  Utensils, Compass, Sparkles, AlertCircle, Info, ChevronRight, Check,
  Zap, PhoneCall, CheckCircle2
} from 'lucide-react';
import { CountryDetail, CityItem } from '../types';
import { DETAILED_COUNTRIES, ALL_195_COUNTRIES } from '../data/countries';
import { CITIES_DATA } from '../data/cities';
import { LANDMARKS_DATA } from '../data/landmarks';
import { FOODS_DATA } from '../data/foods';
import { FESTIVALS_DATA } from '../data/cultureFestivals';

interface CountryDetailModalProps {
  countryId: string | null;
  onClose: () => void;
  onToggleSave: (countryName: string) => void;
  isSaved: boolean;
  onSelectCity?: (cityId: string) => void;
  onSelectLandmark?: (landmarkId: string) => void;
}

type CountryTab =
  | 'overview'
  | 'travel'
  | 'cities'
  | 'landmarks'
  | 'food'
  | 'culture'
  | 'budget'
  | 'safety';

export const CountryDetailModal: React.FC<CountryDetailModalProps> = ({
  countryId,
  onClose,
  onToggleSave,
  isSaved,
  onSelectCity,
  onSelectLandmark
}) => {
  const [activeTab, setActiveTab] = useState<CountryTab>('overview');
  const [budgetTier, setBudgetTier] = useState<'backpacker' | 'midRange' | 'luxury'>('midRange');
  const [tripDays, setTripDays] = useState<number>(7);
  const [copiedShare, setCopiedShare] = useState(false);

  if (!countryId) return null;

  // Find country data (deep detailed profile or fallback from 195 registry)
  const detailedCountry: CountryDetail | undefined = DETAILED_COUNTRIES.find(
    (c) => c.id === countryId || c.name.toLowerCase() === countryId.toLowerCase()
  );

  const fallbackCountry = ALL_195_COUNTRIES.find(
    (c) => c.id === countryId || c.name.toLowerCase() === countryId.toLowerCase()
  );

  // If only fallback is found, build a basic CountryDetail structure
  const rawCountry = detailedCountry || fallbackCountry;

  // Normalized safe country object
  const country: CountryDetail = {
    id: rawCountry?.id || countryId || 'country',
    name: rawCountry?.name || 'Country',
    officialName: detailedCountry?.officialName || rawCountry?.name || 'Sovereign Nation',
    code: (rawCountry as any)?.code || 'XX',
    isoCode: (rawCountry as any)?.code || 'XX',
    flag: rawCountry?.flag || '🏳️',
    capital: rawCountry?.capital || 'Capital City',
    continent: rawCountry?.continent || 'asia',
    region: rawCountry?.region || 'Global',
    subregion: detailedCountry?.subregion || rawCountry?.region || 'Global Region',
    population: rawCountry?.population || 'N/A',
    area: detailedCountry?.area || 'N/A',
    languages: detailedCountry?.languages || ['Official Language', 'Regional Dialects'],
    currency: detailedCountry?.currency || {
      name: (rawCountry as any)?.currency || 'Local Currency',
      code: (rawCountry as any)?.currency || 'USD',
      symbol: '$',
      rateToUSD: 1
    },
    timeZone: detailedCountry?.timeZone || 'UTC+0',
    timeZones: detailedCountry?.timeZones || (detailedCountry?.timeZone ? [detailedCountry.timeZone] : ['UTC+0']),
    drivingSide: detailedCountry?.drivingSide || 'Right',
    callingCode: detailedCountry?.callingCode || '+00',
    government: detailedCountry?.government || 'Sovereign Constitutional State',
    governmentType: detailedCountry?.governmentType || detailedCountry?.government || 'Sovereign Constitutional State',
    overview: detailedCountry?.overview || `${rawCountry?.name} is a sovereign country located in ${rawCountry?.region} with its capital at ${rawCountry?.capital}. It offers unique landscapes, historic heritage, and cultural traditions.`,
    heroImage: detailedCountry?.heroImage || 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1200&q=80',
    gallery: detailedCountry?.gallery || [
      'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80'
    ],
    mapCoords: detailedCountry?.mapCoords || { lat: 20, lng: 0 },
    nationalSymbols: detailedCountry?.nationalSymbols || {
      animal: 'National Fauna',
      flower: 'National Flora',
      motto: 'Unity & Progress'
    },
    interestingFacts: detailedCountry?.interestingFacts || [
      `${rawCountry?.name} is an active sovereign member state of the United Nations.`,
      `The capital city ${rawCountry?.capital} serves as the primary administrative and cultural center.`,
      `The country uses ${((rawCountry as any)?.currency) || 'its official currency'} as legal tender.`
    ],
    travelInfo: {
      bestTimeToVisit: detailedCountry?.travelInfo?.bestTimeToVisit || {
        peakSeason: {
          months: (typeof detailedCountry?.bestTimeToVisit?.peakSeason === 'string' ? detailedCountry.bestTimeToVisit.peakSeason : 'October to March'),
          description: detailedCountry?.bestTimeToVisit?.summary || 'Optimal weather for sightseeing and outdoor cultural tours.'
        },
        shoulderSeason: {
          months: (typeof detailedCountry?.bestTimeToVisit?.shoulderSeason === 'string' ? detailedCountry.bestTimeToVisit.shoulderSeason : 'April & September'),
          description: 'Fewer tourist crowds, pleasant climate, and balanced travel rates.'
        },
        lowSeason: {
          months: (typeof detailedCountry?.bestTimeToVisit?.lowSeason === 'string' ? detailedCountry.bestTimeToVisit.lowSeason : 'May to August'),
          description: 'Off-peak season offering significant discounts on boutique hotels and flights.'
        }
      },
      visaRequirements: detailedCountry?.travelInfo?.visaRequirements || {
        type: detailedCountry?.visaSummary?.difficulty ? `${detailedCountry.visaSummary.difficulty} - ${detailedCountry.visaSummary.note}` : 'eVisa / Visa on Arrival for most nationalities',
        duration: '30-90 Days',
        costUSD: 50,
        officialPortalUrl: detailedCountry?.visaSummary?.officialPortalUrl || 'https://www.tripora.com'
      },
      budgetBreakdown: detailedCountry?.travelInfo?.budgetBreakdown || {
        backpacker: {
          dailyCostUSD: detailedCountry?.averageDailyCostUSD?.budget || 40,
          accommodation: 'Hostel dorm or guesthouse',
          food: 'Local street food & market stalls',
          transport: 'Public buses & metro trains'
        },
        midRange: {
          dailyCostUSD: detailedCountry?.averageDailyCostUSD?.midRange || 110,
          accommodation: '3-star boutique hotel',
          food: 'Casual regional dining & bistros',
          transport: 'Taxis & express rail'
        },
        luxury: {
          dailyCostUSD: detailedCountry?.averageDailyCostUSD?.luxury || 280,
          accommodation: '5-star luxury resort & heritage stay',
          food: 'Fine dining & chef degustations',
          transport: 'Private chauffeurs & executive transfers'
        }
      },
      safety: detailedCountry?.travelInfo?.safety || {
        score: detailedCountry?.safetyScore ? Math.round(detailedCountry.safetyScore * 10) : 85,
        rating: detailedCountry?.safetyScore && detailedCountry.safetyScore >= 8 ? 'Very Safe' : 'Generally Safe',
        tips: [
          'Keep digital backups of your travel insurance, passport, and visas.',
          'Use licensed metered taxis or verified ride-hailing applications.',
          'Stay aware of personal belongings in crowded transit hubs and tourist plazas.'
        ]
      },
      transportation: detailedCountry?.travelInfo?.transportation || {
        domesticFlights: 'Available between primary regional hubs and international gateways.',
        trains: 'Comfortable rail lines and express routes connect major metropolitan areas.',
        buses: 'Extensive long-distance coach networks with affordable intercity connections.',
        carRental: 'Widely accessible at major airports; requires an International Driving Permit.'
      },
      connectivity: detailedCountry?.travelInfo?.connectivity || {
        esimRecommended: true,
        bestLocalSIMs: ['National Telecom', 'Global Mobile 5G', 'Traveler eSIM'],
        wifiAvailability: 'Widely available in hotels, cafes, airports, and urban hubs.'
      },
      electrical: detailedCountry?.travelInfo?.electrical || {
        plugTypes: detailedCountry?.plugTypes || ['Type C', 'Type G'],
        voltage: '230V / 50Hz'
      },
      emergencyNumbers: detailedCountry?.travelInfo?.emergencyNumbers || {
        police: '112 / 911',
        ambulance: '112 / 911',
        touristHelpline: '1800-TRIPORA'
      },
      usefulPhrases: detailedCountry?.travelInfo?.usefulPhrases || [
        { phrase: 'Hello', translation: 'Hello / Greeting', pronunciation: 'hel-loh' },
        { phrase: 'Thank you', translation: 'Thank you', pronunciation: 'thank yoo' },
        { phrase: 'Please', translation: 'Please', pronunciation: 'pleez' },
        { phrase: 'Where is...?', translation: 'Where is...?', pronunciation: 'wair-iz' }
      ]
    }
  };

  // Connected entities from databases
  const rawConnectedCities = CITIES_DATA.filter(
    (c) => c.country.toLowerCase() === country.name.toLowerCase() || country.name.toLowerCase().includes(c.country.toLowerCase())
  );

  const knownCityNames = new Set(rawConnectedCities.map((c) => c.name.toLowerCase()));
  const extraCities: CityItem[] = [];

  const candidateCityNames = [
    country.capital,
    ...(detailedCountry?.popularCities || [])
  ].filter(Boolean);

  candidateCityNames.forEach((cityName) => {
    if (!knownCityNames.has(cityName.toLowerCase()) && cityName !== 'N/A' && cityName !== 'None' && cityName !== 'Capital City') {
      knownCityNames.add(cityName.toLowerCase());
      const isCapital = cityName.toLowerCase() === country.capital.toLowerCase();
      extraCities.push({
        id: cityName.toLowerCase().replace(/\s+/g, '-'),
        name: cityName,
        country: country.name,
        countryCode: country.code || 'XX',
        continent: country.continent,
        region: country.region,
        cityType: isCapital ? 'Capital City' : 'Regional Metropolis',
        tagline: `${isCapital ? 'Capital & ' : ''}Urban Center of ${country.name}`,
        population: country.population ? `${country.population} (Nation)` : 'Urban Hub',
        overview: `${cityName} is a major destination and cultural hub in ${country.name}, featuring historic quarters, authentic local markets, and traditional architecture.`,
        famousPlaces: [`${cityName} Main Plaza`, `Historic Old Town`, `National Heritage Site`],
        attractions: [`Cultural Museum of ${cityName}`, `Central Botanical Park`],
        famousFood: [`Traditional ${country.name} Specialties`, `Local Bakery Delicacies`],
        image: country.heroImage,
        idealDurationDays: 3,
        idealStayDays: 3,
        bestMonthsToVisit: 'Spring & Autumn'
      });
    }
  });

  const connectedCities = [...rawConnectedCities, ...extraCities];

  const connectedLandmarks = LANDMARKS_DATA.filter(
    (l) => l.country.toLowerCase() === country.name.toLowerCase() || country.name.toLowerCase().includes(l.country.toLowerCase())
  );

  const connectedFoods = FOODS_DATA.filter(
    (f) => f.country.toLowerCase() === country.name.toLowerCase() || country.name.toLowerCase().includes(f.country.toLowerCase())
  );

  const connectedFestivals = FESTIVALS_DATA.filter(
    (fest) => fest.country.toLowerCase() === country.name.toLowerCase() || country.name.toLowerCase().includes(fest.country.toLowerCase())
  );

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2000);
  };

  const currentDailyRate =
    budgetTier === 'backpacker'
      ? country.travelInfo.budgetBreakdown.backpacker.dailyCostUSD
      : budgetTier === 'midRange'
      ? country.travelInfo.budgetBreakdown.midRange.dailyCostUSD
      : country.travelInfo.budgetBreakdown.luxury.dailyCostUSD;

  const estimatedTotalCost = currentDailyRate * tripDays;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
      
      {/* Click outside backdrop */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Main Modal Container */}
      <div className="relative w-full max-w-5xl rounded-2xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[92vh] z-10 animate-in zoom-in-95 duration-150 text-[#1a1a1a]">
        
        {/* Modal Top Hero Banner */}
        <div className="relative h-48 sm:h-64 flex-shrink-0 overflow-hidden">
          <img
            src={country.heroImage}
            alt={country.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/60 to-[#1a1a1a]/20" />

          {/* Action Top Bar */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
            <div className="flex items-center gap-2">
              <span className="text-3xl sm:text-4xl shadow-md">{country.flag}</span>
              <div className="bg-[#1a1a1a]/80 backdrop-blur-xs px-3 py-1 rounded-md text-xs font-semibold text-white">
                {country.region} • {country.subregion}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShare}
                className="p-2.5 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-white hover:bg-[#1a1a1a] transition-colors cursor-pointer"
                title="Share link"
              >
                {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>
              
              <button
                onClick={() => onToggleSave(country.name)}
                className={`p-2.5 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                  isSaved
                    ? 'bg-amber-400 text-stone-950 font-bold'
                    : 'bg-[#1a1a1a]/80 text-white hover:text-amber-300'
                }`}
                title={isSaved ? 'Saved to Bucket List' : 'Save to Bucket List'}
              >
                <Bookmark className="w-4 h-4" />
              </button>

              <button
                onClick={onClose}
                className="p-2.5 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Hero Bottom Titles */}
          <div className="absolute bottom-4 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
            <div>
              <div className="text-xs uppercase font-bold tracking-widest text-amber-300">
                {country.officialName}
              </div>
              <h2 className="font-heading text-2xl sm:text-4xl font-bold text-white">
                {country.name}
              </h2>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="px-3 py-1 rounded-md bg-[#1a1a1a]/80 text-stone-200">
                Capital: <strong className="text-white">{country.capital}</strong>
              </span>
              <span className="px-3 py-1 rounded-md bg-emerald-900/60 border border-emerald-500/40 text-emerald-200 font-semibold flex items-center gap-1">
                <Shield className="w-3.5 h-3.5" /> Safety: {country.travelInfo.safety.score}/100
              </span>
            </div>
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2.5 bg-[#f0ece1] border-b border-[#e2ded5] overflow-x-auto text-xs scrollbar-none flex-shrink-0">
          {[
            { id: 'overview', label: 'Overview & Geography' },
            { id: 'travel', label: 'Travel Info & Seasons' },
            { id: 'cities', label: `Cities (${connectedCities.length})` },
            { id: 'landmarks', label: `Landmarks (${connectedLandmarks.length})` },
            { id: 'food', label: `Food & Cuisine (${connectedFoods.length})` },
            { id: 'culture', label: 'Culture & Etiquette' },
            { id: 'budget', label: 'Budget Calculator' },
            { id: 'safety', label: 'Safety & Essentials' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as CountryTab)}
              className={`px-3.5 py-1.5 rounded-md font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#5a564e] hover:text-[#1a1a1a] hover:bg-[#e4dfd2]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Modal Scrollable Content Body */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1 text-[#2d2a24]">
          
          {/* TAB 1: OVERVIEW & GEOGRAPHY */}
          {activeTab === 'overview' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-heading text-lg font-bold text-[#1a1a1a] mb-2">Country Overview</h3>
                <p className="text-sm sm:text-base text-[#4a473e] leading-relaxed">
                  {country.overview}
                </p>
              </div>

              {/* Geographic & Vital Stats Grid */}
              <div>
                <h4 className="text-xs uppercase font-bold tracking-wider text-[#7a7467] mb-3">Vital Geographic & National Facts</h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Total Population</span>
                    <span className="font-bold text-[#1a1a1a] mt-1 block text-sm">{country.population}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Total Land Area</span>
                    <span className="font-bold text-[#1a1a1a] mt-1 block text-sm">{country.area}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Official Currency</span>
                    <span className="font-bold text-amber-900 mt-1 block text-sm">{country.currency.name} ({country.currency.symbol})</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Primary Languages</span>
                    <span className="font-bold text-[#1a1a1a] mt-1 block text-sm truncate">{country.languages.join(', ')}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Time Zones</span>
                    <span className="font-bold text-[#1a1a1a] mt-1 block text-sm">{country.timeZones.join(', ')}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Driving Side</span>
                    <span className="font-bold text-[#1a1a1a] mt-1 block text-sm capitalize">{country.drivingSide} Side</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Calling Code</span>
                    <span className="font-bold text-teal-800 mt-1 block text-sm">{country.callingCode}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[10px] uppercase text-[#7a7467] block font-semibold">Government System</span>
                    <span className="font-bold text-[#1a1a1a] mt-1 block text-sm truncate">{country.governmentType}</span>
                  </div>
                </div>
              </div>

              {/* National Symbols */}
              {country.nationalSymbols && (
                <div className="p-4 rounded-xl bg-[#f8f6f0] border border-[#ebe7dc]">
                  <h4 className="text-xs uppercase font-bold tracking-wider text-[#1a1a1a] mb-3">National Symbols & Heritage</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="text-[#7a7467] block font-medium">National Animal:</span>
                      <strong className="text-[#1a1a1a]">{country.nationalSymbols.animal}</strong>
                    </div>
                    <div>
                      <span className="text-[#7a7467] block font-medium">National Flower / Tree:</span>
                      <strong className="text-[#1a1a1a]">{country.nationalSymbols.flower}</strong>
                    </div>
                    <div>
                      <span className="text-[#7a7467] block font-medium">National Motto:</span>
                      <strong className="text-stone-800 italic">"{country.nationalSymbols.motto}"</strong>
                    </div>
                  </div>
                </div>
              )}

              {/* Interesting Facts */}
              <div>
                <h4 className="text-xs uppercase font-bold tracking-wider text-[#7a7467] mb-3">Interesting & Surprising Facts</h4>
                <div className="space-y-2">
                  {country.interestingFacts.map((fact, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 p-3.5 rounded-xl bg-white border border-[#e7e4dc] text-xs sm:text-sm shadow-xs">
                      <Sparkles className="w-4 h-4 text-amber-700 mt-0.5 flex-shrink-0" />
                      <span className="text-[#4a473e]">{fact}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Photo Gallery */}
              {country.gallery && country.gallery.length > 0 && (
                <div>
                  <h4 className="text-xs uppercase font-bold tracking-wider text-[#7a7467] mb-3">Country Visual Gallery</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {country.gallery.map((imgUrl, i) => (
                      <div key={i} className="h-32 rounded-xl overflow-hidden border border-[#e7e4dc]">
                        <img src={imgUrl} alt={`${country.name} photo ${i + 1}`} className="w-full h-full object-cover hover:scale-105 transition-transform" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: TRAVEL INFO & SEASONS */}
          {activeTab === 'travel' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Best Seasons Matrix */}
              <div>
                <h3 className="font-heading text-lg font-bold text-[#1a1a1a] mb-3">Best Time to Visit & Climate Seasons</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-xl bg-[#eef8f2] border border-[#c3e8d2]">
                    <div className="flex items-center justify-between text-xs font-bold text-emerald-800 uppercase mb-1">
                      <span>Peak Season</span>
                      <span>⭐️ Top Choice</span>
                    </div>
                    <div className="text-base font-bold text-[#1a1a1a]">{country.travelInfo.bestTimeToVisit.peakSeason.months}</div>
                    <p className="text-xs text-[#4a473e] mt-2">{country.travelInfo.bestTimeToVisit.peakSeason.description}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#fbf5ea] border border-[#eedab2]">
                    <div className="flex items-center justify-between text-xs font-bold text-amber-900 uppercase mb-1">
                      <span>Shoulder Season</span>
                      <span>⚖️ Great Value</span>
                    </div>
                    <div className="text-base font-bold text-[#1a1a1a]">{country.travelInfo.bestTimeToVisit.shoulderSeason.months}</div>
                    <p className="text-xs text-[#4a473e] mt-2">{country.travelInfo.bestTimeToVisit.shoulderSeason.description}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#eef5f8] border border-[#c5e1ea]">
                    <div className="flex items-center justify-between text-xs font-bold text-teal-800 uppercase mb-1">
                      <span>Low Season</span>
                      <span>💰 Budget</span>
                    </div>
                    <div className="text-base font-bold text-[#1a1a1a]">{country.travelInfo.bestTimeToVisit.lowSeason.months}</div>
                    <p className="text-xs text-[#4a473e] mt-2">{country.travelInfo.bestTimeToVisit.lowSeason.description}</p>
                  </div>
                </div>
              </div>

              {/* Visa Info */}
              <div className="p-5 rounded-xl bg-white border border-[#e7e4dc] space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <h4 className="font-heading text-base font-bold text-[#1a1a1a] flex items-center gap-2">
                    <Info className="w-4 h-4 text-amber-700" />
                    Tourist Visa Policy & Requirements
                  </h4>
                  <span className="px-2.5 py-1 rounded-md bg-[#f0ece1] text-[#1a1a1a] text-xs font-bold border border-[#ded9cc]">
                    Est. Fee: ${country.travelInfo.visaRequirements.costUSD} USD
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                    <span className="text-[#7a7467] block font-medium">Visa Protocol:</span>
                    <strong className="text-[#1a1a1a] text-sm mt-0.5 block">{country.travelInfo.visaRequirements.type}</strong>
                  </div>
                  <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                    <span className="text-[#7a7467] block font-medium">Standard Stay Length:</span>
                    <strong className="text-[#1a1a1a] text-sm mt-0.5 block">{country.travelInfo.visaRequirements.duration}</strong>
                  </div>
                </div>
                <div className="pt-2 flex justify-end">
                  <a
                    href={country.travelInfo.visaRequirements.officialPortalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white text-xs font-semibold transition-colors"
                  >
                    <span>Check Official Embassy & eVisa Portal</span>
                    <ChevronRight className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {/* Transportation Overview */}
              <div>
                <h4 className="text-xs uppercase font-bold tracking-wider text-[#7a7467] mb-3">Internal Getting Around & Transit</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <strong className="text-amber-900 block mb-1">🚅 Trains & High-Speed Rail</strong>
                    <span className="text-[#4a473e]">{country.travelInfo.transportation.trains}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <strong className="text-teal-900 block mb-1">✈️ Domestic Flights</strong>
                    <span className="text-[#4a473e]">{country.travelInfo.transportation.domesticFlights}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <strong className="text-emerald-900 block mb-1">🚌 Regional Buses & Coaches</strong>
                    <span className="text-[#4a473e]">{country.travelInfo.transportation.buses}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <strong className="text-rose-900 block mb-1">🚗 Car Rental & Driving</strong>
                    <span className="text-[#4a473e]">{country.travelInfo.transportation.carRental}</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: CONNECTED CITIES */}
          {activeTab === 'cities' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">
                Major Cities & Metropolises in {country.name}
              </h3>
              {connectedCities.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {connectedCities.map((city) => (
                    <div
                      key={city.id}
                      className="p-4 rounded-xl bg-white border border-[#e7e4dc] hover:border-[#c5bea] transition-all flex flex-col justify-between shadow-xs"
                    >
                      <div className="flex gap-3">
                        <img src={city.image} alt={city.name} className="w-20 h-20 rounded-lg object-cover" />
                        <div>
                          <span className="text-[10px] uppercase font-bold text-amber-800">{city.cityType}</span>
                          <h4 className="font-heading text-base font-bold text-[#1a1a1a]">{city.name}</h4>
                          <p className="text-xs text-[#5a564e] mt-1 line-clamp-2">{city.overview}</p>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t border-[#f0ece1] flex items-center justify-between text-xs text-[#7a7467]">
                        <span>Ideal stay: <strong className="text-[#1a1a1a]">{city.idealDurationDays || city.idealStayDays || 3} Days</strong></span>
                        {onSelectCity && (
                          <button
                            onClick={() => {
                              onSelectCity(city.id || city.name);
                              onClose();
                            }}
                            className="text-[#1a1a1a] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <span>Explore City Guide</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-[#7a7467] bg-white rounded-xl border border-[#e7e4dc]">
                  <MapPin className="w-8 h-8 text-[#a39c8e] mx-auto mb-2" />
                  <p className="text-sm">Capital city is <strong>{country.capital}</strong>.</p>
                  <p className="text-xs text-[#8a8477] mt-1">Additional regional city profiles are being continuously added to the TRIPORA encyclopedia.</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: LANDMARKS & ATTRACTIONS */}
          {activeTab === 'landmarks' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">
                Famous Landmarks & World Heritage in {country.name}
              </h3>
              {connectedLandmarks.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {connectedLandmarks.map((lm) => (
                    <div
                      key={lm.id}
                      className="p-4 rounded-xl bg-white border border-[#e7e4dc] hover:border-[#c5bea] transition-all flex flex-col justify-between shadow-xs"
                    >
                      <div className="flex gap-3">
                        <img src={lm.image} alt={lm.name} className="w-20 h-20 rounded-lg object-cover" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] uppercase font-bold text-rose-800">{lm.category}</span>
                            {lm.unescoWorldHeritage && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-100 text-cyan-900 font-bold border border-cyan-200">UNESCO</span>
                            )}
                          </div>
                          <h4 className="font-heading text-base font-bold text-[#1a1a1a]">{lm.name}</h4>
                          <p className="text-xs text-[#5a564e] mt-1 line-clamp-2">{lm.overview}</p>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t border-[#f0ece1] flex items-center justify-between text-xs text-[#7a7467]">
                        <span>Rating: <strong className="text-amber-900">★ {lm.rating}</strong></span>
                        {onSelectLandmark && (
                          <button
                            onClick={() => {
                              onSelectLandmark(lm.id);
                              onClose();
                            }}
                            className="text-[#1a1a1a] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <span>View Landmark</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-[#7a7467] bg-white rounded-xl border border-[#e7e4dc]">
                  <Compass className="w-8 h-8 text-[#a39c8e] mx-auto mb-2" />
                  <p className="text-sm">Landmarks database for {country.name} is indexing.</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: FOOD & GASTRONOMY */}
          {activeTab === 'food' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">
                Authentic Food & Flavors of {country.name}
              </h3>
              {connectedFoods.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {connectedFoods.map((food) => (
                    <div key={food.id} className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-3 shadow-xs">
                      <div className="flex gap-3">
                        <img src={food.image} alt={food.name} className="w-20 h-20 rounded-lg object-cover" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] uppercase font-bold text-amber-800">{food.type}</span>
                            {food.isVegetarianFriendly && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">Veg Friendly</span>
                            )}
                          </div>
                          <h4 className="font-heading text-base font-bold text-[#1a1a1a]">{food.name}</h4>
                          <span className="text-xs text-[#7a7467] italic">{food.nativeName}</span>
                        </div>
                      </div>
                      <p className="text-xs text-[#4a473e] leading-relaxed">{food.description}</p>
                      <div className="p-2 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs">
                        <span className="text-[#7a7467] block text-[10px] uppercase font-bold">Where to try:</span>
                        <span className="text-[#1a1a1a] font-medium">{food.whereToFind}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-[#7a7467] bg-white rounded-xl border border-[#e7e4dc]">
                  <Utensils className="w-8 h-8 text-[#a39c8e] mx-auto mb-2" />
                  <p className="text-sm">Discover authentic street stalls and traditional culinary markets across {country.name}.</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: CULTURE & ETIQUETTE */}
          {activeTab === 'culture' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-heading text-lg font-bold text-[#1a1a1a] mb-3">Cultural Etiquette & Social Do's and Don'ts</h3>
                <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 text-xs sm:text-sm shadow-xs">
                  {country.travelInfo.safety.tips.map((tip, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-[#4a473e]">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700 mt-0.5 flex-shrink-0" />
                      <span>{tip}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Useful Local Phrases */}
              {country.travelInfo.usefulPhrases && country.travelInfo.usefulPhrases.length > 0 && (
                <div>
                  <h4 className="text-xs uppercase font-bold tracking-wider text-[#1a1a1a] mb-3">Essential Local Phrases</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {country.travelInfo.usefulPhrases.map((phraseItem, i) => (
                      <div key={i} className="p-3 rounded-xl bg-white border border-[#e7e4dc] flex items-center justify-between shadow-xs">
                        <div>
                          <span className="font-bold text-[#1a1a1a] text-sm block">{phraseItem.phrase}</span>
                          <span className="text-[#7a7467]">Meaning: {phraseItem.translation}</span>
                        </div>
                        <span className="px-2 py-1 rounded bg-[#f0ece1] text-[#4a473e] font-mono text-[11px] border border-[#e2ded5]">
                          [{phraseItem.pronunciation}]
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Connected Festivals */}
              {connectedFestivals.length > 0 && (
                <div>
                  <h4 className="text-xs uppercase font-bold tracking-wider text-purple-900 mb-3">Major National Festivals & Celebrations</h4>
                  <div className="space-y-3">
                    {connectedFestivals.map((fest) => (
                      <div key={fest.id} className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 shadow-xs">
                        <div className="flex items-center justify-between">
                          <h5 className="font-bold text-[#1a1a1a] text-sm">{fest.name}</h5>
                          <span className="text-xs text-purple-800 font-semibold">{fest.timeOfYear}</span>
                        </div>
                        <p className="text-xs text-[#4a473e]">{fest.culturalSignificance}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 7: BUDGET CALCULATOR */}
          {activeTab === 'budget' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-heading text-lg font-bold text-[#1a1a1a] mb-2">Interactive Travel Budget Estimator</h3>
                <p className="text-xs text-[#7a7467]">Estimate your trip expenses based on your travel style and trip duration in {country.name}.</p>
              </div>

              {/* Tier Selection */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'backpacker', label: 'Backpacker / Budget', cost: country.travelInfo.budgetBreakdown.backpacker.dailyCostUSD, icon: '🎒' },
                  { id: 'midRange', label: 'Mid-Range Comfort', cost: country.travelInfo.budgetBreakdown.midRange.dailyCostUSD, icon: '🏨' },
                  { id: 'luxury', label: 'Luxury & Resorts', cost: country.travelInfo.budgetBreakdown.luxury.dailyCostUSD, icon: '✨' }
                ].map((tier) => (
                  <button
                    key={tier.id}
                    onClick={() => setBudgetTier(tier.id as any)}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      budgetTier === tier.id
                        ? 'bg-[#1a1a1a] border-[#1a1a1a] text-white'
                        : 'bg-white border-[#e7e4dc] text-[#5a564e] hover:bg-[#f7f5ee]'
                    }`}
                  >
                    <div className="text-xl mb-1">{tier.icon}</div>
                    <div className="text-xs font-semibold">{tier.label}</div>
                    <div className={`text-sm font-bold mt-1 ${budgetTier === tier.id ? 'text-amber-300' : 'text-[#1a1a1a]'}`}>${tier.cost} <span className="text-[10px] opacity-75 font-normal">/ day</span></div>
                  </button>
                ))}
              </div>

              {/* Trip Duration Slider */}
              <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-3 shadow-xs">
                <div className="flex items-center justify-between text-xs font-semibold text-[#1a1a1a]">
                  <span>Trip Duration: <strong className="text-amber-900 text-base">{tripDays} Days</strong></span>
                  <span className="text-[#7a7467]">1 to 60 days</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="60"
                  value={tripDays}
                  onChange={(e) => setTripDays(Number(e.target.value))}
                  className="w-full accent-[#1a1a1a] cursor-pointer"
                />
              </div>

              {/* Total Calculation Output */}
              <div className="p-5 rounded-xl bg-[#f0ece1] border border-[#ded9cc] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <span className="text-xs uppercase font-bold text-[#6a6457] block">Total Estimated Trip Cost ({tripDays} Days)</span>
                  <div className="font-heading text-3xl font-bold text-[#1a1a1a] mt-1">
                    ${estimatedTotalCost.toLocaleString()} <span className="text-sm font-normal text-[#7a7467]">USD</span>
                  </div>
                  <div className="text-xs text-[#7a7467] mt-0.5">
                    ≈ {(estimatedTotalCost * country.currency.rateToUSD).toLocaleString()} {country.currency.code} ({country.currency.symbol})
                  </div>
                </div>
                <div className="text-right text-xs text-[#4a473e] space-y-1">
                  <div>Hotel: <strong>{budgetTier === 'backpacker' ? 'Hostel' : budgetTier === 'midRange' ? '3-Star' : '5-Star Resort'}</strong></div>
                  <div>Food: <strong>{budgetTier === 'backpacker' ? 'Street Food' : budgetTier === 'midRange' ? 'Casual Dining' : 'Fine Dining'}</strong></div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: SAFETY & ESSENTIALS */}
          {activeTab === 'safety' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Emergency Numbers & Plugs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-3 shadow-xs">
                  <h4 className="font-heading text-sm font-bold text-[#1a1a1a] flex items-center gap-2">
                    <PhoneCall className="w-4 h-4 text-rose-700" />
                    Emergency Contacts & Helplines
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-[#f0ece1]">
                      <span className="text-[#7a7467]">Police Assistance:</span>
                      <strong className="text-rose-800 font-mono text-sm">{country.travelInfo.emergencyNumbers.police}</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-[#f0ece1]">
                      <span className="text-[#7a7467]">Medical Ambulance:</span>
                      <strong className="text-emerald-800 font-mono text-sm">{country.travelInfo.emergencyNumbers.ambulance}</strong>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-[#7a7467]">Tourist Support Line:</span>
                      <strong className="text-amber-900 font-mono">{country.travelInfo.emergencyNumbers.touristHelpline}</strong>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-3 shadow-xs">
                  <h4 className="font-heading text-sm font-bold text-[#1a1a1a] flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-700" />
                    Electricity & Plug Adapters
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="text-[#7a7467] block font-medium">Plug Socket Types:</span>
                      <strong className="text-[#1a1a1a] text-sm mt-0.5 block">{country.travelInfo.electrical.plugTypes.join(', ')}</strong>
                    </div>
                    <div>
                      <span className="text-[#7a7467] block font-medium">Standard Voltage:</span>
                      <strong className="text-teal-800 text-sm mt-0.5 block">{country.travelInfo.electrical.voltage}</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* SIM & Mobile Connectivity */}
              <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                <h4 className="font-heading text-sm font-bold text-[#1a1a1a] mb-2">SIM Cards & Internet Connectivity</h4>
                <div className="text-xs text-[#4a473e] space-y-1.5">
                  <p>• eSIM Available: <strong>{country.travelInfo.connectivity.esimRecommended ? 'Yes (Instant online activation)' : 'Physical SIM recommended'}</strong></p>
                  <p>• Top Local Carriers: <strong>{country.travelInfo.connectivity.bestLocalSIMs.join(', ')}</strong></p>
                  <p>• Wi-Fi Coverage: {country.travelInfo.connectivity.wifiAvailability}</p>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Bottom Footer */}
        <div className="px-6 py-3.5 bg-[#f0ece1] border-t border-[#e2ded5] flex items-center justify-between flex-shrink-0">
          <div className="text-xs text-[#7a7467]">
            TRIPORA Country Encyclopedia • {country.name} ({country.isoCode})
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Close Profile
          </button>
        </div>

      </div>
    </div>
  );
};
