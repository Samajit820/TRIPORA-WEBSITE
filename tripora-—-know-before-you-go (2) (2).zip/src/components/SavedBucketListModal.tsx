import React, { useState } from 'react';
import { Bookmark, X, Trash2, Download, Sparkles, MapPin, Check, ChevronRight } from 'lucide-react';

interface SavedBucketListModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedCountries: string[];
  savedCities: string[];
  savedLandmarks: string[];
  savedDestinations: string[];
  savedExperiences: string[];
  onRemoveItem: (itemType: string, name: string) => void;
  onClearAll: () => void;
}

export const SavedBucketListModal: React.FC<SavedBucketListModalProps> = ({
  isOpen,
  onClose,
  savedCountries,
  savedCities,
  savedLandmarks,
  savedDestinations,
  savedExperiences,
  onRemoveItem,
  onClearAll
}) => {
  const [personalNotes, setPersonalNotes] = useState<Record<string, string>>({});
  const [copiedPlan, setCopiedPlan] = useState(false);

  if (!isOpen) return null;

  const totalSaved =
    savedCountries.length +
    savedCities.length +
    savedLandmarks.length +
    savedDestinations.length +
    savedExperiences.length;

  const handleExportText = () => {
    let text = `TRIPORA MY PERSONAL TRAVEL BUCKET LIST:\n=====================================\n\n`;
    if (savedCountries.length > 0) text += `🌍 COUNTRIES:\n${savedCountries.map((c) => `- ${c}`).join('\n')}\n\n`;
    if (savedCities.length > 0) text += `🏙️ CITIES:\n${savedCities.map((c) => `- ${c}`).join('\n')}\n\n`;
    if (savedLandmarks.length > 0) text += `🏛️ LANDMARKS:\n${savedLandmarks.map((l) => `- ${l}`).join('\n')}\n\n`;
    if (savedDestinations.length > 0) text += `🧭 DESTINATIONS:\n${savedDestinations.map((d) => `- ${d}`).join('\n')}\n\n`;
    if (savedExperiences.length > 0) text += `✨ EXPERIENCES:\n${savedExperiences.map((e) => `- ${e}`).join('\n')}\n\n`;

    navigator.clipboard.writeText(text);
    setCopiedPlan(true);
    setTimeout(() => setCopiedPlan(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-[#fcfbf7] border-l border-[#ded9cc] shadow-2xl h-full flex flex-col justify-between z-10 animate-in slide-in-from-right duration-200 text-[#1a1a1a]">
        
        {/* Drawer Header */}
        <div className="p-6 border-b border-[#ded9cc] flex items-center justify-between bg-[#f4f1ea]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#1a1a1a] text-white">
              <Bookmark className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">My Bucket List</h3>
              <span className="text-xs text-[#615d54]">{totalSaved} Saved World Wonders</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-md bg-white border border-[#ded9cc] text-[#615d54] hover:text-[#1a1a1a] hover:bg-[#ebe7dc] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Drawer Scrollable Content */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1 text-[#2d2a24] divide-y divide-[#ebe7dc]">
          
          {totalSaved === 0 && (
            <div className="py-16 text-center text-[#807a6f]">
              <Sparkles className="w-10 h-10 mx-auto text-[#807a6f] mb-2" />
              <p className="text-sm font-bold text-[#1a1a1a]">Your Bucket List is Empty</p>
              <p className="text-xs text-[#807a6f] mt-1 max-w-xs mx-auto">
                Click the bookmark icon on any country, city, monument, or activity across TRIPORA to save it here for offline reference.
              </p>
            </div>
          )}

          {/* Countries */}
          {savedCountries.length > 0 && (
            <div className="pt-4 first:pt-0 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-900 block">
                Saved Countries ({savedCountries.length})
              </span>
              <div className="space-y-1.5">
                {savedCountries.map((countryName) => (
                  <div key={countryName} className="flex items-center justify-between p-3 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                    <span className="font-semibold text-[#1a1a1a]">🌍 {countryName}</span>
                    <button
                      onClick={() => onRemoveItem('country', countryName)}
                      className="text-[#807a6f] hover:text-rose-700 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cities */}
          {savedCities.length > 0 && (
            <div className="pt-4 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-900 block">
                Saved Cities ({savedCities.length})
              </span>
              <div className="space-y-1.5">
                {savedCities.map((cityName) => (
                  <div key={cityName} className="flex items-center justify-between p-3 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                    <span className="font-semibold text-[#1a1a1a]">🏙️ {cityName}</span>
                    <button
                      onClick={() => onRemoveItem('city', cityName)}
                      className="text-[#807a6f] hover:text-rose-700 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Landmarks */}
          {savedLandmarks.length > 0 && (
            <div className="pt-4 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-900 block">
                Saved Landmarks ({savedLandmarks.length})
              </span>
              <div className="space-y-1.5">
                {savedLandmarks.map((lmName) => (
                  <div key={lmName} className="flex items-center justify-between p-3 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                    <span className="font-semibold text-[#1a1a1a]">🏛️ {lmName}</span>
                    <button
                      onClick={() => onRemoveItem('landmark', lmName)}
                      className="text-[#807a6f] hover:text-rose-700 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Destinations */}
          {savedDestinations.length > 0 && (
            <div className="pt-4 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 block">
                Saved Destinations ({savedDestinations.length})
              </span>
              <div className="space-y-1.5">
                {savedDestinations.map((dName) => (
                  <div key={dName} className="flex items-center justify-between p-3 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                    <span className="font-semibold text-[#1a1a1a]">🧭 {dName}</span>
                    <button
                      onClick={() => onRemoveItem('destination', dName)}
                      className="text-[#807a6f] hover:text-rose-700 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Experiences */}
          {savedExperiences.length > 0 && (
            <div className="pt-4 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-900 block">
                Saved Experiences ({savedExperiences.length})
              </span>
              <div className="space-y-1.5">
                {savedExperiences.map((expName) => (
                  <div key={expName} className="flex items-center justify-between p-3 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                    <span className="font-semibold text-[#1a1a1a] truncate max-w-[240px]">✨ {expName}</span>
                    <button
                      onClick={() => onRemoveItem('experience', expName)}
                      className="text-[#807a6f] hover:text-rose-700 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Drawer Footer Actions */}
        {totalSaved > 0 && (
          <div className="p-4 bg-[#f4f1ea] border-t border-[#ded9cc] space-y-2">
            <button
              onClick={handleExportText}
              className="w-full py-2.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {copiedPlan ? <Check className="w-4 h-4" /> : <Download className="w-4 h-4" />}
              <span>{copiedPlan ? 'Copied Itinerary to Clipboard!' : 'Export Bucket List'}</span>
            </button>
            <button
              onClick={onClearAll}
              className="w-full py-2 rounded-lg bg-white hover:bg-[#ebe7dc] border border-[#ded9cc] text-[#615d54] hover:text-rose-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              Clear All Items
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
