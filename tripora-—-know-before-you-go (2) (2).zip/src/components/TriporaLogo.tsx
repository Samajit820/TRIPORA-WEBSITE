import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'light' | 'dark' | 'amber';
  showBadge?: boolean;
  animated?: boolean;
}

export const TriporaLogo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  variant = 'dark',
  showBadge = true,
  animated = true
}) => {
  // Dimension sizing map
  const sizeMap = {
    sm: { box: 'w-7 h-7 sm:w-8 sm:h-8', icon: 18, text: 'text-base sm:text-lg', badge: 'text-[8px] sm:text-[9px] px-1 py-0.2' },
    md: { box: 'w-8 h-8 sm:w-10 sm:h-10', icon: 22, text: 'text-xl sm:text-2xl', badge: 'text-[9px] sm:text-[10px] px-1.5 py-0.5' },
    lg: { box: 'w-10 h-10 sm:w-12 sm:h-12', icon: 26, text: 'text-2xl sm:text-3xl', badge: 'text-[10px] sm:text-[11px] px-2 py-0.5' },
    xl: { box: 'w-12 h-12 sm:w-16 sm:h-16', icon: 36, text: 'text-3xl sm:text-4xl', badge: 'text-xs px-2.5 py-1' }
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  return (
    <div className={`inline-flex items-center gap-2 sm:gap-3 select-none ${className}`}>
      {/* Visual Logo Emblem */}
      <div
        className={`relative flex items-center justify-center ${currentSize.box} rounded-xl bg-gradient-to-br from-[#1a1a1a] via-[#262420] to-[#0f0e0c] text-white shadow-md border border-[#3d3830] transition-all duration-300 group-hover:shadow-lg group-hover:scale-105 overflow-hidden flex-shrink-0`}
      >
        {/* Subtle geometric longitude/latitude globe grid SVG */}
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`w-full h-full p-1 sm:p-1.5 ${animated ? 'group-hover:rotate-12 transition-transform duration-500' : ''}`}
        >
          {/* Subtle Planetary Orbit Glow */}
          <circle cx="24" cy="24" r="19" stroke="currentColor" strokeWidth="1.2" strokeOpacity="0.25" />
          
          {/* Longitude Ellipses */}
          <ellipse cx="24" cy="24" rx="10" ry="19" stroke="currentColor" strokeWidth="1.2" strokeOpacity="0.45" />
          <ellipse cx="24" cy="24" rx="18" ry="8" stroke="currentColor" strokeWidth="1.2" strokeOpacity="0.35" />
          
          {/* Equator Line */}
          <line x1="5" y1="24" x2="43" y2="24" stroke="currentColor" strokeWidth="1.4" strokeOpacity="0.7" strokeDasharray="2 2" />
          
          {/* Prime Meridian */}
          <line x1="24" y1="5" x2="24" y2="43" stroke="currentColor" strokeWidth="1.4" strokeOpacity="0.7" />

          {/* Compass Star / Tripora Delta Core */}
          <path
            d="M24 10L27.5 21L38 24L27.5 27L24 38L20.5 27L10 24L20.5 21Z"
            fill="url(#tripora-gold-gradient)"
            stroke="#fef08a"
            strokeWidth="0.8"
          />

          {/* Center Beacon Pin */}
          <circle cx="24" cy="24" r="3.2" fill="#d97706" stroke="#ffffff" strokeWidth="1.2" />

          <defs>
            <linearGradient id="tripora-gold-gradient" x1="10" y1="10" x2="38" y2="38" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fbbf24" />
              <stop offset="0.5" stopColor="#f59e0b" />
              <stop offset="1" stopColor="#b45309" />
            </linearGradient>
          </defs>
        </svg>

        {/* Golden Explorer Pinpoint in corner */}
        <div className="absolute top-1 right-1 w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-amber-400 border border-[#1a1a1a] shadow-xs" />
      </div>

      {/* Brand Wordmark & Global Atlas Tag */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <span
            className={`font-heading font-black tracking-wider text-[#1a1a1a] ${currentSize.text} leading-none drop-shadow-2xs`}
          >
            TRIPORA
          </span>
          {showBadge && (
            <span
              className={`uppercase font-bold tracking-widest rounded-md bg-[#f0ece1] text-[#4a473e] border border-[#ded9cc] shadow-2xs ${currentSize.badge}`}
            >
              Atlas
            </span>
          )}
        </div>
        <span className="text-[9px] sm:text-[11px] font-semibold text-[#78716c] tracking-wider sm:tracking-widest uppercase mt-0.5 whitespace-nowrap">
          Know Before You Go
        </span>
      </div>
    </div>
  );
};
