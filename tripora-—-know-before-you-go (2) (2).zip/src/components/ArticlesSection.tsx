import React, { useState } from 'react';
import { BookOpen, Clock, Calendar, ChevronRight, X, Tag } from 'lucide-react';
import { ARTICLES_DATA } from '../data/articles';
import { Article } from '../types';

interface ArticlesSectionProps {
  onSelectArticleModal?: (articleId: string) => void;
}

export const ArticlesSection: React.FC<ArticlesSectionProps> = () => {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  return (
    <section id="articles" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <BookOpen className="w-3.5 h-3.5" />
              Chapter 10 • Editorial Guides & Deep Travel Knowledge
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              TRIPORA Travel Guides
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              Deep destination guides, hidden gems in West Bengal & India, insider Paris secrets, first-timer masterclasses in Japan, and Earth’s greatest natural wonders.
            </p>
          </div>
        </div>

        {/* Article Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-300">
          {ARTICLES_DATA.map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all cursor-pointer group flex flex-col justify-between shadow-xs"
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={article.heroImage}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-xs font-bold uppercase tracking-wider text-white">
                    {article.category}
                  </span>
                </div>

                <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-xs text-stone-200">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Clock className="w-3.5 h-3.5 text-amber-300" /> {article.readTime}
                  </span>
                  <span className="flex items-center gap-1.5 font-medium">
                    <Calendar className="w-3.5 h-3.5 text-amber-300" /> {article.publishedDate}
                  </span>
                </div>
              </div>

              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#1a1a1a] group-hover:text-[#524e44] transition-colors leading-tight mb-2">
                    {article.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#48453e] line-clamp-3 leading-relaxed">
                    {article.excerpt}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#ebe7dc] flex items-center justify-between">
                  <div className="flex flex-wrap gap-1.5">
                    {article.tags.slice(0, 3).map((tag, idx) => (
                      <span key={idx} className="text-[11px] px-2 py-0.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-[#615d54]">
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#1a1a1a] group-hover:text-amber-900">
                    Read Article <ChevronRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Full Screen Article Reading Modal */}
        {selectedArticle && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
            <div className="fixed inset-0" onClick={() => setSelectedArticle(null)} />
            
            <div className="relative w-full max-w-4xl rounded-2xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[92vh] z-10 text-[#1a1a1a]">
              
              {/* Top Banner */}
              <div className="relative h-64 sm:h-80 flex-shrink-0 overflow-hidden">
                <img src={selectedArticle.heroImage} alt={selectedArticle.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/60 to-[#1a1a1a]/10" />

                <button
                  onClick={() => setSelectedArticle(null)}
                  className="absolute top-4 right-4 p-2.5 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-white hover:bg-rose-700 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="absolute bottom-6 left-6 right-6 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-md bg-[#1a1a1a]/80 text-white text-xs font-bold uppercase">
                      {selectedArticle.category}
                    </span>
                    <span className="text-xs text-stone-200 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-amber-300" /> {selectedArticle.readTime}
                    </span>
                  </div>
                  <h2 className="font-heading text-2xl sm:text-4xl font-bold text-white leading-tight">
                    {selectedArticle.title}
                  </h2>
                  <div className="flex items-center gap-3 text-xs text-stone-300">
                    <span>By {selectedArticle.author}</span>
                    <span>•</span>
                    <span>Published {selectedArticle.publishedDate}</span>
                  </div>
                </div>
              </div>

              {/* Scrollable Reader Content */}
              <div className="overflow-y-auto p-6 sm:p-8 space-y-8 flex-1 text-[#2d2a24]">
                
                {/* Excerpt Lead */}
                <div className="p-4 rounded-xl bg-[#f8f6f0] border border-[#ded9cc] text-sm sm:text-base text-[#1a1a1a] font-medium leading-relaxed italic">
                  "{selectedArticle.excerpt}"
                </div>

                {/* Content Sections */}
                {selectedArticle.contentSections.map((sec, idx) => (
                  <div key={idx} className="space-y-3">
                    <h3 className="font-heading text-lg sm:text-xl font-bold text-[#1a1a1a]">
                      {sec.heading}
                    </h3>
                    <p className="text-sm sm:text-base text-[#4a473e] leading-relaxed">
                      {sec.body}
                    </p>
                    {sec.bullets && (
                      <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 shadow-xs">
                        <span className="text-xs uppercase font-bold text-amber-900 block">Takeaway Key Points:</span>
                        <ul className="space-y-1.5 text-xs sm:text-sm text-[#4a473e]">
                          {sec.bullets.map((b, bIdx) => (
                            <li key={bIdx} className="flex items-start gap-2">
                              <span className="text-[#1a1a1a] font-bold">•</span>
                              <span>{b}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}

                {/* Tags */}
                <div className="pt-4 border-t border-[#ebe7dc] flex items-center gap-2">
                  <Tag className="w-4 h-4 text-[#807a6f]" />
                  <div className="flex flex-wrap gap-1.5">
                    {selectedArticle.tags.map((t, i) => (
                      <span key={i} className="text-xs px-2.5 py-1 rounded-md bg-[#f0ece1] border border-[#ebe7dc] text-[#4a473e]">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Reader Footer */}
              <div className="px-6 py-3 bg-[#f0ece1] border-t border-[#e2ded5] flex items-center justify-between">
                <span className="text-xs text-[#615d54]">TRIPORA Global Travel Knowledge</span>
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  Close Guide
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
