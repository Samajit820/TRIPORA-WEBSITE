import React, { useState } from 'react';
import { Globe, Compass, Mountain, Waves, MapPin, CheckCircle2, ChevronRight, Layers, ArrowUpRight } from 'lucide-react';
import { CONTINENTS, OCEANS_SEAS, GEOGRAPHIC_FEATURES, EARTH_LINES } from '../data/continents';
import { ContinentCode } from '../types';

interface EarthExplorerProps {
  onSelectContinent: (continentId: ContinentCode) => void;
}

type HemisphereType = 'northern' | 'southern' | 'eastern' | 'western';

export const EarthExplorer: React.FC<EarthExplorerProps> = ({ onSelectContinent }) => {
  const [activeTab, setActiveTab] = useState<'continents' | 'map' | 'oceans' | 'features' | 'lines'>('continents');
  const [selectedContinent, setSelectedContinent] = useState<ContinentCode>('asia');
  const [activeHemisphere, setActiveHemisphere] = useState<HemisphereType>('northern');
  const [activeOverlay, setActiveOverlay] = useState<'equator' | 'tropics' | 'meridian' | 'none'>('equator');

  const currentContinentData = CONTINENTS.find((c) => c.id === selectedContinent) || CONTINENTS[0];

  const hemisphereData: Record<HemisphereType, { name: string; description: string; landPercent: string; populationPercent: string; keyPoints: string[] }> = {
    northern: {
      name: 'Northern Hemisphere',
      description: 'Contains roughly 68% of the Earth’s total land area and is home to approximately 87-90% of the entire human population.',
      landPercent: '68% of Earth landmass',
      populationPercent: '~88% of human population',
      keyPoints: ['Includes all of North America & Europe, most of Asia and Africa, and small part of South America.', 'Features the Arctic Circle, North Pole, and Aurora Borealis.']
    },
    southern: {
      name: 'Southern Hemisphere',
      description: 'Dominated by vast oceans (81% water surface), housing pristine wildernesses, Antarctica, Australia, and southern tips of Africa and South America.',
      landPercent: '32% of Earth landmass (dominated by oceans)',
      populationPercent: '~12% of human population',
      keyPoints: ['Includes Australia, Antarctica, majority of South America, and one-third of Africa.', 'Experiences inverted seasons (Winter in June–August, Summer in Dec–Feb).', 'Features the Southern Cross constellation and Aurora Australis.']
    },
    eastern: {
      name: 'Eastern Hemisphere ("The Old World")',
      description: 'Lies east of the Prime Meridian and west of the 180th meridian, containing Eurasia, Africa, and Australia.',
      landPercent: 'Vast land connectivity across Afro-Eurasia',
      populationPercent: '~85% of human population',
      keyPoints: ['Birthplace of the world’s oldest recorded civilizations (Mesopotamia, Indus Valley, Nile, Yellow River).']
    },
    western: {
      name: 'Western Hemisphere ("The Americas / New World")',
      description: 'Lies west of the Prime Meridian, encompassing North and South America and parts of the Atlantic and Pacific oceans.',
      landPercent: 'Extends from Greenland and Arctic Canada down to Cape Horn',
      populationPercent: '~15% of human population',
      keyPoints: ['Houses the Andes mountain spine, the Amazon basin, Great Lakes, and Caribbean archipelago.']
    }
  };

  return (
    <section id="earth" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative overflow-hidden border-b border-[#e7e4dc]">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Globe className="w-3.5 h-3.5" />
              Chapter 01 • Planetary Geography
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Explore Earth
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              An interactive overview of Earth's 7 continents, oceans, geographic coordinates, planetary hemispheres, and monumental physical features.
            </p>
          </div>

          {/* Module Switcher Tabs */}
          <div className="flex items-center gap-1 p-1 rounded-lg bg-[#f0ece1] border border-[#e2ded5] overflow-x-auto scrollbar-none">
            {[
              { id: 'continents', label: '7 Continents', icon: Compass },
              { id: 'map', label: 'Interactive Map & Hemispheres', icon: Globe },
              { id: 'oceans', label: 'Oceans & Seas', icon: Waves },
              { id: 'features', label: 'Geographic Features', icon: Mountain },
              { id: 'lines', label: 'Equator & Tropics', icon: Layers }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-md text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-[#1a1a1a] text-[#fcfbf7] shadow-xs'
                      : 'text-[#5e5a51] hover:text-[#1a1a1a] hover:bg-[#e6e2d6]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* TAB 1: 7 Continents Interactive Showcase */}
        {activeTab === 'continents' && (
          <div className="space-y-8 animate-in fade-in duration-300">
            
            {/* Continent Selector Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
              {CONTINENTS.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedContinent(c.id)}
                  className={`p-3 rounded-lg border text-left transition-all relative overflow-hidden cursor-pointer ${
                    selectedContinent === c.id
                      ? 'bg-[#1a1a1a] border-[#1a1a1a] text-[#fcfbf7] shadow-sm'
                      : 'bg-white border-[#e7e4dc] text-[#555148] hover:text-[#1a1a1a] hover:border-[#cbc6b8]'
                  }`}
                >
                  <div className="text-xs uppercase font-bold tracking-wider">{c.name}</div>
                  <div className={`text-[11px] mt-0.5 ${selectedContinent === c.id ? 'text-[#e5dfd3]' : 'text-[#878072]'}`}>
                    {c.countriesCount > 0 ? `${c.countriesCount} Countries` : 'Polar Territory'}
                  </div>
                  {selectedContinent === c.id && (
                    <div className="absolute top-0 right-0 w-1.5 h-full bg-amber-500" />
                  )}
                </button>
              ))}
            </div>

            {/* Selected Continent Deep Detail Card */}
            <div className="grid grid-cols-1 lg:grid-cols-12 rounded-2xl bg-white border border-[#e7e4dc] overflow-hidden shadow-xs">
              
              {/* Left Photo & Visual Highlights */}
              <div className="lg:col-span-5 relative min-h-[320px] lg:min-h-full">
                <img
                  src={currentContinentData.image}
                  alt={currentContinentData.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/90 via-[#1a1a1a]/30 to-transparent" />
                
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="text-xs uppercase font-bold tracking-widest text-amber-300 mb-1">
                    Continent Overview
                  </div>
                  <h3 className="font-heading text-3xl font-bold text-white">
                    {currentContinentData.name}
                  </h3>
                  <p className="text-xs text-stone-200 mt-1 font-medium italic">
                    "{currentContinentData.tagline}"
                  </p>
                </div>
              </div>

              {/* Right Content & Key Metrics */}
              <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div>
                  <p className="text-sm sm:text-base text-[#38352f] leading-relaxed">
                    {currentContinentData.overview}
                  </p>

                  {/* Fact Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6">
                    <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                      <div className="text-[10px] uppercase font-bold text-[#807a6f]">Total Population</div>
                      <div className="text-xs sm:text-sm font-bold text-[#1a1a1a] mt-0.5">{currentContinentData.population}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                      <div className="text-[10px] uppercase font-bold text-[#807a6f]">Land Area</div>
                      <div className="text-xs sm:text-sm font-bold text-[#1a1a1a] mt-0.5">{currentContinentData.area}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                      <div className="text-[10px] uppercase font-bold text-[#807a6f]">Largest Metropolis</div>
                      <div className="text-xs sm:text-sm font-bold text-[#1a1a1a] mt-0.5">{currentContinentData.largestCity}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                      <div className="text-[10px] uppercase font-bold text-[#807a6f]">Highest Point</div>
                      <div className="text-xs sm:text-sm font-bold text-amber-800 mt-0.5">{currentContinentData.highestPoint}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                      <div className="text-[10px] uppercase font-bold text-[#807a6f]">Lowest Point</div>
                      <div className="text-xs sm:text-sm font-bold text-sky-800 mt-0.5">{currentContinentData.lowestPoint}</div>
                    </div>
                    <div className="p-3 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                      <div className="text-[10px] uppercase font-bold text-[#807a6f]">Climate System</div>
                      <div className="text-xs sm:text-sm font-bold text-[#1a1a1a] mt-0.5 truncate">{currentContinentData.climateSummary}</div>
                    </div>
                  </div>

                  {/* Highlights Bullet Tags */}
                  <div className="mt-6">
                    <div className="text-xs font-bold uppercase tracking-wider text-[#807a6f] mb-2">
                      Continental Icons & Highlights:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {currentContinentData.highlights.map((h, i) => (
                        <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#dfdbce] text-xs text-[#3b3830] font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5 text-amber-700" />
                          {h}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Direct Action Link to Countries of this continent */}
                <div className="pt-4 border-t border-[#ebe7dc] flex items-center justify-between">
                  <span className="text-xs text-[#6e685c]">
                    Discover all {currentContinentData.countriesCount} nations in {currentContinentData.name}
                  </span>
                  <a
                    href="#countries"
                    onClick={() => onSelectContinent(currentContinentData.id)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-[#fcfbf7] font-semibold text-xs transition-colors"
                  >
                    <span>Browse {currentContinentData.name} Countries</span>
                    <ChevronRight className="w-4 h-4" />
                  </a>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* TAB 2: Interactive Earth Map & Hemispheres */}
        {activeTab === 'map' && (
          <div className="space-y-8 animate-in fade-in duration-300">
            
            {/* Hemisphere Switcher */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#736d62] mr-2">
                  Select Hemisphere:
                </span>
                {(['northern', 'southern', 'eastern', 'western'] as HemisphereType[]).map((hemi) => (
                  <button
                    key={hemi}
                    onClick={() => setActiveHemisphere(hemi)}
                    className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors capitalize cursor-pointer ${
                      activeHemisphere === hemi
                        ? 'bg-[#1a1a1a] text-white'
                        : 'bg-[#f4f1ea] text-[#4f4b42] hover:bg-[#eae6dc]'
                    }`}
                  >
                    {hemi}
                  </button>
                ))}
              </div>

              {/* Grid line overlay toggles */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#736d62]">Coordinate Lines:</span>
                <button
                  onClick={() => setActiveOverlay(activeOverlay === 'equator' ? 'none' : 'equator')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-colors cursor-pointer ${
                    activeOverlay === 'equator'
                      ? 'bg-rose-50 border-rose-300 text-rose-800'
                      : 'bg-[#f4f1ea] border-[#ded9cc] text-[#555148]'
                  }`}
                >
                  Equator (0°)
                </button>
                <button
                  onClick={() => setActiveOverlay(activeOverlay === 'tropics' ? 'none' : 'tropics')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-colors cursor-pointer ${
                    activeOverlay === 'tropics'
                      ? 'bg-amber-50 border-amber-300 text-amber-800'
                      : 'bg-[#f4f1ea] border-[#ded9cc] text-[#555148]'
                  }`}
                >
                  Tropics (23.5°)
                </button>
                <button
                  onClick={() => setActiveOverlay(activeOverlay === 'meridian' ? 'none' : 'meridian')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border transition-colors cursor-pointer ${
                    activeOverlay === 'meridian'
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                      : 'bg-[#f4f1ea] border-[#ded9cc] text-[#555148]'
                  }`}
                >
                  Prime Meridian (0° Long)
                </button>
              </div>
            </div>

            {/* Interactive Graphic Map Stage */}
            <div className="relative rounded-2xl bg-white border border-[#e7e4dc] p-6 sm:p-8 overflow-hidden shadow-xs">
              
              {/* World SVG Map Diagram */}
              <div className="relative w-full aspect-[2/1] max-h-[460px] bg-[#f7f5ee] rounded-xl border border-[#e5e1d7] overflow-hidden flex items-center justify-center p-4">
                
                {/* SVG Coordinate Grid and Continents */}
                <svg viewBox="0 0 1000 500" className="w-full h-full">
                  {/* Grid Lines */}
                  <defs>
                    <pattern id="grid" width="100" height="50" patternUnits="userSpaceOnUse">
                      <path d="M 100 0 L 0 0 0 50" fill="none" stroke="rgba(0,0,0,0.06)" strokeWidth="1" />
                    </pattern>
                  </defs>
                  <rect width="1000" height="500" fill="url(#grid)" />

                  {/* Continents Simplified Stylized Outlines */}
                  {/* North America */}
                  <path
                    d="M 120 70 Q 220 50 280 90 L 320 160 Q 250 220 180 220 L 130 160 Z"
                    className="fill-[#ded9cb] hover:fill-[#cfc7b4] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('north-america')}
                  >
                    <title>North America</title>
                  </path>
                  {/* South America */}
                  <path
                    d="M 230 250 Q 330 280 300 390 L 250 460 Q 210 360 220 280 Z"
                    className="fill-[#ded9cb] hover:fill-[#cfc7b4] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('south-america')}
                  >
                    <title>South America</title>
                  </path>
                  {/* Europe */}
                  <path
                    d="M 450 80 Q 560 70 560 140 L 480 170 Q 420 140 450 80 Z"
                    className="fill-[#ded9cb] hover:fill-[#cfc7b4] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('europe')}
                  >
                    <title>Europe</title>
                  </path>
                  {/* Africa */}
                  <path
                    d="M 460 180 Q 580 180 560 290 L 520 400 Q 450 330 450 240 Z"
                    className="fill-[#ded9cb] hover:fill-[#cfc7b4] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('africa')}
                  >
                    <title>Africa</title>
                  </path>
                  {/* Asia */}
                  <path
                    d="M 570 70 Q 860 60 880 180 L 740 280 Q 600 250 570 140 Z"
                    className="fill-[#ded9cb] hover:fill-[#cfc7b4] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('asia')}
                  >
                    <title>Asia</title>
                  </path>
                  {/* Australia / Oceania */}
                  <path
                    d="M 780 320 Q 900 320 890 400 L 800 420 Q 750 360 780 320 Z"
                    className="fill-[#ded9cb] hover:fill-[#cfc7b4] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('oceania')}
                  >
                    <title>Australia & Oceania</title>
                  </path>
                  {/* Antarctica */}
                  <path
                    d="M 100 480 Q 500 470 900 480 L 950 500 L 50 500 Z"
                    className="fill-[#e5e1d5] hover:fill-[#d5d0c2] stroke-[#c0b9a6] stroke-1 cursor-pointer transition-colors"
                    onClick={() => onSelectContinent('antarctica')}
                  >
                    <title>Antarctica</title>
                  </path>

                  {/* Overlays */}
                  {/* Equator (0° Latitude) */}
                  {(activeOverlay === 'equator' || activeOverlay === 'tropics') && (
                    <line x1="0" y1="250" x2="1000" y2="250" stroke="#e11d48" strokeWidth="2" strokeDasharray="6,4" />
                  )}
                  {/* Tropic of Cancer (23.5° N) */}
                  {activeOverlay === 'tropics' && (
                    <line x1="0" y1="185" x2="1000" y2="185" stroke="#d97706" strokeWidth="1.5" strokeDasharray="4,4" />
                  )}
                  {/* Tropic of Capricorn (23.5° S) */}
                  {activeOverlay === 'tropics' && (
                    <line x1="0" y1="315" x2="1000" y2="315" stroke="#d97706" strokeWidth="1.5" strokeDasharray="4,4" />
                  )}
                  {/* Prime Meridian (0° Longitude) */}
                  {activeOverlay === 'meridian' && (
                    <line x1="480" y1="0" x2="480" y2="500" stroke="#059669" strokeWidth="2" strokeDasharray="6,4" />
                  )}

                  {/* Coordinate Labels */}
                  <text x="15" y="245" fill="#e11d48" fontSize="12" fontWeight="bold">0° Equator</text>
                  {activeOverlay === 'tropics' && (
                    <>
                      <text x="15" y="180" fill="#d97706" fontSize="11" fontWeight="bold">23.5°N Tropic of Cancer</text>
                      <text x="15" y="310" fill="#d97706" fontSize="11" fontWeight="bold">23.5°S Tropic of Capricorn</text>
                    </>
                  )}
                  {activeOverlay === 'meridian' && (
                    <text x="485" y="20" fill="#059669" fontSize="11" fontWeight="bold">0° Prime Meridian (Greenwich)</text>
                  )}

                  {/* Interactive Hotspot Pins */}
                  <g className="cursor-pointer" onClick={() => onSelectContinent('asia')}>
                    <circle cx="710" cy="170" r="4" fill="#b45309" />
                    <text x="720" y="175" fill="#1a1a1a" fontSize="11" fontWeight="bold">Himalayas (8,848m)</text>
                  </g>

                  <g className="cursor-pointer" onClick={() => onSelectContinent('south-america')}>
                    <circle cx="280" cy="300" r="4" fill="#0369a1" />
                    <text x="290" y="305" fill="#1a1a1a" fontSize="11" fontWeight="bold">Amazon Basin</text>
                  </g>

                  <g className="cursor-pointer" onClick={() => onSelectContinent('africa')}>
                    <circle cx="500" cy="220" r="4" fill="#b45309" />
                    <text x="510" y="225" fill="#1a1a1a" fontSize="11" fontWeight="bold">Sahara Desert</text>
                  </g>

                  <g className="cursor-pointer" onClick={() => onSelectContinent('oceania')}>
                    <circle cx="860" cy="340" r="4" fill="#0369a1" />
                    <text x="830" y="330" fill="#1a1a1a" fontSize="11" fontWeight="bold">Great Barrier Reef</text>
                  </g>
                </svg>

              </div>

              {/* Hemisphere Info Box */}
              <div className="mt-6 p-5 rounded-xl bg-[#f8f6f0] border border-[#ebe7dc]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="font-heading text-lg font-bold text-[#1a1a1a] flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-700" />
                    {hemisphereData[activeHemisphere].name}
                  </h4>
                  <div className="flex items-center gap-4 text-xs font-semibold text-[#45423a]">
                    <span className="px-2.5 py-1 rounded-md bg-white border border-[#ded9cc] text-[#1a1a1a]">{hemisphereData[activeHemisphere].landPercent}</span>
                    <span className="px-2.5 py-1 rounded-md bg-white border border-[#ded9cc] text-[#1a1a1a]">{hemisphereData[activeHemisphere].populationPercent}</span>
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-[#403d36] mt-2 leading-relaxed">
                  {hemisphereData[activeHemisphere].description}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {hemisphereData[activeHemisphere].keyPoints.map((pt, idx) => (
                    <span key={idx} className="text-xs text-[#524e45] bg-white px-3 py-1 rounded-md border border-[#e2ded5]">
                      • {pt}
                    </span>
                  ))}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 3: Oceans & Seas */}
        {activeTab === 'oceans' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {OCEANS_SEAS.map((ocean) => (
              <div key={ocean.id} className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden group hover:border-[#c5bea] transition-all flex flex-col justify-between shadow-xs">
                <div className="relative h-44 overflow-hidden">
                  <img src={ocean.image} alt={ocean.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/20 to-transparent" />
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold text-white uppercase tracking-wider">
                    {ocean.type}
                  </div>
                  <div className="absolute bottom-3 left-4 right-4">
                    <h3 className="font-heading text-xl font-bold text-white">{ocean.name}</h3>
                  </div>
                </div>
                <div className="p-5 space-y-4">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                      <span className="text-[10px] uppercase text-[#807a6f] font-semibold block">Total Area</span>
                      <span className="font-bold text-[#1a1a1a]">{ocean.area}</span>
                    </div>
                    <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                      <span className="text-[10px] uppercase text-[#807a6f] font-semibold block">Average Depth</span>
                      <span className="font-bold text-[#1a1a1a]">{ocean.averageDepth}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-[#807a6f] font-bold block mb-1">Deepest Trench</span>
                    <span className="text-xs font-bold text-sky-900">{ocean.deepestPoint}</span>
                  </div>
                  <div className="space-y-1 text-xs text-[#4f4b42]">
                    {ocean.keyFacts.map((f, i) => (
                      <p key={i} className="text-[11px] text-[#555148] flex items-start gap-1.5 leading-relaxed">
                        <span className="text-amber-800 mt-0.5">•</span>
                        {f}
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 4: Geographic Features */}
        {activeTab === 'features' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {GEOGRAPHIC_FEATURES.map((feat) => (
              <div key={feat.id} className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all flex flex-col justify-between shadow-xs">
                <div className="relative h-44 overflow-hidden">
                  <img src={feat.image} alt={feat.name} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/20 to-transparent" />
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 text-[10px] font-bold text-white uppercase tracking-wider">
                    {feat.type}
                  </div>
                  <div className="absolute bottom-3 left-4 right-4">
                    <h3 className="font-heading text-lg font-bold text-white">{feat.name}</h3>
                    <span className="text-xs text-stone-200">{feat.location}</span>
                  </div>
                </div>
                <div className="p-5 space-y-3">
                  <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                    <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Key Dimension / Metric</span>
                    <span className="text-xs font-bold text-[#1a1a1a]">{feat.keyMetric}</span>
                  </div>
                  <p className="text-xs text-[#48453e] leading-relaxed">
                    {feat.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 5: Equator, Tropics & Prime Meridian */}
        {activeTab === 'lines' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-300">
            {EARTH_LINES.map((line, idx) => (
              <div key={idx} className="p-6 rounded-xl bg-white border border-[#e7e4dc] space-y-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading text-xl font-bold text-[#1a1a1a] flex items-center gap-2">
                    <Layers className="w-5 h-5 text-amber-800" />
                    {line.name}
                  </h3>
                  <span className="px-2.5 py-1 rounded-md bg-[#f4f1ea] border border-[#ded9cc] text-xs font-mono font-bold text-[#1a1a1a]">
                    {line.lat}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#48453e] leading-relaxed">
                  {line.description}
                </p>
                <div className="p-3 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs">
                  <span className="text-[10px] uppercase font-bold text-[#807a6f] block mb-1">Passes Through Nations</span>
                  <span className="text-[#36342e]">{line.passesThrough}</span>
                </div>
                <div className="text-[11px] text-[#6b6559] font-mono">
                  Circumference / Length: <strong className="text-[#1a1a1a]">{line.length}</strong>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
