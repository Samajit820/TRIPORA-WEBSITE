import React, { useState } from 'react';
import { Compass, Clock, Mountain, Train, Car, Sparkles, ChevronRight, Bookmark } from 'lucide-react';
import { EXPERIENCES_DATA } from '../data/experiences';
import { ActivityExperience } from '../types';

interface ExperiencesSectionProps {
  onToggleSave: (title: string) => void;
  savedItems: string[];
}

export const ExperiencesSection: React.FC<ExperiencesSectionProps> = ({
  onToggleSave,
  savedItems
}) => {
  const [selectedExperience, setSelectedExperience] = useState<ActivityExperience | null>(null);

  return (
    <section id="experiences" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Compass className="w-3.5 h-3.5" />
              Chapter 08 • Legendary Activities & Expeditions
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Curated Travel Experiences
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              From the world’s slowest panoramic express train in the Swiss Alps to trekking the Inca Trail and sunrise ballooning over Cappadocia.
            </p>
          </div>
        </div>

        {/* Experiences Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
          {EXPERIENCES_DATA.map((exp) => {
            const isSaved = savedItems.includes(exp.title);
            return (
              <div
                key={exp.id}
                className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs"
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden cursor-pointer" onClick={() => setSelectedExperience(exp)}>
                  <img src={exp.image} alt={exp.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />

                  <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                      {exp.category}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-stone-900/80 border border-stone-700 text-[9px] font-bold text-amber-200">
                      {exp.difficulty}
                    </span>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleSave(exp.title);
                    }}
                    className={`absolute top-3.5 right-3.5 p-2 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                      isSaved
                        ? 'bg-[#1a1a1a] text-white'
                        : 'bg-[#1a1a1a]/70 text-stone-200 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>

                  <div className="absolute bottom-3 left-4 right-4">
                    <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                      {exp.country} • {exp.location}
                    </div>
                    <h3 className="font-heading text-lg font-bold text-white group-hover:text-amber-200 transition-colors">
                      {exp.title}
                    </h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  <p className="text-xs text-[#48453e] line-clamp-2 leading-relaxed">
                    {exp.description}
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                      <span className="text-[9px] uppercase text-[#807a6f] block font-semibold">Duration</span>
                      <strong className="text-[#1a1a1a] text-xs block truncate">{exp.duration}</strong>
                    </div>
                    <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                      <span className="text-[9px] uppercase text-[#807a6f] block font-semibold">Best Window</span>
                      <strong className="text-emerald-800 text-xs block truncate">{exp.bestMonths.split('(')[0]}</strong>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedExperience(exp)}
                    className="w-full py-2.5 rounded-lg bg-[#f4f1ea] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>View Expedition Guide</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal */}
        {selectedExperience && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
            <div className="fixed inset-0" onClick={() => setSelectedExperience(null)} />
            <div className="relative w-full max-w-3xl rounded-2xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] z-10 text-[#1a1a1a]">
              <div className="relative h-64 flex-shrink-0">
                <img src={selectedExperience.image} alt={selectedExperience.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/40 to-transparent" />
                <button
                  onClick={() => setSelectedExperience(null)}
                  className="absolute top-4 right-4 p-2 rounded-md bg-[#1a1a1a]/80 text-white hover:bg-rose-700 transition-colors cursor-pointer"
                >
                  ✕
                </button>
                <div className="absolute bottom-4 left-6 right-6">
                  <span className="text-xs uppercase font-bold text-amber-300">{selectedExperience.country} • {selectedExperience.location}</span>
                  <h2 className="font-heading text-2xl sm:text-3xl font-bold text-white">{selectedExperience.title}</h2>
                </div>
              </div>

              <div className="p-6 overflow-y-auto space-y-4 text-[#2d2a24] text-xs sm:text-sm">
                <div>
                  <h4 className="font-bold text-[#1a1a1a] uppercase text-xs tracking-wider mb-1">Expedition Overview</h4>
                  <p className="text-[#4a473e] leading-relaxed">{selectedExperience.description}</p>
                </div>

                <div className="p-4 rounded-xl bg-[#eef7f9] border border-[#bce4eb] text-[#0d3b45]">
                  <strong className="block text-[#1a1a1a] mb-1">💡 Insider Booking Advice:</strong>
                  {selectedExperience.tips}
                </div>

                <div>
                  <h4 className="font-bold text-[#1a1a1a] uppercase text-xs tracking-wider mb-2">Key Highlights</h4>
                  <div className="space-y-1.5">
                    {selectedExperience.highlights.map((h, i) => (
                      <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                        <span className="text-teal-800 font-bold">•</span>
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[#7a7467] block text-[10px] uppercase font-bold">Total Duration:</span>
                    <strong className="text-[#1a1a1a] text-sm">{selectedExperience.duration}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[#7a7467] block text-[10px] uppercase font-bold">Best Months:</span>
                    <strong className="text-emerald-800 text-sm">{selectedExperience.bestMonths}</strong>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#f0ece1] border-t border-[#e2ded5] flex justify-end">
                <button
                  onClick={() => setSelectedExperience(null)}
                  className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
