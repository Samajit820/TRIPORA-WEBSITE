import React, { useState, useMemo } from 'react';
import {
  Briefcase, DollarSign, ShieldAlert, HelpCircle, Check, Copy, Plus,
  Trash2, RefreshCw, ChevronDown, ChevronUp, ExternalLink, Sparkles
} from 'lucide-react';
import { PACKING_ITEMS_DATABASE, VISA_DESTINATIONS_DATA, GENERAL_TRAVEL_FAQS } from '../data/planners';
import { PackingItem, TripType } from '../types';

export const TravelToolkit: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'packing' | 'budget' | 'visa' | 'faq'>('packing');

  // SMART PACKING STATE
  const [selectedTripType, setSelectedTripType] = useState<TripType>('General');
  const [customItemInput, setCustomItemInput] = useState('');
  const [checkedItemIds, setCheckedItemIds] = useState<string[]>([]);
  const [copiedPacking, setCopiedPacking] = useState(false);
  const [customItems, setCustomItems] = useState<PackingItem[]>([]);

  // BUDGET CALCULATOR STATE
  const [budgetStyle, setBudgetStyle] = useState<'budget' | 'mid' | 'luxury'>('mid');
  const [tripRegion, setTripRegion] = useState<'sea' | 'weu' | 'na' | 'sa' | 'sas' | 'me'>('sea');
  const [numDays, setNumDays] = useState(7);
  const [numTravelers, setNumTravelers] = useState(2);
  const [targetCurrency, setTargetCurrency] = useState<'USD' | 'EUR' | 'INR' | 'GBP' | 'JPY'>('USD');

  // VISA SEARCH STATE
  const [visaSearch, setVisaSearch] = useState('');

  // FAQ EXPANDED STATE
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('faq-1');

  // PACKING LOGIC
  const currentPackingList = useMemo(() => {
    const defaultFiltered = PACKING_ITEMS_DATABASE.filter(
      (item) => item.tripTypes.includes('General') || item.tripTypes.includes(selectedTripType)
    );
    return [...defaultFiltered, ...customItems];
  }, [selectedTripType, customItems]);

  const toggleCheckItem = (id: string) => {
    if (checkedItemIds.includes(id)) {
      setCheckedItemIds(checkedItemIds.filter((itemId) => itemId !== id));
    } else {
      setCheckedItemIds([...checkedItemIds, id]);
    }
  };

  const handleAddCustomItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customItemInput.trim()) return;
    const newItem: PackingItem = {
      id: `custom-${Date.now()}`,
      name: customItemInput.trim(),
      category: 'Custom',
      tripTypes: [selectedTripType],
      essential: true
    };
    setCustomItems([...customItems, newItem]);
    setCustomItemInput('');
  };

  const handleCopyPackingList = () => {
    const lines = currentPackingList.map(
      (item) => `${checkedItemIds.includes(item.id) ? '[✓]' : '[ ]'} ${item.name} (${item.category})`
    );
    const text = `TRIPORA Smart Packing List (${selectedTripType} Trip):\n\n` + lines.join('\n');
    navigator.clipboard.writeText(text);
    setCopiedPacking(true);
    setTimeout(() => setCopiedPacking(false), 2000);
  };

  const packedCount = currentPackingList.filter((item) => checkedItemIds.includes(item.id)).length;
  const progressPercent = currentPackingList.length > 0 ? Math.round((packedCount / currentPackingList.length) * 100) : 0;

  // BUDGET CALCULATOR MATH
  // Base daily cost in USD per person by region & style
  const regionRates: Record<string, { name: string; budget: number; mid: number; luxury: number }> = {
    sea: { name: 'Southeast Asia (Thailand, Vietnam, Bali)', budget: 35, mid: 90, luxury: 250 },
    sas: { name: 'South Asia (India, Sri Lanka, Nepal)', budget: 25, mid: 70, luxury: 200 },
    weu: { name: 'Western Europe (France, Italy, Switzerland)', budget: 85, mid: 220, luxury: 550 },
    na: { name: 'North America (USA, Canada)', budget: 95, mid: 250, luxury: 600 },
    sa: { name: 'South America (Peru, Brazil, Argentina)', budget: 45, mid: 120, luxury: 300 },
    me: { name: 'Middle East (UAE, Oman, Jordan)', budget: 70, mid: 180, luxury: 450 }
  };

  const currencyRates: Record<string, { symbol: string; rate: number }> = {
    USD: { symbol: '$', rate: 1 },
    EUR: { symbol: '€', rate: 0.92 },
    INR: { symbol: '₹', rate: 86.5 },
    GBP: { symbol: '£', rate: 0.79 },
    JPY: { symbol: '¥', rate: 153.2 }
  };

  const activeRegionData = regionRates[tripRegion];
  const dailyPersonUSD = activeRegionData[budgetStyle];
  const totalTripUSD = dailyPersonUSD * numDays * numTravelers;
  
  const convertedTotal = Math.round(totalTripUSD * currencyRates[targetCurrency].rate);
  const curSymbol = currencyRates[targetCurrency].symbol;

  const lodgingPortion = Math.round(convertedTotal * 0.42);
  const foodPortion = Math.round(convertedTotal * 0.28);
  const transportPortion = Math.round(convertedTotal * 0.15);
  const activitiesPortion = Math.round(convertedTotal * 0.10);
  const bufferPortion = Math.round(convertedTotal * 0.05);

  // VISA FILTER
  const filteredVisas = VISA_DESTINATIONS_DATA.filter((v) =>
    v.country.toLowerCase().includes(visaSearch.toLowerCase()) ||
    v.validPassports.toLowerCase().includes(visaSearch.toLowerCase())
  );

  return (
    <section id="planners" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Briefcase className="w-3.5 h-3.5" />
              Chapter 09 • Smart Travel Toolkit
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Travel Planners & Utilities
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              Equip yourself with smart packing checklists, multi-currency budget calculators, global visa advisors, and traveler FAQ guides.
            </p>
          </div>

          {/* Module Selector */}
          <div className="flex items-center p-1 bg-[#f0ece1] border border-[#ded9cc] rounded-lg overflow-x-auto scrollbar-none">
            {[
              { id: 'packing', label: '🎒 Smart Packing', icon: Briefcase },
              { id: 'budget', label: '💰 Budget Calculator', icon: DollarSign },
              { id: 'visa', label: '🛂 Visa Advisor', icon: ShieldAlert },
              { id: 'faq', label: '❓ Travel FAQs', icon: HelpCircle }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-md text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'text-[#615d54] hover:text-[#1a1a1a]'
                }`}
              >
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* TAB 1: SMART PACKING CHECKLIST GENERATOR */}
        {activeTab === 'packing' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-300">
            
            {/* Left Controls & Progress */}
            <div className="lg:col-span-4 space-y-6">
              <div className="p-6 rounded-xl bg-white border border-[#e7e4dc] space-y-5 shadow-xs">
                <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">1. Select Trip Style</h3>
                <div className="grid grid-cols-2 gap-2">
                  {(['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'] as TripType[]).map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedTripType(type)}
                      className={`p-3 rounded-lg border text-xs font-semibold text-left transition-all cursor-pointer ${
                        selectedTripType === type
                          ? 'bg-[#1a1a1a] text-white border-[#1a1a1a]'
                          : 'bg-[#fcfbf7] border-[#e7e4dc] text-[#4a473e] hover:bg-[#f4f1ea]'
                      }`}
                    >
                      {type === 'Beach' ? '🏖️ Beach' : type === 'Hiking' ? '🥾 Hiking' : type === 'Winter' ? '❄️ Winter' : type === 'City' ? '🏙️ City' : type === 'Backpacking' ? '🎒 Backpacking' : '✈️ General'}
                    </button>
                  ))}
                </div>

                {/* Progress Bar */}
                <div className="space-y-2 pt-2 border-t border-[#ebe7dc]">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-[#615d54]">Packing Progress</span>
                    <span className="text-[#1a1a1a]">{packedCount} of {currentPackingList.length} items ({progressPercent}%)</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#f0ece1] overflow-hidden border border-[#ded9cc]">
                    <div
                      className="h-full bg-[#1a1a1a] transition-all duration-300 rounded-full"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Add Custom Item */}
                <form onSubmit={handleAddCustomItem} className="pt-2 border-t border-[#ebe7dc] space-y-2">
                  <span className="text-xs font-semibold text-[#807a6f] block">Add Custom Item:</span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customItemInput}
                      onChange={(e) => setCustomItemInput(e.target.value)}
                      placeholder="e.g. Scuba logbook, drone..."
                      className="flex-1 px-3 py-2 bg-[#fcfbf7] border border-[#d8d3c5] rounded-lg text-xs text-[#1a1a1a] focus:outline-none focus:border-[#1a1a1a]"
                    />
                    <button
                      type="submit"
                      className="p-2 bg-[#1a1a1a] hover:bg-[#33302a] text-white rounded-lg font-semibold cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </form>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleCopyPackingList}
                    className="flex-1 py-2.5 rounded-lg bg-[#f0ece1] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedPacking ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedPacking ? 'Copied Checklist!' : 'Copy to Clipboard'}</span>
                  </button>
                  <button
                    onClick={() => setCheckedItemIds([])}
                    className="p-2.5 rounded-lg bg-[#f0ece1] hover:bg-[#1a1a1a] hover:text-white text-[#615d54] cursor-pointer transition-colors"
                    title="Reset checklist"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Right Interactive Checklist Grid */}
            <div className="lg:col-span-8 p-6 rounded-xl bg-white border border-[#e7e4dc] space-y-6 shadow-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-heading text-xl font-bold text-[#1a1a1a]">
                    {selectedTripType} Packing Checklist
                  </h3>
                  <span className="text-xs text-[#615d54]">Click items as you pack them into your suitcase</span>
                </div>
              </div>

              {/* Group by category */}
              {['Documents', 'Electronics', 'Clothing', 'Footwear', 'Health & Safety', 'Outdoor Gear', 'Custom'].map((cat) => {
                const itemsInCat = currentPackingList.filter((it) => it.category === cat);
                if (itemsInCat.length === 0) return null;
                return (
                  <div key={cat} className="space-y-2">
                    <h4 className="text-xs uppercase font-bold tracking-wider text-amber-900">
                      {cat} ({itemsInCat.filter((i) => checkedItemIds.includes(i.id)).length}/{itemsInCat.length})
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {itemsInCat.map((item) => {
                        const isChecked = checkedItemIds.includes(item.id);
                        return (
                          <div
                            key={item.id}
                            onClick={() => toggleCheckItem(item.id)}
                            className={`p-3 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                              isChecked
                                ? 'bg-[#edf6f0] border-[#cbe4d2] text-[#615d54]'
                                : 'bg-[#fcfbf7] border-[#ebe7dc] text-[#1a1a1a] hover:border-[#d8d3c5]'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className={`w-5 h-5 rounded flex items-center justify-center border transition-colors flex-shrink-0 ${
                                  isChecked
                                    ? 'bg-[#1a1a1a] border-[#1a1a1a] text-white'
                                    : 'border-[#d8d3c5] bg-white'
                                }`}
                              >
                                {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                              </div>
                              <span className={`text-xs font-medium truncate ${isChecked ? 'line-through text-[#807a6f]' : ''}`}>
                                {item.name}
                              </span>
                            </div>
                            {item.essential && !isChecked && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-[#fdf2f2] text-rose-800 border border-[#f5c6cb] font-bold uppercase flex-shrink-0">
                                Essential
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* TAB 2: BUDGET CALCULATOR & ESTIMATOR */}
        {activeTab === 'budget' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-300">
            
            {/* Left Parameters */}
            <div className="lg:col-span-5 p-6 rounded-xl bg-white border border-[#e7e4dc] space-y-6 shadow-xs">
              <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">Trip Parameters</h3>
              
              {/* Region Selector */}
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-[#807a6f] block">Destination Region:</label>
                <select
                  value={tripRegion}
                  onChange={(e) => setTripRegion(e.target.value as any)}
                  className="w-full p-3 bg-[#fcfbf7] border border-[#d8d3c5] rounded-lg text-xs text-[#1a1a1a] focus:outline-none focus:border-[#1a1a1a]"
                >
                  <option value="sea">Southeast Asia (Thailand, Vietnam, Bali)</option>
                  <option value="sas">South Asia (India, Sri Lanka, Nepal)</option>
                  <option value="weu">Western Europe (France, Italy, Switzerland)</option>
                  <option value="na">North America (USA, Canada)</option>
                  <option value="sa">South America (Peru, Brazil, Argentina)</option>
                  <option value="me">Middle East (UAE, Oman, Jordan)</option>
                </select>
              </div>

              {/* Travel Style */}
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-[#807a6f] block">Travel Comfort Style:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'budget', label: 'Backpacker', icon: '🎒' },
                    { id: 'mid', label: 'Mid-Range', icon: '🏨' },
                    { id: 'luxury', label: 'Luxury', icon: '✨' }
                  ].map((st) => (
                    <button
                      key={st.id}
                      onClick={() => setBudgetStyle(st.id as any)}
                      className={`p-3 rounded-lg border text-center transition-all cursor-pointer ${
                        budgetStyle === st.id
                          ? 'bg-[#1a1a1a] text-white font-bold border-[#1a1a1a]'
                          : 'bg-[#fcfbf7] border-[#ebe7dc] text-[#4a473e] hover:bg-[#f4f1ea]'
                      }`}
                    >
                      <div className="text-lg">{st.icon}</div>
                      <div className="text-xs mt-1">{st.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Number of Days Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-semibold text-[#1a1a1a]">
                  <span>Duration: <strong className="text-amber-900 text-sm">{numDays} Days</strong></span>
                  <span className="text-[#807a6f]">1 to 60</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="60"
                  value={numDays}
                  onChange={(e) => setNumDays(Number(e.target.value))}
                  className="w-full accent-[#1a1a1a] cursor-pointer"
                />
              </div>

              {/* Number of Travelers Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-semibold text-[#1a1a1a]">
                  <span>Travelers: <strong className="text-teal-900 text-sm">{numTravelers} Person(s)</strong></span>
                  <span className="text-[#807a6f]">1 to 10</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={numTravelers}
                  onChange={(e) => setNumTravelers(Number(e.target.value))}
                  className="w-full accent-[#1a1a1a] cursor-pointer"
                />
              </div>

              {/* Target Currency Selector */}
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-[#807a6f] block">Display Currency:</label>
                <div className="flex gap-2">
                  {(['USD', 'EUR', 'INR', 'GBP', 'JPY'] as const).map((curr) => (
                    <button
                      key={curr}
                      onClick={() => setTargetCurrency(curr)}
                      className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        targetCurrency === curr
                          ? 'bg-[#1a1a1a] text-white border-[#1a1a1a]'
                          : 'bg-[#fcfbf7] border-[#ebe7dc] text-[#615d54] hover:text-[#1a1a1a]'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Right Output & Breakdown */}
            <div className="lg:col-span-7 p-6 rounded-xl bg-white border border-[#e7e4dc] space-y-6 flex flex-col justify-between shadow-xs">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-heading text-xl font-bold text-[#1a1a1a]">Itemized Budget Breakdown</h3>
                  <span className="text-xs text-[#807a6f] font-medium">{activeRegionData.name}</span>
                </div>

                {/* Grand Total Hero Box */}
                <div className="p-6 rounded-xl bg-[#f8f6f0] border border-[#ebe7dc] mb-6">
                  <span className="text-xs uppercase font-bold tracking-wider text-amber-900 block">
                    Estimated Total Trip Expense ({numDays} Days • {numTravelers} Travelers)
                  </span>
                  <div className="text-4xl sm:text-5xl font-black text-[#1a1a1a] mt-1 font-heading">
                    {curSymbol}{convertedTotal.toLocaleString()} <span className="text-sm font-normal text-[#807a6f]">{targetCurrency}</span>
                  </div>
                  <div className="text-xs text-[#615d54] mt-1">
                    ≈ {curSymbol}{Math.round(convertedTotal / numDays).toLocaleString()} per day for group
                  </div>
                </div>

                {/* Category Sliders / Cards */}
                <div className="space-y-3">
                  <div className="p-3.5 rounded-lg bg-[#fcfbf7] border border-[#ebe7dc] flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#2d2a24]">🏨 Accommodation (Hotels/Hostels - 42%):</span>
                    <strong className="text-[#1a1a1a] font-mono text-sm">{curSymbol}{lodgingPortion.toLocaleString()}</strong>
                  </div>
                  <div className="p-3.5 rounded-lg bg-[#fcfbf7] border border-[#ebe7dc] flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#2d2a24]">🍛 Dining, Food & Cafes (28%):</span>
                    <strong className="text-[#1a1a1a] font-mono text-sm">{curSymbol}{foodPortion.toLocaleString()}</strong>
                  </div>
                  <div className="p-3.5 rounded-lg bg-[#fcfbf7] border border-[#ebe7dc] flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#2d2a24]">🚅 Local Transit & Trains (15%):</span>
                    <strong className="text-[#1a1a1a] font-mono text-sm">{curSymbol}{transportPortion.toLocaleString()}</strong>
                  </div>
                  <div className="p-3.5 rounded-lg bg-[#fcfbf7] border border-[#ebe7dc] flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#2d2a24]">🎟️ Museum Tickets & Tours (10%):</span>
                    <strong className="text-[#1a1a1a] font-mono text-sm">{curSymbol}{activitiesPortion.toLocaleString()}</strong>
                  </div>
                  <div className="p-3.5 rounded-lg bg-[#fcfbf7] border border-[#ebe7dc] flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#2d2a24]">🛡️ Emergency Buffer & Misc (5%):</span>
                    <strong className="text-[#1a1a1a] font-mono text-sm">{curSymbol}{bufferPortion.toLocaleString()}</strong>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc] text-[11px] text-[#7a7467]">
                * Note: Estimates exclude international long-haul return flights and personal luxury shopping.
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: VISA & ENTRY ADVISOR */}
        {activeTab === 'visa' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
              <span className="text-xs text-[#615d54]">
                Search tourist entry policies, eVisa processing times, and official embassy portals
              </span>
              <input
                type="text"
                value={visaSearch}
                onChange={(e) => setVisaSearch(e.target.value)}
                placeholder="Search country or passport..."
                className="w-full sm:w-64 px-3.5 py-2 bg-[#fcfbf7] border border-[#d8d3c5] rounded-lg text-xs text-[#1a1a1a] focus:outline-none focus:border-[#1a1a1a]"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredVisas.map((v, i) => (
                <div key={i} className="p-5 rounded-xl bg-white border border-[#e7e4dc] space-y-4 hover:border-[#c5bea] transition-all flex flex-col justify-between shadow-xs">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{v.flag}</span>
                        <h4 className="font-heading text-lg font-bold text-[#1a1a1a]">{v.country}</h4>
                      </div>
                      <span className="px-2.5 py-1 rounded-md bg-[#f0ece1] text-[#1a1a1a] text-xs font-bold">
                        {v.feeUSD}
                      </span>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                        <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Visa Protocol</span>
                        <strong className="text-[#1a1a1a] text-sm mt-0.5 block">{v.visaType}</strong>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2.5 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                          <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Processing Time</span>
                          <span className="font-semibold text-emerald-800">{v.processingTime}</span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-[#f8f6f0] border border-[#ebe7dc]">
                          <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Eligible Passports</span>
                          <span className="font-semibold text-[#48453e] truncate block">{v.validPassports}</span>
                        </div>
                      </div>
                      <p className="text-[#615d54] text-[11px] leading-relaxed pt-1">
                        💡 {v.notes}
                      </p>
                    </div>
                  </div>

                  <a
                    href={v.officialUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 w-full py-2.5 rounded-lg bg-[#f0ece1] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-semibold text-xs transition-colors"
                  >
                    <span>Official Portal</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: TRAVEL FAQS */}
        {activeTab === 'faq' && (
          <div className="max-w-4xl mx-auto space-y-4 animate-in fade-in duration-300">
            {GENERAL_TRAVEL_FAQS.map((faq) => {
              const isExpanded = expandedFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden transition-all shadow-xs"
                >
                  <button
                    onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer"
                  >
                    <span className="font-heading text-sm sm:text-base font-bold text-[#1a1a1a]">
                      {faq.question}
                    </span>
                    <span className="p-1.5 rounded-md bg-[#f0ece1] text-[#615d54] flex-shrink-0">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </button>
                  {isExpanded && (
                    <div className="px-5 pb-5 text-xs sm:text-sm text-[#48453e] leading-relaxed border-t border-[#ebe7dc] pt-3">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
