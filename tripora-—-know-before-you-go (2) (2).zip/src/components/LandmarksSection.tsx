import React, { useState } from 'react';
import { Compass, Sparkles, MapPin, ChevronRight, Bookmark } from 'lucide-react';
import { LANDMARKS_DATA } from '../data/landmarks';
import { LandmarkCategory } from '../types';

interface LandmarksSectionProps {
  onSelectLandmark: (landmarkId: string) => void;
  savedLandmarks: string[];
  onToggleSaveLandmark: (landmarkName: string) => void;
}

export const LandmarksSection: React.FC<LandmarksSectionProps> = ({
  onSelectLandmark,
  savedLandmarks,
  onToggleSaveLandmark
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'All World Wonders' },
    { id: 'Architectural Wonder', label: '🏛️ Architectural' },
    { id: 'Natural Wonder', label: '🏔️ Natural' },
    { id: 'Ancient Monument', label: '🏺 Ancient History' },
    { id: 'Modern Engineering', label: '🏙️ Modern Engineering' }
  ];

  const filteredLandmarks = LANDMARKS_DATA.filter((lm) => {
    if (selectedCategory === 'all') return true;
    return lm.category.toLowerCase().includes(selectedCategory.toLowerCase());
  });

  return (
    <section id="landmarks" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Compass className="w-3.5 h-3.5" />
              Chapter 05 • Iconic Monuments & Wonders
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              World Landmarks & Wonders
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              The pinnacle of human architectural ingenuity and nature's grandest geological masterworks across seven continents.
            </p>
          </div>

          {/* Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'bg-white border border-[#e7e4dc] text-[#555148] hover:text-[#1a1a1a] hover:bg-[#f7f5ee]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Landmarks Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
          {filteredLandmarks.map((landmark) => {
            const isSaved = savedLandmarks.includes(landmark.name);
            return (
              <div
                key={landmark.id}
                className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs"
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden cursor-pointer" onClick={() => onSelectLandmark(landmark.id)}>
                  <img
                    src={landmark.image}
                    alt={landmark.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                  
                  {/* Badges */}
                  <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                      {landmark.category}
                    </span>
                    {landmark.unescoWorldHeritage && (
                      <span className="px-2 py-0.5 rounded-md bg-stone-900/90 text-amber-200 border border-amber-400/40 text-[9px] font-bold">
                        UNESCO
                      </span>
                    )}
                  </div>

                  {/* Bookmark Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleSaveLandmark(landmark.name);
                    }}
                    className={`absolute top-3.5 right-3.5 p-2 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                      isSaved
                        ? 'bg-[#1a1a1a] text-white'
                        : 'bg-[#1a1a1a]/70 text-stone-200 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>

                  {/* Title */}
                  <div className="absolute bottom-3 left-4 right-4">
                    <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                      {landmark.country}
                    </div>
                    <h3 className="font-heading text-xl font-bold text-white group-hover:text-amber-200 transition-colors">
                      {landmark.name}
                    </h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  <p className="text-xs text-[#48453e] line-clamp-2 leading-relaxed">
                    {landmark.overview}
                  </p>

                  <div className="p-3 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs text-[#48453e]">
                    <strong className="text-[#1a1a1a] block mb-1">⭐️ Special Dimension:</strong>
                    <span className="line-clamp-2">{landmark.whatMakesItSpecial}</span>
                  </div>

                  {/* Explore Button */}
                  <button
                    onClick={() => onSelectLandmark(landmark.id)}
                    className="w-full py-2.5 rounded-lg bg-[#f4f1ea] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>View Monument Guide</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
