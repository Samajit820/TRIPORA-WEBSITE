import React, { useState } from 'react';
import { Utensils, Sparkles, Calendar, BookOpen, CheckCircle2, AlertCircle, Heart, ChevronRight } from 'lucide-react';
import { FOODS_DATA } from '../data/foods';
import { FESTIVALS_DATA, CULTURES_DATA } from '../data/cultureFestivals';

export const FoodCultureSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'food' | 'culture' | 'festivals'>('food');
  const [vegOnly, setVegOnly] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number | 'all'>('all');

  const filteredFoods = FOODS_DATA.filter((f) => {
    if (vegOnly) return f.isVegetarianFriendly;
    return true;
  });

  const filteredFestivals = FESTIVALS_DATA.filter((fest) => {
    if (selectedMonth === 'all') return true;
    return fest.monthIndex === selectedMonth;
  });

  return (
    <section id="food-culture" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Utensils className="w-3.5 h-3.5" />
              Chapter 07 • World Gastronomy & Living Heritage
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Food, Culture & Festivals
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              Immerse in legendary culinary recipes, respectful cultural etiquette, and vibrant festive celebrations across human civilizations.
            </p>
          </div>

          {/* Module Switcher */}
          <div className="flex items-center p-1 bg-[#f0ece1] border border-[#ded9cc] rounded-lg">
            <button
              onClick={() => setActiveTab('food')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'food'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#615d54] hover:text-[#1a1a1a]'
              }`}
            >
              World Foods ({FOODS_DATA.length})
            </button>
            <button
              onClick={() => setActiveTab('culture')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'culture'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#615d54] hover:text-[#1a1a1a]'
              }`}
            >
              Culture & Etiquette ({CULTURES_DATA.length})
            </button>
            <button
              onClick={() => setActiveTab('festivals')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'festivals'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#615d54] hover:text-[#1a1a1a]'
              }`}
            >
              Global Festivals ({FESTIVALS_DATA.length})
            </button>
          </div>
        </div>

        {/* TAB 1: WORLD FOODS */}
        {activeTab === 'food' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Filter bar */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
              <span className="text-xs text-[#615d54]">
                Displaying authentic culinary masterworks & street gastronomy
              </span>
              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-emerald-800">
                <input
                  type="checkbox"
                  checked={vegOnly}
                  onChange={(e) => setVegOnly(e.target.checked)}
                  className="rounded accent-[#1a1a1a] cursor-pointer"
                />
                <span>Vegetarian Friendly Only</span>
              </label>
            </div>

            {/* Food Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredFoods.map((food) => (
                <div
                  key={food.id}
                  className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs"
                >
                  <div className="relative h-56 overflow-hidden">
                    <img src={food.image} alt={food.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                    
                    <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                        {food.type}
                      </span>
                      {food.isVegetarianFriendly && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-950/80 text-emerald-200 border border-emerald-800/40 text-[9px] font-bold">
                          🌱 Veg
                        </span>
                      )}
                    </div>

                    <div className="absolute bottom-3 left-4 right-4">
                      <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                        {food.region}
                      </div>
                      <h3 className="font-heading text-xl font-bold text-white">
                        {food.name}
                      </h3>
                      <div className="text-xs text-amber-200/90 font-medium">
                        {food.nativeName}
                      </div>
                    </div>
                  </div>

                  <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                    <p className="text-xs text-[#48453e] leading-relaxed">
                      {food.description}
                    </p>

                    {/* Flavor Profile & Cultural Story */}
                    <div className="p-3 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs space-y-1.5">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-amber-900 block">Flavor Profile:</span>
                        <span className="text-[#48453e]">{food.flavorProfile}</span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Where to Taste Authentically:</span>
                        <span className="text-[#1a1a1a] font-semibold">{food.whereToFind}</span>
                      </div>
                    </div>

                    {/* Key Ingredients */}
                    <div className="text-xs">
                      <span className="text-[10px] uppercase font-bold text-[#807a6f] block mb-1">Key Ingredients:</span>
                      <div className="flex flex-wrap gap-1">
                        {food.ingredientsOverview.slice(0, 4).map((ing, i) => (
                          <span key={i} className="px-2 py-0.5 rounded-md bg-[#f0ece1] text-[#4a473e] text-[10px]">
                            {ing}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: CULTURE & ETIQUETTE */}
        {activeTab === 'culture' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {CULTURES_DATA.map((item) => (
              <div key={item.id} className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all flex flex-col justify-between shadow-xs">
                <div className="relative h-48 overflow-hidden">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/30 to-transparent" />
                  <div className="absolute top-3.5 left-3.5 px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 text-[10px] font-bold text-white uppercase">
                    {item.country} • {item.category}
                  </div>
                  <div className="absolute bottom-3 left-4 right-4">
                    <h3 className="font-heading text-lg font-bold text-white">{item.title}</h3>
                  </div>
                </div>

                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  <p className="text-xs text-[#48453e] leading-relaxed">{item.description}</p>
                  
                  <div className="p-3.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] space-y-2">
                    <span className="text-[10px] uppercase font-bold text-amber-900 block">Respectful Etiquette Guidelines:</span>
                    <ul className="space-y-1.5 text-xs text-[#48453e]">
                      {item.culturalEtiquetteTips.map((tip, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 mt-0.5 flex-shrink-0" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="text-[11px] text-[#7a7467] italic">
                    {item.historicalContext}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 3: FESTIVALS CALENDAR */}
        {activeTab === 'festivals' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredFestivals.map((fest) => (
                <div key={fest.id} className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs">
                  <div className="relative h-56 overflow-hidden">
                    <img src={fest.image} alt={fest.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                    
                    <div className="absolute top-3.5 left-3.5 px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                      {fest.country} • {fest.category}
                    </div>

                    <div className="absolute bottom-3 left-4 right-4">
                      <div className="text-xs font-bold text-amber-300">
                        🗓️ {fest.timeOfYear}
                      </div>
                      <h3 className="font-heading text-xl font-bold text-white">
                        {fest.name}
                      </h3>
                      <div className="text-xs text-stone-200 font-medium">{fest.nativeName}</div>
                    </div>
                  </div>

                  <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                    <p className="text-xs text-[#48453e] leading-relaxed">
                      {fest.culturalSignificance}
                    </p>

                    <div className="p-3 rounded-md bg-[#fbf5ea] border border-[#eedab2] text-xs text-amber-950">
                      <strong className="text-[#1a1a1a] block mb-1">🎉 Visitor Experience:</strong>
                      {fest.visitorExperience}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
