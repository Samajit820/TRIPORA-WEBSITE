import React from 'react';
import { X, MapPin, Sparkles, Compass, CheckCircle2, Bookmark } from 'lucide-react';
import { LandmarkItem } from '../types';
import { LANDMARKS_DATA } from '../data/landmarks';

interface LandmarkDetailModalProps {
  landmarkId: string | null;
  onClose: () => void;
  onToggleSave: (landmarkName: string) => void;
  isSaved: boolean;
}

export const LandmarkDetailModal: React.FC<LandmarkDetailModalProps> = ({
  landmarkId,
  onClose,
  onToggleSave,
  isSaved
}) => {
  if (!landmarkId) return null;

  const landmark = LANDMARKS_DATA.find((l) => l.id === landmarkId) || LANDMARKS_DATA[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-3xl rounded-2xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10 text-[#1a1a1a]">
        
        {/* Header Photo */}
        <div className="relative h-64 flex-shrink-0 overflow-hidden">
          <img src={landmark.image} alt={landmark.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/40 to-[#1a1a1a]/10" />

          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-xs font-bold text-white uppercase">
                {landmark.category}
              </span>
              {landmark.unescoWorldHeritage && (
                <span className="px-2.5 py-1 rounded-md bg-stone-900/90 text-amber-200 border border-amber-400/40 text-xs font-bold">
                  UNESCO World Heritage
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onToggleSave(landmark.name)}
                className={`p-2.5 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                  isSaved
                    ? 'bg-amber-400 text-stone-950 font-bold'
                    : 'bg-[#1a1a1a]/80 text-white hover:text-amber-300'
                }`}
              >
                <Bookmark className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2.5 rounded-md bg-[#1a1a1a]/80 text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="absolute bottom-4 left-6 right-6">
            <span className="text-xs uppercase font-bold text-amber-300 tracking-wider">
              {landmark.location} • {landmark.country}
            </span>
            <h2 className="font-heading text-2xl sm:text-3xl font-bold text-white">
              {landmark.name}
            </h2>
          </div>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 space-y-5 flex-1 text-[#2d2a24] text-xs sm:text-sm">
          <div>
            <h3 className="font-heading text-base font-bold text-[#1a1a1a] mb-1">Landmark Overview</h3>
            <p className="text-[#4a473e] leading-relaxed">{landmark.overview}</p>
          </div>

          {/* What makes it special */}
          <div className="p-4 rounded-xl bg-[#fdf2f2] border border-[#f5c6cb] text-rose-950">
            <strong className="text-[#1a1a1a] block mb-1 text-sm">✨ What Makes It Globally Special:</strong>
            {landmark.whatMakesItSpecial}
          </div>

          {/* Highlights */}
          <div>
            <h4 className="font-bold text-[#1a1a1a] uppercase text-xs tracking-wider mb-2">Key Features & Highlights</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {landmark.highlights.map((h, i) => (
                <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                  <CheckCircle2 className="w-4 h-4 text-amber-700 mt-0.5 flex-shrink-0" />
                  <span>{h}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tips & Nearby */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 shadow-xs">
              <h4 className="font-bold text-xs uppercase text-amber-900">💡 Visitor Guide & Tips</h4>
              <p className="text-xs text-[#4a473e] leading-relaxed">{landmark.visitorTips}</p>
            </div>
            <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 shadow-xs">
              <h4 className="font-bold text-xs uppercase text-teal-800">📍 Nearby Sights</h4>
              <div className="flex flex-wrap gap-1.5">
                {landmark.nearbyAttractions.map((att, idx) => (
                  <span key={idx} className="px-2.5 py-1 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs text-[#1a1a1a]">
                    {att}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-3 bg-[#f0ece1] border-t border-[#e2ded5] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
