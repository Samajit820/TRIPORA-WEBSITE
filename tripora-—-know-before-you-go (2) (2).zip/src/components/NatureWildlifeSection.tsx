import React, { useState } from 'react';
import { TreePine, Sun, Waves, Mountain, ShieldAlert, Sparkles, MapPin, Eye } from 'lucide-react';
import { WILDLIFE_DATA, BIOMES_SUMMARY } from '../data/natureWildlife';

export const NatureWildlifeSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'wildlife' | 'biomes'>('wildlife');
  const [selectedAnimal, setSelectedAnimal] = useState<string | null>(null);

  return (
    <section id="nature-wildlife" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <TreePine className="w-3.5 h-3.5" />
              Chapter 06 • Earth Ecosystems & Wildlife
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Nature & Wildlife Safari
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              Explore Earth's primary ecosystems, biodiverse biomes, iconic wild fauna, conservation sanctuaries, and premier safari frontiers.
            </p>
          </div>

          {/* Toggle Tab */}
          <div className="flex items-center p-1 bg-[#f0ece1] border border-[#ded9cc] rounded-lg">
            <button
              onClick={() => setActiveTab('wildlife')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'wildlife'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#615d54] hover:text-[#1a1a1a]'
              }`}
            >
              Wild Fauna ({WILDLIFE_DATA.length})
            </button>
            <button
              onClick={() => setActiveTab('biomes')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'biomes'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#615d54] hover:text-[#1a1a1a]'
              }`}
            >
              Earth Biomes ({BIOMES_SUMMARY.length})
            </button>
          </div>
        </div>

        {/* TAB 1: WILDLIFE */}
        {activeTab === 'wildlife' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {WILDLIFE_DATA.map((animal) => (
              <div
                key={animal.id}
                className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs"
              >
                <div className="relative h-56 overflow-hidden">
                  <img src={animal.image} alt={animal.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                  
                  <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                      {animal.category}
                    </span>
                    <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold border ${
                      animal.conservationStatus === 'Endangered'
                        ? 'bg-rose-950/80 text-rose-200 border-rose-800/40'
                        : animal.conservationStatus === 'Vulnerable'
                        ? 'bg-amber-950/80 text-amber-200 border-amber-800/40'
                        : 'bg-emerald-950/80 text-emerald-200 border-emerald-800/40'
                    }`}>
                      {animal.conservationStatus}
                    </span>
                  </div>

                  <div className="absolute bottom-3 left-4 right-4">
                    <div className="text-[11px] font-mono text-amber-300 italic">
                      {animal.scientificName}
                    </div>
                    <h3 className="font-heading text-xl font-bold text-white">
                      {animal.name}
                    </h3>
                  </div>
                </div>

                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="text-xs text-[#615d54]">
                      <strong className="text-[#1a1a1a]">Native Habitats: </strong>
                      {animal.primaryHabitats.join(', ')}
                    </div>
                    <div className="text-xs text-[#615d54]">
                      <strong className="text-[#1a1a1a]">Nations Found: </strong>
                      {animal.countriesFound.join(', ')}
                    </div>
                  </div>

                  {/* Best places to spot */}
                  <div className="p-3 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs">
                    <span className="text-[10px] uppercase font-bold text-amber-900 block mb-1 flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> Best Spotting Sanctuaries:
                    </span>
                    <ul className="space-y-0.5 text-[#48453e]">
                      {animal.bestPlacesToSpot.slice(0, 2).map((p, idx) => (
                        <li key={idx} className="truncate">• {p}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Fun Fact */}
                  <div className="p-3 rounded-md bg-[#edf6f0] border border-[#cbe4d2] text-xs text-[#2d2a24]">
                    <span className="text-emerald-900 font-bold block mb-1">🐾 Behavioral Fact:</span>
                    <p className="line-clamp-2 text-[#48453e]">{animal.interestingFacts[0]}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 2: BIOMES */}
        {activeTab === 'biomes' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-300">
            {BIOMES_SUMMARY.map((biome) => (
              <div
                key={biome.id}
                className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col sm:flex-row shadow-xs"
              >
                <div className="sm:w-1/2 relative h-48 sm:h-auto overflow-hidden">
                  <img src={biome.image} alt={biome.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-[#1a1a1a]/60 to-transparent" />
                </div>
                <div className="sm:w-1/2 p-5 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider">
                      {biome.coverage}
                    </span>
                    <h3 className="font-heading text-xl font-bold text-[#1a1a1a] mt-0.5">
                      {biome.title}
                    </h3>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                      <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Biodiversity Density</span>
                      <span className="text-[#1a1a1a] font-medium">{biome.biodiversity}</span>
                    </div>
                    <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                      <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Prime Planetary Locations</span>
                      <span className="text-amber-900 font-medium">{biome.keyRegions}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
