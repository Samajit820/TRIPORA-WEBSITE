import React, { useState, useEffect, useRef, useMemo } from 'react';
import * as d3 from 'd3';
import {
  History,
  Search,
  Filter,
  Play,
  Pause,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Calendar,
  Compass,
  MapPin,
  Quote,
  Users,
  Award,
  BookOpen,
  X,
  Layers,
  ChevronDown
} from 'lucide-react';
import { HistoricalEvent, HistoricalEra, HistoricalCategory, CountryHistoricalProfile } from '../types';
import { ALL_195_COUNTRIES } from '../data/countries';
import { HISTORICAL_PROFILES, getCountryHistoricalProfile } from '../data/historyTimelines';

interface HistoricalTimelineProps {
  initialCountryId?: string;
  onSelectCountryDetails?: (countryId: string) => void;
}

const CATEGORY_COLORS: Record<HistoricalCategory, { bg: string; border: string; text: string; dot: string }> = {
  'Politics & Empires': { bg: 'bg-amber-50', border: 'border-amber-300', text: 'text-amber-900', dot: '#d97706' },
  'Culture & Arts': { bg: 'bg-rose-50', border: 'border-rose-300', text: 'text-rose-900', dot: '#e11d48' },
  'Science & Innovation': { bg: 'bg-sky-50', border: 'border-sky-300', text: 'text-sky-900', dot: '#0284c7' },
  'Conflict & Peace': { bg: 'bg-purple-50', border: 'border-purple-300', text: 'text-purple-900', dot: '#9333ea' },
  'Architecture & Wonders': { bg: 'bg-emerald-50', border: 'border-emerald-300', text: 'text-emerald-900', dot: '#16a34a' },
  'Milestone': { bg: 'bg-stone-50', border: 'border-stone-300', text: 'text-stone-900', dot: '#57534e' }
};

const ERA_COLORS: Record<HistoricalEra, string> = {
  Ancient: '#d97706',
  Classical: '#ea580c',
  Medieval: '#0284c7',
  'Early Modern': '#16a34a',
  Modern: '#9333ea',
  Contemporary: '#e11d48'
};

export const HistoricalTimeline: React.FC<HistoricalTimelineProps> = ({
  initialCountryId = 'india',
  onSelectCountryDetails
}) => {
  // Country Selection State
  const [selectedCountryId, setSelectedCountryId] = useState<string>(initialCountryId);
  const [countrySearchQuery, setCountrySearchQuery] = useState('');
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);

  // Filter & Search States
  const [selectedEra, setSelectedEra] = useState<HistoricalEra | 'All'>('All');
  const [selectedCategory, setSelectedCategory] = useState<HistoricalCategory | 'All'>('All');
  const [eventSearchQuery, setEventSearchQuery] = useState('');

  // Active Event Inspector Modal / Drawer
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);

  // Autoplay Tour State
  const [isPlayingTour, setIsPlayingTour] = useState(false);
  const [tourIndex, setTourIndex] = useState(0);

  // D3 & Canvas References
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [containerWidth, setContainerWidth] = useState(1000);
  const [zoomTransform, setZoomTransform] = useState<d3.ZoomTransform>(d3.zoomIdentity);

  // Featured Quick-Select Countries
  const featuredQuickPicks = [
    { id: 'india', name: 'India', flag: '🇮🇳' },
    { id: 'japan', name: 'Japan', flag: '🇯🇵' },
    { id: 'france', name: 'France', flag: '🇫🇷' },
    { id: 'italy', name: 'Italy', flag: '🇮🇹' },
    { id: 'egypt', name: 'Egypt', flag: '🇪🇬' },
    { id: 'united-states', name: 'United States', flag: '🇺🇸' }
  ];

  // Resolve current Country Historical Profile
  const countryProfile: CountryHistoricalProfile = useMemo(() => {
    const matchedSimple = ALL_195_COUNTRIES.find((c) => c.id === selectedCountryId);
    return getCountryHistoricalProfile(
      selectedCountryId,
      matchedSimple ? matchedSimple.name : selectedCountryId,
      matchedSimple ? matchedSimple.flag : '🏳️',
      matchedSimple ? matchedSimple.region : 'Global'
    );
  }, [selectedCountryId]);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return countryProfile.events.filter((ev) => {
      const matchEra = selectedEra === 'All' || ev.era === selectedEra;
      const matchCategory = selectedCategory === 'All' || ev.category === selectedCategory;
      const matchSearch =
        !eventSearchQuery.trim() ||
        ev.title.toLowerCase().includes(eventSearchQuery.toLowerCase()) ||
        ev.summary.toLowerCase().includes(eventSearchQuery.toLowerCase()) ||
        ev.yearDisplay.toLowerCase().includes(eventSearchQuery.toLowerCase()) ||
        (ev.keyFigures && ev.keyFigures.some((k) => k.toLowerCase().includes(eventSearchQuery.toLowerCase())));
      return matchEra && matchCategory && matchSearch;
    });
  }, [countryProfile, selectedEra, selectedCategory, eventSearchQuery]);

  // Selected Event Object
  const activeEvent = useMemo(() => {
    if (!selectedEventId) return null;
    return countryProfile.events.find((e) => e.id === selectedEventId) || null;
  }, [countryProfile, selectedEventId]);

  // Responsive Container Resize Observer
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0) {
          setContainerWidth(Math.max(entry.contentRect.width, 320));
        }
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Reset selected event when country changes
  useEffect(() => {
    if (countryProfile.events.length > 0) {
      setSelectedEventId(countryProfile.events[0].id);
    } else {
      setSelectedEventId(null);
    }
    setIsPlayingTour(false);
    setTourIndex(0);
  }, [selectedCountryId, countryProfile]);

  // Autoplay Tour Effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlayingTour && filteredEvents.length > 0) {
      timer = setInterval(() => {
        setTourIndex((prev) => {
          const next = (prev + 1) % filteredEvents.length;
          setSelectedEventId(filteredEvents[next].id);
          return next;
        });
      }, 4000);
    }
    return () => clearInterval(timer);
  }, [isPlayingTour, filteredEvents]);

  // D3 Rendering of the Interactive Timeline
  useEffect(() => {
    if (!svgRef.current || filteredEvents.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const margin = { top: 70, right: 60, bottom: 80, left: 60 };
    const width = containerWidth;
    const height = 440;
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Determine year domain with padding
    const minYear = d3.min(countryProfile.events, (d) => d.year) ?? -1000;
    const maxYear = d3.max(countryProfile.events, (d) => d.year) ?? 2026;
    const yearPadding = Math.max(50, (maxYear - minYear) * 0.08);

    // D3 Linear Time Scale
    const xScale = d3
      .scaleLinear()
      .domain([minYear - yearPadding, maxYear + yearPadding])
      .range([0, innerWidth]);

    const transformedXScale = zoomTransform.rescaleX(xScale);

    // Base SVG container group
    const g = svg
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // D3 Defs for gradients & shadow filters
    const defs = svg.append('defs');

    // Glow Filter
    const filter = defs.append('filter').attr('id', 'glow').attr('x', '-50%').attr('y', '-50%').attr('width', '200%').attr('height', '200%');
    filter.append('feGaussianBlur').attr('stdDeviation', '4').attr('result', 'coloredBlur');
    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    // Era Background Ribbon at top
    const eraBandsGroup = g.append('g').attr('class', 'era-bands');
    countryProfile.majorEras.forEach((era) => {
      // Calculate start and end years for era approximation
      let startYear = minYear;
      let endYear = maxYear;
      if (era.era === 'Ancient') {
        startYear = minYear;
        endYear = Math.min(-1, maxYear);
      } else if (era.era === 'Classical') {
        startYear = 0;
        endYear = Math.min(600, maxYear);
      } else if (era.era === 'Medieval') {
        startYear = 600;
        endYear = Math.min(1500, maxYear);
      } else if (era.era === 'Early Modern') {
        startYear = 1500;
        endYear = Math.min(1850, maxYear);
      } else if (era.era === 'Modern') {
        startYear = 1850;
        endYear = Math.min(1950, maxYear);
      } else {
        startYear = 1950;
        endYear = maxYear;
      }

      const x1 = Math.max(0, transformedXScale(startYear));
      const x2 = Math.min(innerWidth, transformedXScale(endYear));
      if (x2 > x1) {
        eraBandsGroup
          .append('rect')
          .attr('x', x1)
          .attr('y', -45)
          .attr('width', x2 - x1)
          .attr('height', 24)
          .attr('fill', era.color)
          .attr('fill-opacity', 0.15)
          .attr('rx', 4)
          .attr('stroke', era.color)
          .attr('stroke-opacity', 0.3)
          .attr('stroke-width', 1);

        eraBandsGroup
          .append('text')
          .attr('x', x1 + 6)
          .attr('y', -30)
          .attr('font-size', '10px')
          .attr('font-weight', '700')
          .attr('fill', era.color)
          .attr('font-family', 'sans-serif')
          .text(era.era);
      }
    });

    // Central Timeline Spine (Axis Line)
    const spineY = innerHeight / 2;

    g.append('line')
      .attr('x1', 0)
      .attr('y1', spineY)
      .attr('x2', innerWidth)
      .attr('y2', spineY)
      .attr('stroke', '#d6d1c4')
      .attr('stroke-width', 3)
      .attr('stroke-linecap', 'round');

    // D3 Axis with custom formatted tick labels
    const xAxis = d3
      .axisBottom(transformedXScale)
      .ticks(Math.max(4, Math.floor(innerWidth / 120)))
      .tickFormat((d) => {
        const yr = Number(d);
        if (yr < 0) return `${Math.abs(yr)} BCE`;
        if (yr === 0) return '1 CE';
        return `${yr} CE`;
      });

    const axisGroup = g
      .append('g')
      .attr('transform', `translate(0, ${innerHeight + 25})`)
      .call(xAxis);

    axisGroup.select('.domain').attr('stroke', '#ded9cc');
    axisGroup.selectAll('.tick line').attr('stroke', '#ded9cc').attr('y2', 6);
    axisGroup
      .selectAll('.tick text')
      .attr('fill', '#78716c')
      .attr('font-size', '11px')
      .attr('font-family', 'sans-serif')
      .attr('font-weight', '500');

    // Render Event Connectors & Nodes (Alternating Top / Bottom Tracks)
    const eventsGroup = g.append('g').attr('class', 'timeline-events');

    filteredEvents.forEach((ev, idx) => {
      const cx = transformedXScale(ev.year);
      // Skip rendering if out of current visible canvas boundaries
      if (cx < -40 || cx > innerWidth + 40) return;

      const isTop = idx % 2 === 0;
      const trackDistance = isTop ? -95 : 95;
      const nodeY = spineY + trackDistance;
      const isSelected = selectedEventId === ev.id;
      const eraColor = ERA_COLORS[ev.era] || '#d97706';

      // Curved Bezier Connector Line
      const pathData = d3.path();
      pathData.moveTo(cx, spineY);
      pathData.bezierCurveTo(cx, spineY + trackDistance * 0.4, cx, nodeY - (isTop ? -20 : 20), cx, nodeY);

      eventsGroup
        .append('path')
        .attr('d', pathData.toString())
        .attr('fill', 'none')
        .attr('stroke', isSelected ? eraColor : '#d6d1c4')
        .attr('stroke-width', isSelected ? 2.5 : 1.5)
        .attr('stroke-dasharray', isSelected ? 'none' : '3,3')
        .attr('opacity', isSelected ? 1 : 0.7);

      // Point on the axis spine
      eventsGroup
        .append('circle')
        .attr('cx', cx)
        .attr('cy', spineY)
        .attr('r', isSelected ? 5 : 3.5)
        .attr('fill', isSelected ? eraColor : '#a8a29e')
        .attr('stroke', '#ffffff')
        .attr('stroke-width', 1.5);

      // Milestone Card / Node Group
      const nodeGroup = eventsGroup
        .append('g')
        .attr('transform', `translate(${cx}, ${nodeY})`)
        .attr('cursor', 'pointer')
        .on('click', () => {
          setSelectedEventId(ev.id);
          setIsPlayingTour(false);
        });

      // Outer Selection Ring
      if (isSelected) {
        nodeGroup
          .append('circle')
          .attr('r', 24)
          .attr('fill', 'none')
          .attr('stroke', eraColor)
          .attr('stroke-width', 2)
          .attr('stroke-dasharray', '4,3')
          .attr('filter', 'url(#glow)');
      }

      // Node Circle
      nodeGroup
        .append('circle')
        .attr('r', isSelected ? 18 : 14)
        .attr('fill', '#ffffff')
        .attr('stroke', eraColor)
        .attr('stroke-width', isSelected ? 3.5 : 2.5)
        .attr('filter', isSelected ? 'url(#glow)' : 'none');

      // Inner icon or year indicator
      nodeGroup
        .append('circle')
        .attr('r', isSelected ? 8 : 6)
        .attr('fill', eraColor);

      // Text Label Card
      const labelGroup = nodeGroup.append('g').attr('transform', `translate(0, ${isTop ? -28 : 28})`);

      // Year badge
      labelGroup
        .append('rect')
        .attr('x', -45)
        .attr('y', isTop ? -20 : 0)
        .attr('width', 90)
        .attr('height', 18)
        .attr('rx', 4)
        .attr('fill', isSelected ? '#1a1a1a' : '#f0ece1')
        .attr('stroke', isSelected ? '#1a1a1a' : '#ded9cc')
        .attr('stroke-width', 1);

      labelGroup
        .append('text')
        .attr('x', 0)
        .attr('y', isTop ? -8 : 12)
        .attr('text-anchor', 'middle')
        .attr('font-size', '10px')
        .attr('font-weight', '700')
        .attr('fill', isSelected ? '#ffffff' : '#44403c')
        .attr('font-family', 'sans-serif')
        .text(ev.yearDisplay);

      // Event Title Truncation
      const truncatedTitle = ev.title.length > 26 ? ev.title.substring(0, 24) + '…' : ev.title;
      labelGroup
        .append('text')
        .attr('x', 0)
        .attr('y', isTop ? -26 : 28)
        .attr('text-anchor', 'middle')
        .attr('font-size', '11px')
        .attr('font-weight', isSelected ? '700' : '600')
        .attr('fill', isSelected ? '#1a1a1a' : '#57534e')
        .attr('font-family', 'sans-serif')
        .text(truncatedTitle);
    });

    // D3 Zoom Behavior Attachment
    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.6, 6])
      .extent([
        [0, 0],
        [width, height]
      ])
      .on('zoom', (event) => {
        setZoomTransform(event.transform);
      });

    svg.call(zoom);
  }, [containerWidth, filteredEvents, countryProfile, selectedEventId, zoomTransform]);

  // Zoom Button Controls
  const handleZoomIn = () => {
    if (!svgRef.current) return;
    d3.select(svgRef.current)
      .transition()
      .duration(350)
      .call(d3.zoom<SVGSVGElement, unknown>().scaleBy, 1.3);
  };

  const handleZoomOut = () => {
    if (!svgRef.current) return;
    d3.select(svgRef.current)
      .transition()
      .duration(350)
      .call(d3.zoom<SVGSVGElement, unknown>().scaleBy, 0.7);
  };

  const handleResetZoom = () => {
    if (!svgRef.current) return;
    d3.select(svgRef.current)
      .transition()
      .duration(450)
      .call(d3.zoom<SVGSVGElement, unknown>().transform, d3.zoomIdentity);
    setZoomTransform(d3.zoomIdentity);
  };

  // Step to Next/Prev Event in Drawer
  const handlePrevEvent = () => {
    if (!activeEvent || filteredEvents.length === 0) return;
    const currentIndex = filteredEvents.findIndex((e) => e.id === activeEvent.id);
    const prevIndex = (currentIndex - 1 + filteredEvents.length) % filteredEvents.length;
    setSelectedEventId(filteredEvents[prevIndex].id);
  };

  const handleNextEvent = () => {
    if (!activeEvent || filteredEvents.length === 0) return;
    const currentIndex = filteredEvents.findIndex((e) => e.id === activeEvent.id);
    const nextIndex = (currentIndex + 1) % filteredEvents.length;
    setSelectedEventId(filteredEvents[nextIndex].id);
  };

  // Filter list of 195 countries for the dropdown search
  const filteredCountryList = useMemo(() => {
    if (!countrySearchQuery.trim()) return ALL_195_COUNTRIES;
    return ALL_195_COUNTRIES.filter(
      (c) =>
        c.name.toLowerCase().includes(countrySearchQuery.toLowerCase()) ||
        c.region.toLowerCase().includes(countrySearchQuery.toLowerCase())
    );
  }, [countrySearchQuery]);

  return (
    <div id="history-timeline-section" className="py-16 sm:py-24 bg-[#fcfbf7] border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <History className="w-3.5 h-3.5 text-amber-700" />
              Interactive D3 Atlas • Historical Chronology
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Historical Timeline of Nations
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              Traverse millennia of human civilization. Discover defining empires, scientific breakthroughs, constitutional milestones, and monumental turning points across every nation.
            </p>
          </div>

          {/* Quick Stats Banner */}
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
            <div className="w-10 h-10 rounded-lg bg-[#f0ece1] flex items-center justify-center font-bold text-xl">
              {countryProfile.flag}
            </div>
            <div>
              <span className="text-[11px] font-semibold text-[#807a6f] uppercase block">Selected Nation</span>
              <span className="font-heading font-bold text-base text-[#1a1a1a]">{countryProfile.countryName}</span>
            </div>
            <div className="h-8 w-px bg-[#ebe7dc] mx-1" />
            <div className="text-right">
              <span className="text-[11px] font-semibold text-[#807a6f] uppercase block">Epoch Span</span>
              <span className="text-xs font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                {countryProfile.historicalSpan}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Pick Country Buttons & Full Search Selector */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-[#f8f6f0] border border-[#ded9cc] mb-6">
          
          {/* Quick Pick Chips */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-bold text-[#615d54] uppercase mr-1">Quick Picks:</span>
            {featuredQuickPicks.map((pick) => {
              const isSelected = selectedCountryId === pick.id;
              return (
                <button
                  key={pick.id}
                  id={`btn-country-pick-${pick.id}`}
                  onClick={() => setSelectedCountryId(pick.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#1a1a1a] text-white shadow-xs'
                      : 'bg-white border border-[#ded9cc] text-[#44403c] hover:bg-[#eae5d8]'
                  }`}
                >
                  <span>{pick.flag}</span>
                  <span>{pick.name}</span>
                </button>
              );
            })}
          </div>

          {/* Full 195 Country Dropdown Selector */}
          <div className="relative">
            <button
              id="btn-open-country-history-dropdown"
              onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-white border border-[#ded9cc] text-xs font-bold text-[#1a1a1a] hover:border-[#1a1a1a] transition-all cursor-pointer shadow-xs"
            >
              <span>{countryProfile.flag}</span>
              <span>{countryProfile.countryName} ({countryProfile.region})</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#78716c]" />
            </button>

            {isCountryDropdownOpen && (
              <div className="absolute right-0 mt-2 w-72 sm:w-80 rounded-xl bg-white border border-[#ded9cc] shadow-xl z-30 p-3 space-y-2 animate-in fade-in duration-150">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#78716c]" />
                  <input
                    type="text"
                    id="input-search-history-country"
                    placeholder="Search any of 195 UN countries..."
                    value={countrySearchQuery}
                    onChange={(e) => setCountrySearchQuery(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs rounded-md bg-[#f8f6f0] border border-[#ded9cc] text-[#1a1a1a] focus:outline-none focus:border-[#1a1a1a]"
                  />
                </div>

                <div className="max-h-56 overflow-y-auto space-y-1 divide-y divide-[#f0ece1]">
                  {filteredCountryList.map((country) => (
                    <button
                      key={country.id}
                      onClick={() => {
                        setSelectedCountryId(country.id);
                        setIsCountryDropdownOpen(false);
                      }}
                      className="w-full text-left flex items-center justify-between px-2 py-1.5 text-xs hover:bg-[#f8f6f0] rounded transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2 font-medium text-[#1a1a1a]">
                        <span>{country.flag}</span>
                        <span>{country.name}</span>
                      </span>
                      <span className="text-[10px] text-[#78716c]">{country.region}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Foundational Quote & Civilizations Ribbon */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-[#e7e4dc] mb-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Quote className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs sm:text-sm text-[#44403c] italic leading-relaxed">
                "{countryProfile.foundationalQuote}"
              </p>
              <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                <span className="text-[11px] font-bold text-[#807a6f] uppercase">Major Civilizations:</span>
                {countryProfile.keyCivilizations.map((civ, i) => (
                  <span
                    key={i}
                    className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-[#57534e]"
                  >
                    {civ}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {onSelectCountryDetails && (
            <button
              id="btn-view-full-profile-from-history"
              onClick={() => onSelectCountryDetails(countryProfile.countryId)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#f0ece1] hover:bg-[#e2ded5] text-[#1a1a1a] text-xs font-bold transition-colors cursor-pointer flex-shrink-0"
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-800" />
              Full Country Profile
            </button>
          )}
        </div>

        {/* Interactive Controls Bar: Filter by Era, Category, Search, and Timeline Controls */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 p-4 rounded-xl bg-white border border-[#e7e4dc] mb-4 shadow-xs">
          
          {/* Era Filter Chips */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-bold text-[#78716c] uppercase mr-1">Era:</span>
            {(['All', 'Ancient', 'Classical', 'Medieval', 'Early Modern', 'Modern', 'Contemporary'] as const).map((era) => (
              <button
                key={era}
                id={`btn-era-${era.toLowerCase().replace(' ', '-')}`}
                onClick={() => setSelectedEra(era)}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  selectedEra === era
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'bg-[#f8f6f0] text-[#57534e] hover:bg-[#eae5d8] border border-[#ebe7dc]'
                }`}
              >
                {era}
              </button>
            ))}
          </div>

          {/* D3 Zoom and Autoplay Controls */}
          <div className="flex flex-wrap items-center gap-2 justify-end">
            
            {/* Autoplay Tour Button */}
            <button
              id="btn-tour-autoplay"
              onClick={() => setIsPlayingTour(!isPlayingTour)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isPlayingTour
                  ? 'bg-amber-600 text-white animate-pulse'
                  : 'bg-[#f0ece1] text-[#1a1a1a] hover:bg-[#e2ded5] border border-[#ded9cc]'
              }`}
            >
              {isPlayingTour ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlayingTour ? 'Pause Tour' : 'Autoplay Tour'}</span>
            </button>

            {/* D3 Zoom Controls */}
            <div className="flex items-center bg-[#f8f6f0] rounded-lg border border-[#ded9cc] p-0.5">
              <button
                id="btn-d3-zoom-in"
                onClick={handleZoomIn}
                title="Zoom In Timeline"
                className="p-1.5 text-[#57534e] hover:text-[#1a1a1a] hover:bg-white rounded transition-colors cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                id="btn-d3-zoom-out"
                onClick={handleZoomOut}
                title="Zoom Out Timeline"
                className="p-1.5 text-[#57534e] hover:text-[#1a1a1a] hover:bg-white rounded transition-colors cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                id="btn-d3-zoom-reset"
                onClick={handleResetZoom}
                title="Reset Timeline View"
                className="p-1.5 text-[#57534e] hover:text-[#1a1a1a] hover:bg-white rounded transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>

        {/* Category Filters and In-Timeline Search */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6">
          <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
            <span className="text-[11px] font-bold text-[#78716c] uppercase mr-1">Category:</span>
            {(['All', 'Politics & Empires', 'Culture & Arts', 'Science & Innovation', 'Conflict & Peace', 'Architecture & Wonders'] as const).map(
              (cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-[11px] font-semibold px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-amber-900 text-white'
                      : 'bg-white border border-[#ebe7dc] text-[#615d54] hover:bg-[#f8f6f0]'
                  }`}
                >
                  {cat}
                </button>
              )
            )}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#78716c]" />
            <input
              type="text"
              id="input-filter-events-text"
              placeholder="Search historical events..."
              value={eventSearchQuery}
              onChange={(e) => setEventSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-white border border-[#ded9cc] text-[#1a1a1a] focus:outline-none focus:border-[#1a1a1a]"
            />
          </div>
        </div>

        {/* D3 Interactive Timeline Visualizer Canvas */}
        <div
          ref={containerRef}
          className="relative w-full bg-white rounded-2xl border border-[#e7e4dc] p-2 sm:p-4 shadow-sm overflow-hidden mb-8"
        >
          {/* Top Instruction Pill */}
          <div className="flex items-center justify-between px-3 py-2 border-b border-[#f0ece1] text-xs text-[#78716c]">
            <span className="flex items-center gap-1.5 font-medium">
              <Compass className="w-3.5 h-3.5 text-amber-700" />
              Scroll / Drag canvas to pan across centuries • Click any node to inspect historical details
            </span>
            <span className="font-bold text-[#1a1a1a]">
              Showing {filteredEvents.length} of {countryProfile.events.length} Milestones
            </span>
          </div>

          {/* D3 Rendered SVG */}
          <div className="w-full overflow-x-auto cursor-grab active:cursor-grabbing select-none py-2">
            <svg ref={svgRef} className="w-full" style={{ minWidth: '600px' }} />
          </div>

          {/* Era Legend Bar */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-3 border-t border-[#f0ece1] text-xs">
            {Object.entries(ERA_COLORS).map(([eraName, colorHex]) => (
              <div key={eraName} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: colorHex }} />
                <span className="text-[#615d54] font-medium">{eraName}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Event Deep Dive Card / Inspector */}
        {activeEvent && (
          <div
            id={`event-inspector-${activeEvent.id}`}
            className="rounded-2xl bg-white border border-[#ded9cc] shadow-md p-6 sm:p-8 animate-in fade-in duration-200"
          >
            {/* Header: Year, Era, Category Badges & Navigation Buttons */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#ebe7dc]">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-lg bg-[#1a1a1a] text-white text-xs font-bold font-mono tracking-wide">
                  {activeEvent.yearDisplay}
                </span>
                <span
                  className="px-2.5 py-0.5 rounded-md text-xs font-bold text-white"
                  style={{ backgroundColor: ERA_COLORS[activeEvent.era] || '#d97706' }}
                >
                  {activeEvent.era} Era
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-md text-xs font-bold border ${
                    CATEGORY_COLORS[activeEvent.category]?.bg || 'bg-stone-50'
                  } ${CATEGORY_COLORS[activeEvent.category]?.border || 'border-stone-200'} ${
                    CATEGORY_COLORS[activeEvent.category]?.text || 'text-stone-800'
                  }`}
                >
                  {activeEvent.category}
                </span>
                <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
                  ★ {activeEvent.significance}
                </span>
              </div>

              {/* Prev / Next Event Step Controls */}
              <div className="flex items-center gap-1.5 self-end sm:self-auto">
                <button
                  id="btn-prev-history-event"
                  onClick={handlePrevEvent}
                  className="p-2 rounded-lg bg-[#f8f6f0] hover:bg-[#eae5d8] border border-[#ded9cc] text-[#1a1a1a] transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                >
                  <ChevronLeft className="w-4 h-4" /> Prev
                </button>
                <button
                  id="btn-next-history-event"
                  onClick={handleNextEvent}
                  className="p-2 rounded-lg bg-[#f8f6f0] hover:bg-[#eae5d8] border border-[#ded9cc] text-[#1a1a1a] transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                >
                  Next <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Event Title and Body Details */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-6">
              
              {/* Left 2 Columns: Narrative & Impact */}
              <div className="lg:col-span-2 space-y-5">
                <div>
                  <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#1a1a1a] leading-tight">
                    {activeEvent.title}
                  </h3>
                  {activeEvent.location && (
                    <div className="flex items-center gap-1.5 text-xs text-[#78716c] font-medium mt-1">
                      <MapPin className="w-3.5 h-3.5 text-amber-700" />
                      <span>{activeEvent.location}</span>
                    </div>
                  )}
                </div>

                <p className="text-sm sm:text-base text-[#44403c] font-medium leading-relaxed bg-[#fcfbf7] p-4 rounded-xl border border-[#ebe7dc]">
                  {activeEvent.summary}
                </p>

                <p className="text-sm sm:text-base text-[#44403c] leading-relaxed">
                  {activeEvent.detailedDescription}
                </p>

                {/* Historic Impact Box */}
                <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 uppercase">
                    <Award className="w-4 h-4 text-amber-700" />
                    Historical Impact & Global Significance
                  </div>
                  <p className="text-xs sm:text-sm text-amber-950 font-medium leading-relaxed">
                    {activeEvent.historicalImpact}
                  </p>
                </div>

                {/* Key Figures */}
                {activeEvent.keyFigures && activeEvent.keyFigures.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 pt-2">
                    <span className="text-xs font-bold text-[#78716c] flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" /> Key Figures:
                    </span>
                    {activeEvent.keyFigures.map((fig, i) => (
                      <span
                        key={i}
                        className="text-xs font-bold px-2.5 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#1a1a1a]"
                      >
                        {fig}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Image & Quote */}
              <div className="space-y-5">
                {activeEvent.image ? (
                  <div className="relative rounded-xl overflow-hidden border border-[#ded9cc] shadow-xs group h-56 sm:h-64">
                    <img
                      src={activeEvent.image}
                      alt={activeEvent.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/70 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3 text-white text-xs font-bold flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-amber-300" />
                      <span>{activeEvent.yearDisplay} • {countryProfile.countryName}</span>
                    </div>
                  </div>
                ) : (
                  <div className="p-6 rounded-xl bg-[#f8f6f0] border border-[#ded9cc] flex flex-col items-center justify-center text-center h-48 space-y-2">
                    <span className="text-4xl">{countryProfile.flag}</span>
                    <span className="font-heading font-bold text-sm text-[#1a1a1a]">{countryProfile.countryName} History</span>
                    <span className="text-xs text-[#78716c]">{activeEvent.yearDisplay}</span>
                  </div>
                )}

                {activeEvent.quoteOrExcerpt && (
                  <div className="p-4 rounded-xl bg-[#f8f6f0] border border-[#ded9cc] space-y-2">
                    <Quote className="w-4 h-4 text-amber-700" />
                    <p className="text-xs sm:text-sm text-[#44403c] italic leading-relaxed">
                      "{activeEvent.quoteOrExcerpt}"
                    </p>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
