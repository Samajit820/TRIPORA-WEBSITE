import React from 'react';
import {
  X, MapPin, Calendar, Clock, Utensils, Compass, Sparkles,
  Bookmark, Camera, Building2, Trees, Lightbulb, ChevronRight, Share2, Check
} from 'lucide-react';
import { CityItem, CountryDetail } from '../types';
import { CITIES_DATA } from '../data/cities';
import { DETAILED_COUNTRIES, ALL_195_COUNTRIES } from '../data/countries';

interface CityDetailModalProps {
  cityId: string | null;
  onClose: () => void;
  onToggleSave: (cityName: string) => void;
  isSaved: boolean;
}

export const CityDetailModal: React.FC<CityDetailModalProps> = ({
  cityId,
  onClose,
  onToggleSave,
  isSaved
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!cityId) return null;

  // 1. Check curated CITIES_DATA by ID or Name
  let foundCity: CityItem | undefined = CITIES_DATA.find(
    (c) => c.id.toLowerCase() === cityId.toLowerCase() || c.name.toLowerCase() === cityId.toLowerCase()
  );

  // 2. If not found, check if it's a known capital or popular city in DETAILED_COUNTRIES or ALL_195_COUNTRIES
  if (!foundCity) {
    const parentDetailed = DETAILED_COUNTRIES.find(
      (c) =>
        c.capital.toLowerCase() === cityId.toLowerCase() ||
        c.popularCities?.some((pc) => pc.toLowerCase() === cityId.toLowerCase()) ||
        c.name.toLowerCase() === cityId.toLowerCase()
    );

    const parentFallback = ALL_195_COUNTRIES.find(
      (c) =>
        c.capital.toLowerCase() === cityId.toLowerCase() ||
        c.name.toLowerCase() === cityId.toLowerCase()
    );

    const country = parentDetailed || parentFallback;
    const countryName = country?.name || 'Sovereign Nation';
    const capitalName = country?.capital || cityId;
    const isCapital = capitalName.toLowerCase() === cityId.toLowerCase();

    foundCity = {
      id: cityId.toLowerCase().replace(/\s+/g, '-'),
      name: cityId,
      country: countryName,
      countryCode: (country as any)?.code || (country as any)?.isoCode || 'XX',
      continent: country?.continent || 'asia',
      region: country?.region || 'Global',
      cityType: isCapital ? 'Capital City' : 'Regional Metropolis',
      tagline: `Vibrant Urban Center of ${countryName}`,
      population: (country as any)?.population ? `${(country as any).population} (National Context)` : 'Urban Hub',
      overview: `${cityId} is a prominent cultural, historic, and economic center located in ${countryName}. It serves as a vital destination showcasing the nation's unique regional traditions, local gastronomy, and rich architectural heritage.`,
      historySnippet: `Established as a key settlement in ${countryName}, ${cityId} has evolved across centuries of regional history, trade, and cultural development into a modern focal point of the nation.`,
      history: `Established as a key settlement in ${countryName}, ${cityId} has evolved across centuries of regional history, trade, and cultural development into a modern focal point of the nation.`,
      famousPlaces: [
        `${cityId} Central Plaza & Old Town`,
        `National Cultural Center of ${countryName}`,
        `Historic Waterfront & Promenade`,
        `Grand Bazaar & Local Artisan Market`,
        `City Heritage Museum`
      ],
      attractions: [
        `Main Cathedral / Grand Mosque / Temple of ${cityId}`,
        `Botanical Gardens & Public Parks`,
        `Historic Fortress / City Gates`,
        `Observation Point & Skyline Overlook`
      ],
      localFood: [
        `Traditional ${countryName} Roasted Specialties`,
        `Fresh Regional Breads & Savory Pastries`,
        `Local Spiced Stews & Rice Dishes`,
        `Artisan Sweets & Herbal Infusions`
      ],
      famousFood: [
        `Traditional ${countryName} Specialties`,
        `Fresh Regional Flatbreads`,
        `Spiced Meat & Vegetable Stews`,
        `Artisan Local Pastries`
      ],
      cultureHighlights: `Vibrant street markets, welcoming local hospitality, musical and folk festivals, and time-honored artisanal handicraft workshops.`,
      architectureStyle: `A captivating blend of classical regional architecture, traditional masonry, and contemporary civic urban design.`,
      natureSpots: [
        `Municipal Botanical Garden`,
        `Riverside & Lakefront Promenade`,
        `Nearby Scenic Hillside Lookouts`
      ],
      activities: [
        `Walk the historic Old Quarter cobblestone avenues`,
        `Sample freshly prepared regional dishes at local market stalls`,
        `Visit top museums and heritage monuments`,
        `Capture golden-hour photos from panoramic viewpoints`
      ],
      dayTrips: [
        `Historic country villages and scenic countryside (1 hr)`,
        `Nearby national parks & nature preserves (1.5 hrs)`,
        `Ancient fortresses and archaeological sites (2 hrs)`
      ],
      travelTips: [
        `Respect local customs and modest dress codes when visiting sacred sites.`,
        `Keep small local currency notes handy for markets and public transportation.`,
        `Early morning is the best time for photography and avoiding busy crowds.`
      ],
      secretTip: `Head to the highest historic viewpoint or rooftop cafe near the old quarter at sunset for an unforgettable golden view across the city rooftops.`,
      image: (country as any)?.heroImage || 'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?auto=format&fit=crop&w=800&q=80',
      gallery: (country as any)?.gallery || [
        'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80'
      ],
      interestingFacts: [
        `${cityId} plays a central role in the economy and cultural identity of ${countryName}.`,
        `The city is known for its distinctive blend of historical heritage and dynamic modern growth.`
      ],
      idealDurationDays: 3,
      idealStayDays: 3,
      bestMonthsToVisit: 'Spring & Autumn (Optimal Weather)',
      bestMonths: 'Spring & Autumn'
    };
  }

  const city = foundCity;

  // Normalized safe field access
  const historyText = city.history || city.historySnippet || city.overview;
  const foodList = city.famousFood || city.localFood || ['Regional specialties', 'Local delicacies'];
  const placesList = city.famousPlaces || city.attractions || [];
  const dayTripsList = city.dayTrips || city.nearbyDestinations || [];
  const secretTipText = city.secretTip || (city.travelTips && city.travelTips[0]) || 'Explore the local markets in the early morning for the freshest produce and authentic artisan crafts.';
  const idealDays = city.idealDurationDays || city.idealStayDays || 3;
  const bestMonthsText = city.bestMonthsToVisit || city.bestMonths || 'Year-round';
  const taglineText = city.tagline || `${city.cityType} in ${city.country}`;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-4xl rounded-2xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[92vh] z-10 text-[#1a1a1a] animate-in zoom-in-95 duration-150">
        
        {/* Hero Header */}
        <div className="relative h-56 sm:h-72 overflow-hidden flex-shrink-0">
          <img src={city.image} alt={city.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/50 to-[#1a1a1a]/20" />

          {/* Top Action Bar */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
            <span className="px-3 py-1 rounded-md bg-[#1a1a1a]/85 backdrop-blur-xs text-[11px] sm:text-xs font-bold text-white uppercase tracking-wider border border-white/15">
              {city.cityType}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleShare}
                className="p-2 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-white hover:bg-[#1a1a1a] transition-colors cursor-pointer"
                title="Share City"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>
              <button
                onClick={() => onToggleSave(city.name)}
                className={`p-2 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                  isSaved
                    ? 'bg-amber-400 text-stone-950 font-bold'
                    : 'bg-[#1a1a1a]/80 text-white hover:text-amber-300'
                }`}
                title="Save to bucket list"
              >
                <Bookmark className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-md bg-[#1a1a1a]/80 text-white hover:bg-rose-700 transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Title & Location Banner */}
          <div className="absolute bottom-4 left-4 sm:left-6 right-4 sm:right-6">
            <div className="flex items-center gap-2 text-xs uppercase font-bold tracking-wider text-amber-300 mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{city.country} • {taglineText}</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black text-white drop-shadow-md">
              {city.name}
            </h2>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-6 flex-1 text-[#2d2a24]">
          
          {/* Quick Travel Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 text-xs">
            <div className="p-3 sm:p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs">
              <span className="text-[#7a7467] block text-[10px] uppercase font-bold tracking-wide">Population</span>
              <strong className="text-[#1a1a1a] text-sm mt-0.5 block truncate">{city.population}</strong>
            </div>
            <div className="p-3 sm:p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs">
              <span className="text-[#7a7467] block text-[10px] uppercase font-bold tracking-wide">Ideal Duration</span>
              <strong className="text-amber-900 text-sm mt-0.5 block">{idealDays} Days Stay</strong>
            </div>
            <div className="p-3 sm:p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs">
              <span className="text-[#7a7467] block text-[10px] uppercase font-bold tracking-wide">Best Season</span>
              <strong className="text-emerald-800 text-sm mt-0.5 block truncate">{bestMonthsText}</strong>
            </div>
            <div className="p-3 sm:p-3.5 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs">
              <span className="text-[#7a7467] block text-[10px] uppercase font-bold tracking-wide">Archetype</span>
              <strong className="text-teal-800 text-sm mt-0.5 block truncate">{city.cityType}</strong>
            </div>
          </div>

          {/* Overview & History */}
          <div className="space-y-3">
            <h3 className="font-heading text-base sm:text-lg font-bold text-[#1a1a1a]">Overview & City Spirit</h3>
            <p className="text-sm text-[#4a473e] leading-relaxed">{city.overview}</p>
            
            <div className="p-4 rounded-xl bg-[#f8f6f0] border border-[#ebe7dc] text-xs text-[#4a473e]">
              <strong className="text-[#1a1a1a] block mb-1 text-sm">🏛️ Historical Roots & Evolution</strong>
              <p className="leading-relaxed">{historyText}</p>
            </div>
          </div>

          {/* Famous Places & Must-Visit Sights */}
          <div>
            <h3 className="font-heading text-base sm:text-lg font-bold text-[#1a1a1a] mb-3">Famous Places & Key Landmarks</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {placesList.map((place, idx) => (
                <div key={idx} className="flex items-center gap-2.5 p-3 rounded-xl bg-white border border-[#e7e4dc] text-xs sm:text-sm text-[#1a1a1a] shadow-2xs hover:border-[#1a1a1a]/40 transition-colors">
                  <MapPin className="w-4 h-4 text-teal-800 flex-shrink-0" />
                  <span className="font-semibold">{place}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Local Gastronomy & Food */}
          <div className="p-4 sm:p-5 rounded-xl bg-[#fbf5ea] border border-[#eedab2]">
            <h3 className="font-heading text-base font-bold text-amber-950 flex items-center gap-2 mb-3">
              <Utensils className="w-4 h-4 text-amber-800" />
              Iconic Culinary Dishes & Tastes in {city.name}
            </h3>
            <div className="flex flex-wrap gap-2">
              {foodList.map((food, i) => (
                <span key={i} className="px-3 py-1.5 rounded-lg bg-white border border-[#e7e4dc] text-xs font-semibold text-[#1a1a1a] shadow-2xs">
                  🍲 {food}
                </span>
              ))}
            </div>
          </div>

          {/* Culture & Architecture Snippets (If available) */}
          {(city.cultureHighlights || city.architectureStyle) && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {city.cultureHighlights && (
                <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs space-y-1">
                  <span className="font-bold text-[#1a1a1a] uppercase text-[10px] tracking-wider text-rose-800 block">Culture & Lifestyle</span>
                  <p className="text-[#4a473e] leading-relaxed">{city.cultureHighlights}</p>
                </div>
              )}
              {city.architectureStyle && (
                <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs space-y-1">
                  <span className="font-bold text-[#1a1a1a] uppercase text-[10px] tracking-wider text-indigo-800 block">Architectural Character</span>
                  <p className="text-[#4a473e] leading-relaxed">{city.architectureStyle}</p>
                </div>
              )}
            </div>
          )}

          {/* Day Trips & Insider Secrets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 shadow-2xs">
              <h4 className="font-bold text-xs uppercase text-[#7a7467] flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-teal-800" /> Popular Day Trips & Excursions
              </h4>
              <ul className="text-xs text-[#4a473e] space-y-1.5">
                {dayTripsList.map((dt, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-teal-700 font-bold">•</span>
                    <span>{dt}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] space-y-2 shadow-2xs">
              <h4 className="font-bold text-xs uppercase text-[#7a7467] flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-amber-700" /> Insider Secret Tip
              </h4>
              <p className="text-xs text-[#4a473e] leading-relaxed italic">
                "{secretTipText}"
              </p>
            </div>
          </div>

          {/* Interesting Facts */}
          {city.interestingFacts && city.interestingFacts.length > 0 && (
            <div className="p-4 rounded-xl bg-white border border-[#e7e4dc] shadow-2xs">
              <h4 className="font-bold text-xs uppercase text-[#7a7467] flex items-center gap-1.5 mb-2.5">
                <Sparkles className="w-4 h-4 text-amber-600" /> Fascinating Facts about {city.name}
              </h4>
              <div className="space-y-1.5 text-xs text-[#4a473e]">
                {city.interestingFacts.map((fact, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="text-amber-600 font-bold">•</span>
                    <span>{fact}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* City Visual Gallery */}
          {city.gallery && city.gallery.length > 0 && (
            <div>
              <h4 className="font-heading text-sm font-bold text-[#1a1a1a] mb-2.5 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-teal-800" /> Visual Gallery of {city.name}
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {city.gallery.map((img, i) => (
                  <div key={i} className="h-28 sm:h-36 rounded-xl overflow-hidden border border-[#e7e4dc]">
                    <img src={img} alt={`${city.name} view ${i + 1}`} className="w-full h-full object-cover hover:scale-105 transition-transform" />
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-4 sm:px-6 py-3 bg-[#f0ece1] border-t border-[#e2ded5] flex items-center justify-between">
          <div className="text-xs text-[#78716c] font-medium">
            TRIPORA Planetary City Atlas
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
