import React, { useState } from 'react';
import { Search, Sparkles, ArrowRight, Globe, Compass, ShieldCheck } from 'lucide-react';

interface SearchableHeroTitleProps {
  onOpenSearch: (initialQuery?: string) => void;
  totalCountriesCount?: number;
  totalCitiesCount?: number;
}

export const SearchableHeroTitle: React.FC<SearchableHeroTitleProps> = ({
  onOpenSearch,
  totalCountriesCount = 195,
  totalCitiesCount = 50
}) => {
  const [localSearchInput, setLocalSearchInput] = useState('');

  const quickPopularSearches = [
    { label: 'India', flag: '🇮🇳', query: 'India' },
    { label: 'Japan', flag: '🇯🇵', query: 'Japan' },
    { label: 'France', flag: '🇫🇷', query: 'France' },
    { label: 'Italy', flag: '🇮🇹', query: 'Italy' },
    { label: 'Kolkata', flag: '🏛️', query: 'Kolkata' },
    { label: 'Tokyo', flag: '🗼', query: 'Tokyo' },
    { label: 'Swiss Alps', flag: '🏔️', query: 'Alps' }
  ];

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearchInput.trim()) {
      onOpenSearch(localSearchInput.trim());
    } else {
      onOpenSearch();
    }
  };

  return (
    <div className="relative w-full overflow-hidden bg-gradient-to-b from-[#f8f6f0] via-[#fcfbf7] to-[#fcfbf7] border-b border-[#e7e4dc] py-8 sm:py-14 lg:py-16">
      {/* Subtle Background Planetary Coordinates Grid */}
      <div className="absolute inset-0 opacity-[0.035] pointer-events-none bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:24px_24px]" />
      
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center flex flex-col items-center">
        
        {/* Top Eyebrow Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 sm:px-3.5 sm:py-1.5 rounded-full bg-white/90 border border-[#ded9cc] shadow-2xs text-[#44403c] text-[11px] sm:text-xs font-bold tracking-wide uppercase mb-4 sm:mb-6 animate-in fade-in duration-300">
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          <Globe className="w-3.5 h-3.5 text-amber-700" />
          <span>Earth's Sovereign Atlas • 195 UN Member States</span>
        </div>

        {/* Primary Searchable Title & Subtitle */}
        <h1 className="font-heading text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-[#1a1a1a] tracking-tight leading-[1.15] max-w-3xl mb-3 sm:mb-4">
          Discover Every Nation, City &amp; Wonder on Earth
        </h1>
        
        <p className="text-sm sm:text-base lg:text-lg text-[#57534e] max-w-2xl leading-relaxed mb-6 sm:mb-8 px-2">
          The definitive planetary encyclopedia. Explore historical timelines, official visa guidelines, daily travel budgets, and cultural secrets for <span className="font-bold text-[#1a1a1a]">{totalCountriesCount} sovereign countries</span>.
        </p>

        {/* Live Interactive Hero Search Input Bar */}
        <div className="w-full max-w-2xl">
          <form
            onSubmit={handleFormSubmit}
            className="relative flex items-center bg-white rounded-2xl border-2 border-[#ded9cc] focus-within:border-[#1a1a1a] focus-within:ring-4 focus-within:ring-[#1a1a1a]/10 shadow-lg p-1.5 sm:p-2.5 transition-all duration-200"
          >
            <div className="pl-2.5 sm:pl-4 text-[#78716c]">
              <Search className="w-5 h-5 text-[#78716c]" />
            </div>

            <input
              type="text"
              id="hero-main-search-input"
              value={localSearchInput}
              onChange={(e) => setLocalSearchInput(e.target.value)}
              placeholder="Search any of 195 countries, capitals, landmarks, foods..."
              className="w-full px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-base font-medium text-[#1a1a1a] placeholder:text-[#a8a29e] bg-transparent focus:outline-none"
            />

            <div className="flex items-center gap-1.5 sm:gap-2 pr-1">
              <kbd className="hidden md:inline-flex items-center gap-0.5 px-2 py-1 text-[11px] font-mono font-bold bg-[#f4f1ea] text-[#78716c] rounded-md border border-[#dfdbd1]">
                ⌘K
              </kbd>
              <button
                type="submit"
                id="btn-hero-search-submit"
                className="inline-flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 rounded-xl bg-[#1a1a1a] hover:bg-[#33302a] text-white text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer flex-shrink-0"
              >
                <span>Search</span>
                <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>
            </div>
          </form>

          {/* Quick Filter Search Pills */}
          <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 mt-3.5 sm:mt-4 text-xs">
            <span className="font-bold text-[#78716c] flex items-center gap-1 text-[11px] sm:text-xs">
              <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-600" /> Popular:
            </span>
            {quickPopularSearches.map((item) => (
              <button
                key={item.label}
                id={`quick-search-${item.label.toLowerCase()}`}
                type="button"
                onClick={() => onOpenSearch(item.query)}
                className="inline-flex items-center gap-1 px-2.5 sm:px-3 py-1 rounded-full bg-white hover:bg-[#f0ece1] border border-[#ded9cc] text-[#44403c] text-[11px] sm:text-xs font-medium transition-all shadow-2xs hover:border-[#1a1a1a] cursor-pointer"
              >
                <span>{item.flag}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Feature Credential Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-4 mt-8 sm:mt-12 pt-6 sm:pt-8 border-t border-[#e7e4dc] w-full max-w-4xl text-left">
          <div className="p-2.5 sm:p-3 rounded-xl bg-white/70 border border-[#ded9cc]/60 shadow-2xs">
            <div className="text-lg sm:text-2xl font-heading font-black text-[#1a1a1a]">195</div>
            <div className="text-[11px] sm:text-xs font-semibold text-[#78716c]">UN Sovereign Nations</div>
          </div>
          <div className="p-2.5 sm:p-3 rounded-xl bg-white/70 border border-[#ded9cc]/60 shadow-2xs">
            <div className="text-lg sm:text-2xl font-heading font-black text-[#1a1a1a]">5,000+</div>
            <div className="text-[11px] sm:text-xs font-semibold text-[#78716c]">Historical Eras &amp; Events</div>
          </div>
          <div className="p-2.5 sm:p-3 rounded-xl bg-white/70 border border-[#ded9cc]/60 shadow-2xs">
            <div className="text-lg sm:text-2xl font-heading font-black text-[#1a1a1a]">7</div>
            <div className="text-[11px] sm:text-xs font-semibold text-[#78716c]">Continents &amp; Oceans</div>
          </div>
          <div className="p-2.5 sm:p-3 rounded-xl bg-white/70 border border-[#ded9cc]/60 shadow-2xs">
            <div className="text-lg sm:text-2xl font-heading font-black text-[#1a1a1a]">100%</div>
            <div className="text-[11px] sm:text-xs font-semibold text-[#78716c]">Visa &amp; Budget Profiles</div>
          </div>
        </div>

      </div>
    </div>
  );
};
