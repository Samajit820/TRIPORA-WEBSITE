import React, { useState, useMemo } from 'react';
import { Globe, Search, Filter, Shield, ChevronRight, Bookmark, Check, Sparkles } from 'lucide-react';
import { ALL_195_COUNTRIES, DETAILED_COUNTRIES } from '../data/countries';
import { ContinentCode } from '../types';

interface CountriesSectionProps {
  selectedContinent: ContinentCode | 'all';
  onSelectContinent: (continent: ContinentCode | 'all') => void;
  onSelectCountry: (countryId: string) => void;
  savedCountries: string[];
  onToggleSaveCountry: (countryName: string) => void;
}

export const CountriesSection: React.FC<CountriesSectionProps> = ({
  selectedContinent,
  onSelectContinent,
  onSelectCountry,
  savedCountries,
  onToggleSaveCountry
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'featured' | 'all195'>('featured');

  const filteredCountries = useMemo(() => {
    return ALL_195_COUNTRIES.filter((c) => {
      const matchContinent = selectedContinent === 'all' || c.continent === selectedContinent;
      const matchSearch =
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.capital.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.region.toLowerCase().includes(searchQuery.toLowerCase());
      return matchContinent && matchSearch;
    });
  }, [selectedContinent, searchQuery]);

  const continentFilters: { id: ContinentCode | 'all'; label: string }[] = [
    { id: 'all', label: 'All 195 Nations' },
    { id: 'asia', label: 'Asia (48)' },
    { id: 'europe', label: 'Europe (44)' },
    { id: 'africa', label: 'Africa (54)' },
    { id: 'north-america', label: 'North America (23)' },
    { id: 'south-america', label: 'South America (12)' },
    { id: 'oceania', label: 'Oceania (14)' }
  ];

  return (
    <section id="countries" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Globe className="w-3.5 h-3.5" />
              Chapter 02 • Global Nations Directory
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              The 195 Sovereign Countries
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              Every country on Earth featuring flag, capital city, population, currency, travel seasons, safety indexes, and cultural encyclopedia records.
            </p>
          </div>

          {/* Toggle between Featured Visual Profiles and Full Directory */}
          <div className="flex items-center p-1 bg-[#f0ece1] border border-[#e2ded5] rounded-lg">
            <button
              onClick={() => setViewMode('featured')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'featured'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#5a564e] hover:text-[#1a1a1a]'
              }`}
            >
              Featured Profiles ({DETAILED_COUNTRIES.length})
            </button>
            <button
              onClick={() => setViewMode('all195')}
              className={`px-4 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                viewMode === 'all195'
                  ? 'bg-[#1a1a1a] text-white shadow-xs'
                  : 'text-[#5a564e] hover:text-[#1a1a1a]'
              }`}
            >
              Complete 195 Directory
            </button>
          </div>
        </div>

        {/* Filters & Search Toolbar */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-8">
          
          {/* Continent Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full lg:w-auto scrollbar-none pb-2 lg:pb-0">
            {continentFilters.map((f) => (
              <button
                key={f.id}
                onClick={() => onSelectContinent(f.id)}
                className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  selectedContinent === f.id
                    ? 'bg-[#1a1a1a] text-white'
                    : 'bg-white border border-[#e7e4dc] text-[#555148] hover:text-[#1a1a1a] hover:bg-[#f7f5ee]'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Search bar inside section */}
          <div className="relative w-full lg:w-72">
            <Search className="w-4 h-4 text-[#8a8477] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter countries, capitals..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-[#e2ded5] rounded-lg text-xs text-[#1a1a1a] placeholder:text-[#8a8477] focus:outline-none focus:border-[#1a1a1a] shadow-xs"
            />
          </div>

        </div>

        {/* VIEW 1: FEATURED VISUAL COUNTRY CARDS */}
        {viewMode === 'featured' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {DETAILED_COUNTRIES.filter(
              (c) =>
                (selectedContinent === 'all' || c.continent === selectedContinent) &&
                (c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  c.capital.toLowerCase().includes(searchQuery.toLowerCase()))
            ).map((country) => {
              const isSaved = savedCountries.includes(country.name);
              return (
                <div
                  key={country.id}
                  className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs"
                >
                  {/* Card Top Image & Flag */}
                  <div className="relative h-52 overflow-hidden cursor-pointer" onClick={() => onSelectCountry(country.id)}>
                    <img
                      src={country.heroImage}
                      alt={country.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                    
                    {/* Country Flag & Region Badge */}
                    <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                      <span className="text-2xl shadow-sm">{country.flag}</span>
                      <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                        {country.region}
                      </span>
                    </div>

                    {/* Bookmark action */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleSaveCountry(country.name);
                      }}
                      className={`absolute top-3.5 right-3.5 p-2 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                        isSaved
                          ? 'bg-[#1a1a1a] text-white'
                          : 'bg-[#1a1a1a]/70 text-stone-200 hover:text-white'
                      }`}
                      title={isSaved ? 'Remove from Saved' : 'Save Country'}
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                    </button>

                    {/* Country Name on Image */}
                    <div className="absolute bottom-3 left-4 right-4">
                      <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                        {country.subregion}
                      </div>
                      <h3 className="font-heading text-2xl font-bold text-white group-hover:text-amber-200 transition-colors">
                        {country.name}
                      </h3>
                    </div>
                  </div>

                  {/* Card Content & Key Facts */}
                  <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                    <p className="text-xs text-[#48453e] line-clamp-2 leading-relaxed">
                      {country.overview}
                    </p>

                    {/* Quick Metric Grid */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                        <span className="text-[10px] uppercase text-[#807a6f] block font-semibold">Capital City</span>
                        <span className="font-bold text-[#1a1a1a] truncate block">{country.capital}</span>
                      </div>
                      <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                        <span className="text-[10px] uppercase text-[#807a6f] block font-semibold">Currency</span>
                        <span className="font-bold text-amber-900 truncate block">{country.currency.code} ({country.currency.symbol})</span>
                      </div>
                      <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                        <span className="text-[10px] uppercase text-[#807a6f] block font-semibold">Best Season</span>
                        <span className="font-bold text-[#1a1a1a] truncate block">{country.bestTimeToVisit?.peakSeason || 'Oct - Apr'}</span>
                      </div>
                      <div className="p-2.5 rounded-md bg-[#f8f6f0] border border-[#ebe7dc]">
                        <span className="text-[10px] uppercase text-[#807a6f] block font-semibold">Safety Score</span>
                        <span className="font-bold text-emerald-800 flex items-center gap-1">
                          <Shield className="w-3 h-3" /> {country.safetyScore ? `${country.safetyScore * 10}/100` : '85/100'}
                        </span>
                      </div>
                    </div>

                    {/* Action Button */}
                    <button
                      onClick={() => onSelectCountry(country.id)}
                      className="w-full py-2.5 rounded-lg bg-[#f4f1ea] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <span>Explore Full Profile & Travel Guide</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 2: COMPLETE 195 SOVEREIGN NATIONS DIRECTORY */}
        {viewMode === 'all195' && (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div className="text-xs text-[#757064] mb-2">
              Displaying <strong>{filteredCountries.length}</strong> of 195 sovereign nations
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredCountries.map((nation) => (
                <button
                  key={nation.id}
                  onClick={() => onSelectCountry(nation.id)}
                  className="flex items-center justify-between p-3.5 rounded-xl bg-white hover:bg-[#f7f5ee] border border-[#e7e4dc] hover:border-[#c5bea] text-left transition-all group shadow-xs cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="text-2xl flex-shrink-0">{nation.flag}</span>
                    <div className="min-w-0">
                      <h4 className="font-heading text-xs sm:text-sm font-bold text-[#1a1a1a] group-hover:text-amber-900 truncate">
                        {nation.name}
                      </h4>
                      <div className="text-[11px] text-[#757064] truncate">
                        Cap: {nation.capital} • {nation.currencyCode}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#a39c8e] group-hover:text-[#1a1a1a] group-hover:translate-x-0.5 transition-all flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
