import React, { useState } from 'react';
import { Search, Bookmark, Compass, Sun, Moon } from 'lucide-react';
import { SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { TriporaLogo } from './TriporaLogo';

interface HeaderProps {
  currentLang: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onOpenSearch: () => void;
  onOpenBucketList: () => void;
  savedCount: number;
  activeSection: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  onLanguageChange,
  onOpenSearch,
  onOpenBucketList,
  savedCount,
  activeSection
}) => {
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[currentLang];

  const navLinks = [
    { id: 'earth', label: t.exploreEarth, href: '#earth' },
    { id: 'countries', label: t.countries, href: '#countries' },
    { id: 'history', label: t.historyTimeline, href: '#history' },
    { id: 'cities', label: t.cities, href: '#cities' },
    { id: 'destinations', label: t.destinations, href: '#destinations' },
    { id: 'landmarks', label: t.landmarks, href: '#landmarks' },
    { id: 'nature-wildlife', label: t.natureWildlife, href: '#nature-wildlife' },
    { id: 'food-culture', label: t.foodCulture, href: '#food-culture' },
    { id: 'experiences', label: t.experiences, href: '#experiences' },
    { id: 'planners', label: t.planners, href: '#planners' },
    { id: 'articles', label: t.articles, href: '#articles' }
  ];

  const languages: { code: SupportedLanguage; label: string; flag: string }[] = [
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
    { code: 'bn', label: 'বাংলা', flag: '🇧🇩' },
    { code: 'es', label: 'Español', flag: '🇪🇸' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#fcfbf7]/95 backdrop-blur-md border-b border-[#e7e4dc] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo & Tagline */}
          <a href="#" className="group">
            <TriporaLogo size="md" showBadge={true} animated={true} />
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={link.href}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold tracking-wide transition-colors ${
                  activeSection === link.id
                    ? 'text-[#1a1a1a] bg-[#ebe7dc] font-bold'
                    : 'text-[#5a564e] hover:text-[#1a1a1a] hover:bg-[#f2eee4]'
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Action Tools */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Global Search Button */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white hover:bg-[#f7f5ef] text-[#2c2923] border border-[#e2ded5] shadow-xs transition-all text-xs font-medium group cursor-pointer"
              title="Search world directory (Cmd+K)"
            >
              <Search className="w-4 h-4 text-[#8c8273] group-hover:text-[#1a1a1a] transition-colors" />
              <span className="hidden md:inline">Search Directory</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-[#f4f1ea] text-[#6b665d] rounded border border-[#dfdbd1]">
                ⌘K
              </kbd>
            </button>

            {/* Language Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white hover:bg-[#f7f5ef] border border-[#e2ded5] text-xs font-medium text-[#2c2923] shadow-xs transition-colors cursor-pointer"
                title="Change language"
              >
                <span>{languages.find((l) => l.code === currentLang)?.flag}</span>
                <span className="hidden sm:inline uppercase font-bold text-[#1a1a1a]">{currentLang}</span>
              </button>

              {isLangMenuOpen && (
                <div 
                  className="absolute right-0 mt-2 w-48 rounded-lg bg-white border border-[#e2ded5] shadow-xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setIsLangMenuOpen(false)}
                >
                  <div className="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#827c71] border-b border-[#f0ece1] mb-1">
                    Language / भाषा / ভাষা
                  </div>
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        onLanguageChange(lang.code);
                        setIsLangMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                        currentLang === lang.code
                          ? 'bg-[#1a1a1a] text-white font-bold'
                          : 'text-[#33302a] hover:bg-[#f5f2e9]'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{lang.flag}</span>
                        <span>{lang.label}</span>
                      </span>
                      {currentLang === lang.code && <span className="text-[10px] font-bold">✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Saved Bucket List Drawer Trigger */}
            <button
              onClick={onOpenBucketList}
              className="relative p-2.5 rounded-lg bg-white hover:bg-[#f7f5ef] border border-[#e2ded5] text-[#2c2923] shadow-xs hover:text-amber-800 transition-colors cursor-pointer"
              title="Saved Travel Bucket List"
            >
              <Bookmark className="w-4 h-4" />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-5 h-5 px-1 bg-[#1a1a1a] text-[#fcfbf7] font-bold text-[10px] rounded-full shadow-sm">
                  {savedCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="xl:hidden p-2.5 rounded-lg bg-white border border-[#e2ded5] text-[#2c2923]"
              aria-label="Toggle navigation menu"
            >
              <Compass className={`w-5 h-5 text-[#1a1a1a] transition-transform ${isMobileMenuOpen ? 'rotate-90' : ''}`} />
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {isMobileMenuOpen && (
          <div className="xl:hidden py-3 border-t border-[#e7e4dc] grid grid-cols-2 gap-1.5 animate-in slide-in-from-top-2 duration-200">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="px-3 py-2 rounded-md text-xs font-semibold text-[#403c34] hover:text-[#1a1a1a] hover:bg-[#f4f0e6] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>
        )}

      </div>
    </header>
  );
};
