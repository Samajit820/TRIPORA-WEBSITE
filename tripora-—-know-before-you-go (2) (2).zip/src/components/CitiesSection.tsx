import React, { useState, useMemo } from 'react';
import { MapPin, Calendar, Clock, ChevronRight, Bookmark, Search, Globe, Filter } from 'lucide-react';
import { CITIES_DATA } from '../data/cities';
import { ContinentCode } from '../types';

interface CitiesSectionProps {
  onSelectCity: (cityId: string) => void;
  savedCities: string[];
  onToggleSaveCity: (cityName: string) => void;
}

export const CitiesSection: React.FC<CitiesSectionProps> = ({
  onSelectCity,
  savedCities,
  onToggleSaveCity
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedContinent, setSelectedContinent] = useState<ContinentCode | 'all'>('all');
  const [selectedType, setSelectedType] = useState<string>('all');

  const continentFilters: { id: ContinentCode | 'all'; label: string }[] = [
    { id: 'all', label: 'All Continents' },
    { id: 'asia', label: 'Asia' },
    { id: 'europe', label: 'Europe' },
    { id: 'north-america', label: 'North America' },
    { id: 'south-america', label: 'South America' },
    { id: 'africa', label: 'Africa' },
    { id: 'oceania', label: 'Oceania' }
  ];

  const cityTypes = [
    'all',
    'Mega Metropolis',
    'Historical Capital',
    'Coastal Hub',
    'Cultural Center',
    'Capital City'
  ];

  const filteredCities = useMemo(() => {
    return CITIES_DATA.filter((city) => {
      // Continent filter
      if (selectedContinent !== 'all' && city.continent !== selectedContinent) {
        return false;
      }
      // Type filter
      if (selectedType !== 'all' && !city.cityType.toLowerCase().includes(selectedType.toLowerCase())) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = city.name.toLowerCase().includes(q);
        const matchCountry = city.country.toLowerCase().includes(q);
        const matchOverview = city.overview.toLowerCase().includes(q);
        const matchPlaces = (city.famousPlaces || []).some((p) => p.toLowerCase().includes(q));
        if (!matchName && !matchCountry && !matchOverview && !matchPlaces) {
          return false;
        }
      }
      return true;
    });
  }, [selectedContinent, selectedType, searchQuery]);

  return (
    <section id="cities" className="py-16 sm:py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <MapPin className="w-3.5 h-3.5" />
              Chapter 03 • World Metropolises & Capitals
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-[#1a1a1a]">
              Cities of the World
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl leading-relaxed">
              Explore the soul, heritage, landmark sights, and iconic gastronomy of the planet's most iconic metropolises and historical capitals.
            </p>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-[#7a7467] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search cities, countries, sights..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white border border-[#e7e4dc] text-xs sm:text-sm text-[#1a1a1a] placeholder-[#8a8477] focus:outline-none focus:border-[#1a1a1a] transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#7a7467] hover:text-[#1a1a1a]"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Filters Bar: Continents & Archetypes */}
        <div className="flex flex-col gap-3 mb-8 p-3 sm:p-4 rounded-xl bg-[#f4f1ea] border border-[#e5e0d3]">
          {/* Continents Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            <span className="text-[11px] font-bold uppercase text-[#7a7467] mr-1 flex items-center gap-1 flex-shrink-0">
              <Globe className="w-3 h-3" /> Region:
            </span>
            {continentFilters.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedContinent(tab.id)}
                className={`px-3 py-1 rounded-md text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  selectedContinent === tab.id
                    ? 'bg-[#1a1a1a] text-white shadow-2xs'
                    : 'bg-white border border-[#e7e4dc] text-[#555148] hover:text-[#1a1a1a] hover:bg-[#faf9f5]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* City Type Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            <span className="text-[11px] font-bold uppercase text-[#7a7467] mr-1 flex items-center gap-1 flex-shrink-0">
              <Filter className="w-3 h-3" /> Category:
            </span>
            {cityTypes.map((type) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-3 py-1 rounded-md text-xs font-semibold transition-all capitalize whitespace-nowrap cursor-pointer ${
                  selectedType === type
                    ? 'bg-amber-900 text-white shadow-2xs'
                    : 'bg-white/80 border border-[#e7e4dc] text-[#555148] hover:text-[#1a1a1a] hover:bg-white'
                }`}
              >
                {type === 'all' ? 'All Types' : type}
              </button>
            ))}
          </div>
        </div>

        {/* Results Counter */}
        <div className="flex items-center justify-between mb-6 text-xs text-[#78716c]">
          <span>
            Showing <strong>{filteredCities.length}</strong> world {filteredCities.length === 1 ? 'city' : 'cities'}
          </span>
          {(searchQuery || selectedContinent !== 'all' || selectedType !== 'all') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedContinent('all');
                setSelectedType('all');
              }}
              className="text-amber-900 font-bold hover:underline cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Cities Grid */}
        {filteredCities.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {filteredCities.map((city) => {
              const isSaved = savedCities.includes(city.name);
              const stayDays = city.idealDurationDays || city.idealStayDays || 3;
              const season = city.bestMonthsToVisit || city.bestMonths || 'Year-round';
              const places = city.famousPlaces || city.attractions || [];

              return (
                <div
                  key={city.id}
                  className="rounded-2xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#1a1a1a]/40 hover:shadow-md transition-all group flex flex-col justify-between shadow-2xs"
                >
                  {/* City Photo Header */}
                  <div className="relative h-60 overflow-hidden cursor-pointer" onClick={() => onSelectCity(city.id)}>
                    <img
                      src={city.image}
                      alt={city.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/90 via-[#1a1a1a]/30 to-transparent" />
                    
                    {/* City Type Badge */}
                    <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/85 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white border border-white/10">
                        {city.cityType}
                      </span>
                    </div>

                    {/* Bookmark Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleSaveCity(city.name);
                      }}
                      className={`absolute top-3.5 right-3.5 p-2 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                        isSaved
                          ? 'bg-amber-400 text-stone-950 font-bold'
                          : 'bg-[#1a1a1a]/70 text-stone-200 hover:text-white'
                      }`}
                      title={isSaved ? 'Saved' : 'Save to Bucket List'}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>

                    {/* City Title & Country */}
                    <div className="absolute bottom-3.5 left-4 right-4">
                      <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider mb-0.5">
                        {city.country}
                      </div>
                      <h3 className="font-heading text-2xl sm:text-3xl font-black text-white group-hover:text-amber-200 transition-colors">
                        {city.name}
                      </h3>
                    </div>
                  </div>

                  {/* City Content Details */}
                  <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                    <p className="text-xs text-[#48453e] line-clamp-2 leading-relaxed">
                      {city.overview}
                    </p>

                    {/* Travel Metrics */}
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-[#f8f6f0] border border-[#ebe7dc] flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-amber-800 flex-shrink-0" />
                        <div>
                          <span className="text-[9px] uppercase text-[#807a6f] block font-bold">Ideal Stay</span>
                          <span className="font-bold text-[#1a1a1a]">{stayDays} Days</span>
                        </div>
                      </div>
                      <div className="p-2.5 rounded-xl bg-[#f8f6f0] border border-[#ebe7dc] flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-emerald-800 flex-shrink-0" />
                        <div>
                          <span className="text-[9px] uppercase text-[#807a6f] block font-bold">Best Weather</span>
                          <span className="font-bold text-[#1a1a1a] truncate block">{season}</span>
                        </div>
                      </div>
                    </div>

                    {/* Famous Places */}
                    {places.length > 0 && (
                      <div className="text-xs text-[#757064]">
                        <span className="font-bold text-[#1a1a1a]">Must-See: </span>
                        <span>{places.slice(0, 3).join(', ')}...</span>
                      </div>
                    )}

                    {/* Action Button */}
                    <button
                      onClick={() => onSelectCity(city.id)}
                      className="w-full py-2.5 rounded-xl bg-[#f4f1ea] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                    >
                      <span>Explore City Guide</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-12 text-center bg-white rounded-2xl border border-[#e7e4dc]">
            <MapPin className="w-10 h-10 text-[#a39c8e] mx-auto mb-3" />
            <h3 className="font-heading text-lg font-bold text-[#1a1a1a]">No cities matched your criteria</h3>
            <p className="text-xs text-[#7a7467] mt-1">Try adjusting your search keywords or clearing the active filters.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedContinent('all');
                setSelectedType('all');
              }}
              className="mt-4 px-4 py-2 rounded-lg bg-[#1a1a1a] text-white text-xs font-semibold cursor-pointer"
            >
              Show All Cities
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
