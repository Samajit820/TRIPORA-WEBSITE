import React from 'react';
import { Compass, Heart, ArrowUp, MapPin, Shield } from 'lucide-react';
import { TriporaLogo } from './TriporaLogo';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#f4f1ea] text-[#615d54] border-t border-[#ded9cc] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Top Branding & Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Brand */}
          <div className="lg:col-span-2 space-y-4">
            <TriporaLogo size="lg" showBadge={true} animated={false} />

            <p className="text-[#615d54] text-xs leading-relaxed max-w-sm">
              <strong className="text-[#1a1a1a]">Know Before You Go.</strong> Earth's ultimate travel encyclopedia, global discovery engine, and interactive planetary atlas. Covering 195 sovereign nations, iconic capitals, hidden wonders, cuisines, and cultural etiquette.
            </p>

            <div className="flex items-center gap-3 pt-2 text-[#615d54]">
              <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-md bg-white border border-[#ded9cc] text-[#4a473e]">
                🌍 195 Sovereign Nations
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-md bg-white border border-[#ded9cc] text-[#4a473e]">
                🌐 7 Continents
              </span>
            </div>
          </div>

          {/* Column 1: Core Exploration */}
          <div className="space-y-3">
            <h4 className="font-heading text-xs font-bold text-[#1a1a1a] uppercase tracking-wider">
              Explore Earth
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#earth-explorer" className="hover:text-[#1a1a1a] transition-colors">Planetary Atlas</a></li>
              <li><a href="#countries" className="hover:text-[#1a1a1a] transition-colors">195 Countries Directory</a></li>
              <li><a href="#cities" className="hover:text-[#1a1a1a] transition-colors">World Metropolises</a></li>
              <li><a href="#destinations" className="hover:text-[#1a1a1a] transition-colors">Hidden Gems & Wonders</a></li>
              <li><a href="#landmarks" className="hover:text-[#1a1a1a] transition-colors">Iconic Monuments</a></li>
            </ul>
          </div>

          {/* Column 2: Living Heritage */}
          <div className="space-y-3">
            <h4 className="font-heading text-xs font-bold text-[#1a1a1a] uppercase tracking-wider">
              Heritage & Wildlife
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#nature-wildlife" className="hover:text-[#1a1a1a] transition-colors">Earth Biomes & Fauna</a></li>
              <li><a href="#food-culture" className="hover:text-[#1a1a1a] transition-colors">World Gastronomy</a></li>
              <li><a href="#food-culture" className="hover:text-[#1a1a1a] transition-colors">Cultural Etiquette</a></li>
              <li><a href="#food-culture" className="hover:text-[#1a1a1a] transition-colors">Global Festivals Calendar</a></li>
              <li><a href="#experiences" className="hover:text-[#1a1a1a] transition-colors">Curated Expeditions</a></li>
            </ul>
          </div>

          {/* Column 3: Travel Toolkit */}
          <div className="space-y-3">
            <h4 className="font-heading text-xs font-bold text-[#1a1a1a] uppercase tracking-wider">
              Traveler Toolkit
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#planners" className="hover:text-[#1a1a1a] transition-colors">Smart Packing Generator</a></li>
              <li><a href="#planners" className="hover:text-[#1a1a1a] transition-colors">Budget Calculator</a></li>
              <li><a href="#planners" className="hover:text-[#1a1a1a] transition-colors">Visa Policy Advisor</a></li>
              <li><a href="#planners" className="hover:text-[#1a1a1a] transition-colors">Traveler FAQs</a></li>
              <li><a href="#articles" className="hover:text-[#1a1a1a] transition-colors">TRIPORA Travel Guides</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#ded9cc] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-[11px] text-[#807a6f] text-center sm:text-left">
            © {new Date().getFullYear()} TRIPORA — Know Before You Go. Built for world explorers, geography enthusiasts & adventurers.
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-[#ded9cc] text-[#4a473e] hover:text-[#1a1a1a] hover:bg-[#ebe7dc] transition-all text-xs cursor-pointer"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
