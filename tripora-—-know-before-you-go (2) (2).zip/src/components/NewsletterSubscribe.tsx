import React, { useState } from 'react';
import { Mail, Sparkles, CheckCircle2, Send } from 'lucide-react';

export const NewsletterSubscribe: React.FC = () => {
  const [email, setEmail] = useState('');
  const [frequency, setFrequency] = useState<'weekly' | 'monthly'>('weekly');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return;
    setIsSubscribed(true);
  };

  return (
    <section className="py-16 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        <div className="p-8 sm:p-12 rounded-2xl bg-white border border-[#ded9cc] shadow-xs relative overflow-hidden">
          
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold uppercase tracking-wider mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            Join 120,000+ Global Explorers
          </div>

          <h2 className="font-heading text-2xl sm:text-4xl font-bold text-[#1a1a1a] tracking-tight">
            The TRIPORA Global Dispatch
          </h2>
          
          <p className="mt-2 text-xs sm:text-sm text-[#615d54] max-w-xl mx-auto leading-relaxed">
            Curated weekly travel intel, newly discovered hidden gems, seasonal visa policy updates, and deep country encyclopedic guides delivered straight to your inbox.
          </p>

          {isSubscribed ? (
            <div className="mt-8 p-6 rounded-xl bg-[#edf6f0] border border-[#cbe4d2] text-emerald-900 max-w-md mx-auto animate-in zoom-in-95 duration-200">
              <CheckCircle2 className="w-8 h-8 text-emerald-800 mx-auto mb-2" />
              <h4 className="font-heading text-lg font-bold text-[#1a1a1a]">You're on the Dispatch List!</h4>
              <p className="text-xs text-[#48453e] mt-1">
                A welcome guide covering the World's Top 50 Offbeat Wonders has been sent to <strong>{email}</strong>.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-8 max-w-md mx-auto space-y-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Mail className="w-4 h-4 text-[#807a6f] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your personal email address..."
                    required
                    className="w-full pl-10 pr-4 py-3 bg-[#fcfbf7] border border-[#d8d3c5] rounded-lg text-xs text-[#1a1a1a] placeholder:text-[#807a6f] focus:outline-none focus:border-[#1a1a1a]"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-3 bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span>Subscribe</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-center justify-center gap-4 text-xs text-[#615d54]">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="freq"
                    checked={frequency === 'weekly'}
                    onChange={() => setFrequency('weekly')}
                    className="accent-[#1a1a1a]"
                  />
                  <span>Weekly Digest</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="freq"
                    checked={frequency === 'monthly'}
                    onChange={() => setFrequency('monthly')}
                    className="accent-[#1a1a1a]"
                  />
                  <span>Monthly Deep Dives</span>
                </label>
              </div>
            </form>
          )}

          <div className="mt-4 text-[10px] text-[#807a6f]">
            No spam ever. Unsubscribe with 1-click anytime.
          </div>

        </div>

      </div>
    </section>
  );
};
