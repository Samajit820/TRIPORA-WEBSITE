import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Search, X, MapPin, Globe, Compass, Utensils, Sparkles, BookOpen, ChevronRight } from 'lucide-react';
import { ALL_195_COUNTRIES, DETAILED_COUNTRIES } from '../data/countries';
import { CITIES_DATA } from '../data/cities';
import { DESTINATIONS_DATA } from '../data/destinations';
import { LANDMARKS_DATA } from '../data/landmarks';
import { FOODS_DATA } from '../data/foods';
import { FESTIVALS_DATA } from '../data/cultureFestivals';
import { ARTICLES_DATA } from '../data/articles';
import { SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCountry: (countryId: string) => void;
  onSelectCity: (cityId: string) => void;
  onSelectLandmark: (landmarkId: string) => void;
  onSelectArticle: (articleId: string) => void;
  currentLang: SupportedLanguage;
  initialQuery?: string;
}

type SearchCategory = 'all' | 'countries' | 'cities' | 'landmarks' | 'food' | 'festivals' | 'articles';

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectCountry,
  onSelectCity,
  onSelectLandmark,
  onSelectArticle,
  currentLang,
  initialQuery = ''
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState<SearchCategory>('all');
  const inputRef = useRef<HTMLInputElement>(null);
  const t = TRANSLATIONS[currentLang];

  useEffect(() => {
    if (isOpen) {
      if (initialQuery) {
        setQuery(initialQuery);
      }
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen, initialQuery]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const searchResults = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) {
      return {
        countries: ALL_195_COUNTRIES.slice(0, 4),
        cities: CITIES_DATA.slice(0, 3),
        landmarks: LANDMARKS_DATA.slice(0, 3),
        foods: FOODS_DATA.slice(0, 2),
        festivals: FESTIVALS_DATA.slice(0, 2),
        articles: ARTICLES_DATA.slice(0, 2)
      };
    }

    const matchedCountries = ALL_195_COUNTRIES.filter(
      (c) => c.name.toLowerCase().includes(q) || c.capital.toLowerCase().includes(q) || c.region.toLowerCase().includes(q)
    ).slice(0, 6);

    const matchedCities = CITIES_DATA.filter(
      (c) => c.name.toLowerCase().includes(q) || c.country.toLowerCase().includes(q) || c.famousPlaces.some(p => p.toLowerCase().includes(q))
    ).slice(0, 4);

    const matchedLandmarks = LANDMARKS_DATA.filter(
      (l) => l.name.toLowerCase().includes(q) || l.country.toLowerCase().includes(q) || l.highlights.some(h => h.toLowerCase().includes(q))
    ).slice(0, 4);

    const matchedFoods = FOODS_DATA.filter(
      (f) => f.name.toLowerCase().includes(q) || f.country.toLowerCase().includes(q) || f.type.toLowerCase().includes(q)
    ).slice(0, 4);

    const matchedFestivals = FESTIVALS_DATA.filter(
      (fest) => fest.name.toLowerCase().includes(q) || fest.country.toLowerCase().includes(q)
    ).slice(0, 3);

    const matchedArticles = ARTICLES_DATA.filter(
      (a) => a.title.toLowerCase().includes(q) || a.tags.some(tag => tag.toLowerCase().includes(q))
    ).slice(0, 3);

    return {
      countries: matchedCountries,
      cities: matchedCities,
      landmarks: matchedLandmarks,
      foods: matchedFoods,
      festivals: matchedFestivals,
      articles: matchedArticles
    };
  }, [query]);

  if (!isOpen) return null;

  const totalResultsCount =
    searchResults.countries.length +
    searchResults.cities.length +
    searchResults.landmarks.length +
    searchResults.foods.length +
    searchResults.festivals.length +
    searchResults.articles.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
      
      {/* Click outside backdrop */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-3xl rounded-xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[82vh] z-10 animate-in zoom-in-95 duration-150 text-[#1a1a1a]">
        
        {/* Search Bar Input */}
        <div className="relative flex items-center px-4 py-3.5 border-b border-[#ded9cc] bg-white">
          <Search className="w-5 h-5 text-[#807a6f] mr-3 flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full bg-transparent text-sm sm:text-base text-[#1a1a1a] placeholder:text-[#807a6f] focus:outline-none font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-[#807a6f] hover:text-[#1a1a1a] mr-2 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2 py-1 text-xs font-semibold bg-[#f0ece1] hover:bg-[#ded9cc] text-[#4a473e] rounded-md transition-colors cursor-pointer"
          >
            ESC
          </button>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 px-4 py-2 bg-[#f4f1ea] border-b border-[#ded9cc] overflow-x-auto text-xs scrollbar-none">
          <span className="text-[#807a6f] font-semibold mr-1">Filter:</span>
          {(['all', 'countries', 'cities', 'landmarks', 'food', 'festivals', 'articles'] as SearchCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-2.5 py-1 rounded-md capitalize font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                category === cat
                  ? 'bg-[#1a1a1a] text-white'
                  : 'bg-white border border-[#ded9cc] text-[#615d54] hover:bg-[#ebe7dc]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results Container */}
        <div className="overflow-y-auto p-4 space-y-5 divide-y divide-[#ebe7dc]">
          
          {totalResultsCount === 0 && (
            <div className="py-12 text-center text-[#807a6f]">
              <Compass className="w-10 h-10 mx-auto text-[#807a6f] mb-2 animate-spin" style={{ animationDuration: '6s' }} />
              <p className="text-sm">No world records found matching "<span className="text-[#1a1a1a] font-medium">{query}</span>"</p>
              <p className="text-xs text-[#807a6f] mt-1">Try searching for country names like "India", "Japan", landmarks like "Taj Mahal", or foods like "Biryani".</p>
            </div>
          )}

          {/* Countries Results */}
          {(category === 'all' || category === 'countries') && searchResults.countries.length > 0 && (
            <div className="pt-2 first:pt-0">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-900 mb-2">
                <Globe className="w-3.5 h-3.5" />
                <span>Countries ({searchResults.countries.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {searchResults.countries.map((country) => (
                  <button
                    key={country.id}
                    onClick={() => {
                      onSelectCountry(country.id);
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-white hover:bg-[#f8f6f0] border border-[#e7e4dc] text-left transition-all group cursor-pointer shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{country.flag}</span>
                      <div>
                        <div className="text-sm font-semibold text-[#1a1a1a] group-hover:text-amber-900 transition-colors">
                          {country.name}
                        </div>
                        <div className="text-xs text-[#807a6f]">
                          Capital: {country.capital} • {country.region}
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#807a6f] group-hover:text-[#1a1a1a] group-hover:translate-x-0.5 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Cities Results */}
          {(category === 'all' || category === 'cities') && searchResults.cities.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-900 mb-2">
                <MapPin className="w-3.5 h-3.5" />
                <span>World Cities ({searchResults.cities.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {searchResults.cities.map((city) => (
                  <button
                    key={city.id}
                    onClick={() => {
                      onSelectCity(city.id);
                      onClose();
                    }}
                    className="flex items-center gap-3 p-2.5 rounded-lg bg-white hover:bg-[#f8f6f0] border border-[#e7e4dc] text-left transition-all group cursor-pointer shadow-xs"
                  >
                    <img src={city.image} alt={city.name} className="w-12 h-12 rounded-md object-cover flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-[#1a1a1a] group-hover:text-teal-900 truncate">
                        {city.name}
                      </div>
                      <div className="text-xs text-[#807a6f] truncate">
                        {city.country} • {city.cityType}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#807a6f] group-hover:text-[#1a1a1a]" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Landmarks Results */}
          {(category === 'all' || category === 'landmarks') && searchResults.landmarks.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-900 mb-2">
                <Compass className="w-3.5 h-3.5" />
                <span>Landmarks & Attractions ({searchResults.landmarks.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {searchResults.landmarks.map((lm) => (
                  <button
                    key={lm.id}
                    onClick={() => {
                      onSelectLandmark(lm.id);
                      onClose();
                    }}
                    className="flex items-center gap-3 p-2.5 rounded-lg bg-white hover:bg-[#f8f6f0] border border-[#e7e4dc] text-left transition-all group cursor-pointer shadow-xs"
                  >
                    <img src={lm.image} alt={lm.name} className="w-12 h-12 rounded-md object-cover flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-[#1a1a1a] group-hover:text-rose-900 truncate">
                        {lm.name}
                      </div>
                      <div className="text-xs text-[#807a6f] truncate">
                        {lm.country} • {lm.category}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#807a6f] group-hover:text-[#1a1a1a]" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* World Foods */}
          {(category === 'all' || category === 'food') && searchResults.foods.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-900 mb-2">
                <Utensils className="w-3.5 h-3.5" />
                <span>World Food & Cuisine ({searchResults.foods.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {searchResults.foods.map((f) => (
                  <div
                    key={f.id}
                    className="flex items-center gap-3 p-2.5 rounded-lg bg-white border border-[#e7e4dc] shadow-xs"
                  >
                    <img src={f.image} alt={f.name} className="w-12 h-12 rounded-md object-cover flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-[#1a1a1a] truncate">
                        {f.name}
                      </div>
                      <div className="text-xs text-[#807a6f] truncate">
                        {f.country} • {f.type}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Articles */}
          {(category === 'all' || category === 'articles') && searchResults.articles.length > 0 && (
            <div className="pt-3">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-900 mb-2">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Travel Articles ({searchResults.articles.length})</span>
              </div>
              <div className="space-y-2">
                {searchResults.articles.map((art) => (
                  <button
                    key={art.id}
                    onClick={() => {
                      onSelectArticle(art.id);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-lg bg-white hover:bg-[#f8f6f0] border border-[#e7e4dc] text-left transition-all group cursor-pointer shadow-xs"
                  >
                    <div>
                      <div className="text-sm font-semibold text-[#1a1a1a] group-hover:text-indigo-900">
                        {art.title}
                      </div>
                      <div className="text-xs text-[#807a6f]">
                        {art.category} • {art.readTime}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#807a6f] group-hover:text-[#1a1a1a]" />
                  </button>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer info bar */}
        <div className="px-4 py-2.5 bg-[#f0ece1] border-t border-[#ded9cc] flex items-center justify-between text-[11px] text-[#615d54]">
          <span>Search database across 195 nations & global guides</span>
          <span>Press <strong>ESC</strong> to exit</span>
        </div>

      </div>
    </div>
  );
};
