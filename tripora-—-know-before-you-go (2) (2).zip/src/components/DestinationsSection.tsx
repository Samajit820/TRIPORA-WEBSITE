import React, { useState } from 'react';
import { Compass, Sparkles, Mountain, Waves, Sun, Eye, ChevronRight, Bookmark } from 'lucide-react';
import { DESTINATIONS_DATA } from '../data/destinations';
import { Destination } from '../types';

interface DestinationsSectionProps {
  onToggleSave: (destName: string) => void;
  savedItems: string[];
}

export const DestinationsSection: React.FC<DestinationsSectionProps> = ({
  onToggleSave,
  savedItems
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);

  const categories = [
    { id: 'all', label: 'All Destinations' },
    { id: 'World-Famous', label: '🌟 World-Famous Icons' },
    { id: 'Hidden Gem', label: '💎 Hidden Gems & Offbeat' },
    { id: 'Mountain & Valley', label: '🏔️ Mountains & Valleys' },
    { id: 'Waterfall & Lake', label: '🌊 Waterfalls & Lakes' },
    { id: 'Volcano', label: '🌋 Volcanoes' },
    { id: 'Island & Beach', label: '🏝️ Islands & Coral Atolls' }
  ];

  const filteredDestinations = DESTINATIONS_DATA.filter((dest) => {
    if (activeCategory === 'all') return true;
    return dest.category === activeCategory;
  });

  return (
    <section id="destinations" className="py-20 bg-[#fcfbf7] text-[#1a1a1a] relative border-b border-[#e7e4dc]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-[#f0ece1] border border-[#ded9cc] text-[#4a473e] text-xs font-bold tracking-wider uppercase mb-3">
              <Compass className="w-3.5 h-3.5" />
              Chapter 04 • Famous, Hidden & Natural Wonders
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#1a1a1a]">
              Global Destinations
            </h2>
            <p className="mt-2 text-sm sm:text-base text-[#615d54] max-w-2xl">
              From bucket-list icons to secret mangrove deltas, subpolar sea cliffs, alpine glacial valleys, and subterranean marine sinkholes.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#1a1a1a] text-white shadow-xs'
                    : 'bg-white border border-[#e7e4dc] text-[#555148] hover:text-[#1a1a1a] hover:bg-[#f7f5ee]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Destination Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-300">
          {filteredDestinations.map((dest) => {
            const isSaved = savedItems.includes(dest.name);
            return (
              <div
                key={dest.id}
                className="rounded-xl bg-white border border-[#e7e4dc] overflow-hidden hover:border-[#c5bea] transition-all group flex flex-col justify-between shadow-xs"
              >
                {/* Destination Image */}
                <div className="relative h-56 overflow-hidden cursor-pointer" onClick={() => setSelectedDestination(dest)}>
                  <img
                    src={dest.image}
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a]/85 via-[#1a1a1a]/25 to-transparent" />
                  
                  {/* Badges */}
                  <div className="absolute top-3.5 left-3.5 flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-md bg-[#1a1a1a]/80 backdrop-blur-xs text-[10px] font-bold uppercase tracking-wider text-white">
                      {dest.category}
                    </span>
                    {dest.type === 'Hidden' && (
                      <span className="px-2 py-0.5 rounded-md bg-purple-950/80 text-purple-200 border border-purple-800/40 text-[9px] font-bold">
                        💎 Hidden Gem
                      </span>
                    )}
                  </div>

                  {/* Bookmark Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleSave(dest.name);
                    }}
                    className={`absolute top-3.5 right-3.5 p-2 rounded-md backdrop-blur-xs transition-colors cursor-pointer ${
                      isSaved
                        ? 'bg-[#1a1a1a] text-white'
                        : 'bg-[#1a1a1a]/70 text-stone-200 hover:text-white'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>

                  {/* Title on Image */}
                  <div className="absolute bottom-3 left-4 right-4">
                    <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider">
                      {dest.country}
                    </div>
                    <h3 className="font-heading text-xl font-bold text-white group-hover:text-amber-200 transition-colors">
                      {dest.name}
                    </h3>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="text-[11px] font-semibold text-emerald-800 mb-1">
                      {dest.subType}
                    </div>
                    <p className="text-xs text-[#48453e] line-clamp-2 leading-relaxed">
                      {dest.overview}
                    </p>
                  </div>

                  {/* Highlights */}
                  <div className="p-3 rounded-md bg-[#f8f6f0] border border-[#ebe7dc] text-xs space-y-1">
                    <span className="text-[10px] uppercase font-bold text-[#807a6f] block">Best Season to Visit:</span>
                    <strong className="text-[#1a1a1a] block">{dest.bestSeason}</strong>
                  </div>

                  {/* Action */}
                  <button
                    onClick={() => setSelectedDestination(dest)}
                    className="w-full py-2.5 rounded-lg bg-[#f4f1ea] hover:bg-[#1a1a1a] hover:text-white text-[#1a1a1a] font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>View Destination Guide</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal for Destination Details */}
        {selectedDestination && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#1a1a1a]/70 backdrop-blur-xs animate-in fade-in duration-200">
            <div className="fixed inset-0" onClick={() => setSelectedDestination(null)} />
            <div className="relative w-full max-w-3xl rounded-2xl bg-[#fcfbf7] border border-[#e7e4dc] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] z-10 text-[#1a1a1a]">
              <div className="relative h-64 flex-shrink-0">
                <img src={selectedDestination.image} alt={selectedDestination.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] via-[#1a1a1a]/40 to-transparent" />
                <button
                  onClick={() => setSelectedDestination(null)}
                  className="absolute top-4 right-4 p-2 rounded-md bg-[#1a1a1a]/80 text-white hover:bg-rose-700 transition-colors cursor-pointer"
                >
                  ✕
                </button>
                <div className="absolute bottom-4 left-6 right-6">
                  <span className="text-xs uppercase font-bold text-amber-300">{selectedDestination.country} • {selectedDestination.subType}</span>
                  <h2 className="font-heading text-3xl font-bold text-white">{selectedDestination.name}</h2>
                </div>
              </div>

              <div className="p-6 overflow-y-auto space-y-5 text-[#2d2a24] text-xs sm:text-sm">
                <div>
                  <h4 className="font-bold text-[#1a1a1a] uppercase text-xs tracking-wider mb-1">Destination Overview</h4>
                  <p className="text-[#4a473e] leading-relaxed">{selectedDestination.overview}</p>
                </div>

                <div className="p-4 rounded-xl bg-[#edf6f0] border border-[#cbe4d2] text-emerald-950">
                  <strong className="block text-[#1a1a1a] mb-1">💡 Why Visit:</strong>
                  {selectedDestination.whyVisit}
                </div>

                <div>
                  <h4 className="font-bold text-[#1a1a1a] uppercase text-xs tracking-wider mb-2">Key Highlights & Sights</h4>
                  <div className="space-y-1.5">
                    {selectedDestination.highlights.map((h, i) => (
                      <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg bg-white border border-[#e7e4dc] text-xs shadow-xs">
                        <span className="text-emerald-800 font-bold">•</span>
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[#7a7467] block text-[10px] uppercase font-bold">Best Season:</span>
                    <strong className="text-[#1a1a1a] text-sm">{selectedDestination.bestSeason}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-[#e7e4dc] shadow-xs">
                    <span className="text-[#7a7467] block text-[10px] uppercase font-bold">Ideal For:</span>
                    <strong className="text-amber-900 text-sm">{selectedDestination.idealFor.join(', ')}</strong>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#f0ece1] border-t border-[#e2ded5] flex justify-end">
                <button
                  onClick={() => setSelectedDestination(null)}
                  className="px-4 py-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#33302a] text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
