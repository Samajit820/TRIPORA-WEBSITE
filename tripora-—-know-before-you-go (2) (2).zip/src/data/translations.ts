import { SupportedLanguage } from '../types';

export interface Translations {
  tagline: string;
  heroHeadline: string;
  heroSubheadline: string;
  searchPlaceholder: string;
  exploreEarth: string;
  countries: string;
  historyTimeline: string;
  cities: string;
  destinations: string;
  landmarks: string;
  natureWildlife: string;
  foodCulture: string;
  experiences: string;
  planners: string;
  articles: string;
  savedItems: string;
  allContinents: string;
  popularFilters: string;
  quickFacts: string;
  capital: string;
  population: string;
  currency: string;
  language: string;
  timeZone: string;
  bestTime: string;
  visaDifficulty: string;
  budgetPerDay: string;
  readMore: string;
  viewAll: string;
  exploreCountry: string;
  close: string;
  filterBy: string;
  subscribeTitle: string;
  subscribeSubtitle: string;
  subscribeBtn: string;
  subscribeSuccess: string;
  smartPacking: string;
  budgetCalculator: string;
  visaGuide: string;
  faqTitle: string;
}

export const TRANSLATIONS: Record<SupportedLanguage, Translations> = {
  en: {
    tagline: 'Know Before You Go',
    heroHeadline: 'Discover Every Corner of Our Planet',
    heroSubheadline: 'Your definitive global encyclopedia for 195 countries, iconic cities, hidden natural wonders, authentic world food, and smart travel preparation.',
    searchPlaceholder: 'Search countries, cities, landmarks, nature, food, culture (e.g., Japan, Kolkata, Alps)...',
    exploreEarth: 'Explore Earth',
    countries: '195 Countries',
    historyTimeline: 'History Timeline',
    cities: 'World Cities',
    destinations: 'Destinations',
    landmarks: 'Landmarks',
    natureWildlife: 'Nature & Wildlife',
    foodCulture: 'Food & Culture',
    experiences: 'Experiences',
    planners: 'Travel Toolkit',
    articles: 'Travel Guides',
    savedItems: 'My Bucket List',
    allContinents: 'All Continents',
    popularFilters: 'Popular Categories',
    quickFacts: 'Essential Quick Facts',
    capital: 'Capital',
    population: 'Population',
    currency: 'Currency',
    language: 'Language',
    timeZone: 'Time Zone',
    bestTime: 'Best Time to Visit',
    visaDifficulty: 'Visa Requirement',
    budgetPerDay: 'Estimated Daily Cost',
    readMore: 'Explore Details',
    viewAll: 'View All Entries',
    exploreCountry: 'Full Country Profile',
    close: 'Close',
    filterBy: 'Filter By',
    subscribeTitle: 'Stay Ahead of Global Travel',
    subscribeSubtitle: 'Receive curated destination guides, visa policy updates, hidden gem discoveries, and smart packing recommendations weekly.',
    subscribeBtn: 'Subscribe for Free',
    subscribeSuccess: 'Thank you! You are now subscribed to TRIPORA travel updates.',
    smartPacking: 'Smart Packing Generator',
    budgetCalculator: 'Travel Budget Estimator',
    visaGuide: 'Visa & Entry Advisor',
    faqTitle: 'Frequently Asked Travel Questions'
  },
  hi: {
    tagline: 'जाने से पहले जानें',
    heroHeadline: 'हमारी पृथ्वी के हर कोने की खोज करें',
    heroSubheadline: '195 देशों, विश्व प्रसिद्ध शहरों, छिपे हुए प्राकृतिक अजूबों, प्रामाणिक खान-पान और यात्रा योजना के लिए आपका संपूर्ण वैश्विक विश्वकोश।',
    searchPlaceholder: 'देश, शहर, स्मारक, प्रकृति, भोजन खोजें (जैसे: भारत, जापान, कोलकाता, पेरिस)...',
    exploreEarth: 'पृथ्वी की खोज',
    countries: '195 देश',
    historyTimeline: 'ऐतिहासिक कालक्रम',
    cities: 'विश्व के शहर',
    destinations: 'गंतव्य स्थल',
    landmarks: 'प्रमुख स्मारक',
    natureWildlife: 'प्रकृति और वन्यजीव',
    foodCulture: 'खान-पान और संस्कृति',
    experiences: 'रोमांचक अनुभव',
    planners: 'यात्रा टूलकिट',
    articles: 'यात्रा गाइड',
    savedItems: 'मेरी बकेट लिस्ट',
    allContinents: 'सभी महाद्वीप',
    popularFilters: 'लोकप्रिय श्रेणियां',
    quickFacts: 'मुख्य तथ्य',
    capital: 'राजधानी',
    population: 'जनसंख्या',
    currency: 'मुद्रा',
    language: 'भाषा',
    timeZone: 'समय क्षेत्र',
    bestTime: 'घूमने का सबसे अच्छा समय',
    visaDifficulty: 'वीज़ा आवश्यकता',
    budgetPerDay: 'दैनिक अनुमानित खर्च',
    readMore: 'विवरण देखें',
    viewAll: 'सभी प्रविष्टियां देखें',
    exploreCountry: 'संपूर्ण देश प्रोफ़ाइल',
    close: 'बंद करें',
    filterBy: 'फ़िल्टर करें',
    subscribeTitle: 'विश्व यात्रा से अपडेट रहें',
    subscribeSubtitle: 'हर हफ्ते गंतव्य गाइड, वीज़ा अपडेट, और बजट यात्रा युक्तियाँ सीधे अपने इनबॉक्स में पाएं।',
    subscribeBtn: 'निःशुल्क सदस्यता लें',
    subscribeSuccess: 'धन्यवाद! अब आप TRIPORA यात्रा अपडेट से जुड़ चुके हैं।',
    smartPacking: 'स्मार्ट पैकिंग सहायक',
    budgetCalculator: 'यात्रा बजट कैलकुलेटर',
    visaGuide: 'वीज़ा और प्रवेश सलाहकार',
    faqTitle: 'अक्सर पूछे जाने वाले यात्रा प्रश्न'
  },
  bn: {
    tagline: 'যাওয়ার আগেই জানুন',
    heroHeadline: 'আমাদের পৃথিবীর প্রতিটি কোণ আবিষ্কার করুন',
    heroSubheadline: '১৯৫টি দেশ, ঐতিহাসিক শহর, প্রাকৃতিক বিস্ময়, সুস্বাদু খাবার এবং ভ্রমণ পরিকল্পনার জন্য আপনার নির্ভরযোগ্য বৈশ্বিক বিশ্বকোষ।',
    searchPlaceholder: 'দেশ, শহর, ল্যান্ডমার্ক, প্রকৃতি, খাবার খুঁজুন (যেমন: কলকাতা, ভারত, জাপান, সুন্দরবন)...',
    exploreEarth: 'পৃথিবী আবিষ্কার',
    countries: '১৯৫টি দেশ',
    historyTimeline: 'ঐতিহাসিক টাইমলাইন',
    cities: 'বিশ্বের শহর',
    destinations: 'দর্শনীয় স্থান',
    landmarks: 'ঐতিহাসিক স্মৃতিস্তম্ভ',
    natureWildlife: 'প্রকৃতি ও বন্যপ্রাণী',
    foodCulture: 'খাবার ও সংস্কৃতি',
    experiences: 'রোমাঞ্চকর অভিজ্ঞতা',
    planners: 'ভ্রমণ টুলকিট',
    articles: 'ভ্রমণ গাইড',
    savedItems: 'আমার ট্রাভেল বাকেট লিস্ট',
    allContinents: 'সব মহাদেশ',
    popularFilters: 'জনপ্রিয় বিভাগ',
    quickFacts: 'জরুরি তথ্য',
    capital: 'রাজধানী',
    population: 'জনসংখ্যা',
    currency: 'মুদ্রা',
    language: 'ভাষা',
    timeZone: 'সময় অঞ্চল',
    bestTime: 'ভ্রমণের সেরা সময়',
    visaDifficulty: 'ভিসা নিয়মাবলী',
    budgetPerDay: 'দৈনিক খরচের হিসাব',
    readMore: 'বিস্তারিত দেখুন',
    viewAll: 'সব দেখুন',
    exploreCountry: 'সম্পূর্ণ দেশের তথ্য',
    close: 'বন্ধ করুন',
    filterBy: 'ফিল্টার করুন',
    subscribeTitle: 'নিয়মিত ভ্রমণ তথ্য পান',
    subscribeSubtitle: 'প্রতি সপ্তাহে নতুন ভ্রমণ গাইড, ভিসা আপডেট এবং আকর্ষণীয় স্থান সম্পর্কে জানুন।',
    subscribeBtn: 'সাবস্ক্রাইব করুন',
    subscribeSuccess: 'ধন্যবাদ! আপনি সফলভাবে TRIPORA-এ সাবস্ক্রাইব করেছেন।',
    smartPacking: 'স্মার্ট প্যাকিং চেকলিস্ট',
    budgetCalculator: 'ভ্রমণ বাজেট ক্যালকুলেটর',
    visaGuide: 'ভিসা ও প্রবেশ নির্দেশিকা',
    faqTitle: 'সাধারণ ভ্রমণ প্রশ্নোত্তর'
  },
  es: {
    tagline: 'Saber antes de viajar',
    heroHeadline: 'Descubre cada rincón de nuestro planeta',
    heroSubheadline: 'Tu enciclopedia de viajes definitiva para 195 países, ciudades icónicas, maravillas naturales, gastronomía y herramientas de viaje inteligentes.',
    searchPlaceholder: 'Buscar países, ciudades, monumentos, naturaleza, comida (ej. Japón, París, Roma)...',
    exploreEarth: 'Explorar la Tierra',
    countries: '195 Países',
    historyTimeline: 'Línea de Tiempo Histórica',
    cities: 'Ciudades del Mundo',
    destinations: 'Destinos',
    landmarks: 'Monumentos',
    natureWildlife: 'Naturaleza y Vida Silvestre',
    foodCulture: 'Gastronomía y Cultura',
    experiences: 'Experiencias',
    planners: 'Herramientas de Viaje',
    articles: 'Guías de Viaje',
    savedItems: 'Mi Lista de Deseos',
    allContinents: 'Todos los Continentes',
    popularFilters: 'Categorías Populares',
    quickFacts: 'Datos Rápidos Esenciales',
    capital: 'Capital',
    population: 'Población',
    currency: 'Moneda',
    language: 'Idioma',
    timeZone: 'Zona Horaria',
    bestTime: 'Mejor Época para Visitar',
    visaDifficulty: 'Requisito de Visa',
    budgetPerDay: 'Costo Diario Estimado',
    readMore: 'Ver Detalles',
    viewAll: 'Ver Todo',
    exploreCountry: 'Perfil Completo del País',
    close: 'Cerrar',
    filterBy: 'Filtrar Por',
    subscribeTitle: 'Mantente al día con los viajes globales',
    subscribeSubtitle: 'Recibe guías de destinos, novedades sobre visas y consejos de viaje semanalmente.',
    subscribeBtn: 'Suscribirse Gratis',
    subscribeSuccess: '¡Gracias! Te has suscrito con éxito a las actualizaciones de TRIPORA.',
    smartPacking: 'Generador de Equipaje Inteligente',
    budgetCalculator: 'Calculadora de Presupuesto',
    visaGuide: 'Asesor de Visas y Entrada',
    faqTitle: 'Preguntas Frecuentes de Viaje'
  },
  fr: {
    tagline: 'Savoir avant de partir',
    heroHeadline: 'Découvrez chaque recoin de notre planète',
    heroSubheadline: 'Votre encyclopédie mondiale pour 195 pays, villes emblématiques, merveilles naturelles, gastronomie authentique et planification intelligente.',
    searchPlaceholder: 'Rechercher pays, villes, monuments, nature, cuisine (ex. Japon, Paris, Suisse)...',
    exploreEarth: 'Explorer la Terre',
    countries: '195 Pays',
    historyTimeline: 'Frise Historique',
    cities: 'Villes du Monde',
    destinations: 'Destinations',
    landmarks: 'Monuments',
    natureWildlife: 'Nature & Faune',
    foodCulture: 'Gastronomie & Culture',
    experiences: 'Expériences',
    planners: 'Boîte à Outils',
    articles: 'Guides de Voyage',
    savedItems: 'Ma Liste de Souhaits',
    allContinents: 'Tous les Continents',
    popularFilters: 'Catégories Populaires',
    quickFacts: 'Faits Essentiels',
    capital: 'Capitale',
    population: 'Population',
    currency: 'Monnaie',
    language: 'Langue',
    timeZone: 'Fuseau Horaire',
    bestTime: 'Meilleure Période',
    visaDifficulty: 'Exigences de Visa',
    budgetPerDay: 'Budget Quotidien Estimé',
    readMore: 'Explorer les Détails',
    viewAll: 'Voir Toutes les Entrées',
    exploreCountry: 'Profil Completo del Pays',
    close: 'Fermer',
    filterBy: 'Filtrer Par',
    subscribeTitle: 'Restez informé sur le voyage',
    subscribeSubtitle: 'Recevez chaque semaine des guides de destination, mises à jour sur les visas et conseils pratiques.',
    subscribeBtn: 'S\'abonner Gratuitement',
    subscribeSuccess: 'Merci ! Vous êtes maintenant inscrit aux actualités TRIPORA.',
    smartPacking: 'Générateur de Valise Intelligent',
    budgetCalculator: 'Calculateur de Budget',
    visaGuide: 'Conseiller Visa & Entrée',
    faqTitle: 'Questions Fréquentes de Voyage'
  }
};
