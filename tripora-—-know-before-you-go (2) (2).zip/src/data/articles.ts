import { Article } from '../types';

export const ARTICLES_DATA: Article[] = [
  {
    id: 'japan-first-timer-guide',
    title: 'The Ultimate First-Timer’s Guide to Japan: Tokyo, Kyoto & Beyond',
    slug: 'japan-first-timer-guide',
    excerpt: 'From navigating Tokyo’s Shinkansen bullet trains to savoring authentic ramen in Kyoto and mastering etiquette, here is everything you need to know before you go.',
    author: 'TRIPORA Editorial Team',
    publishedDate: '2025-02-10',
    readTime: '7 min read',
    category: 'Destination Guide',
    heroImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80',
    country: 'Japan',
    continent: 'asia',
    tags: ['Japan', 'Tokyo', 'Kyoto', 'First Time Travel', 'Shinkansen', 'Budget Tips'],
    contentSections: [
      {
        heading: '1. Master the Golden Route (Tokyo - Hakone - Kyoto - Osaka)',
        body: 'For your first trip, allocate 10 to 14 days following the classic Golden Route. Spend 4-5 days exploring Tokyo’s futuristic neighborhoods (Shinjuku, Shibuya, Akihabara, Asakusa), 1 night soaking in an onsen hot spring ryokan overlooking Mt. Fuji in Hakone, 3-4 days wandering Kyoto’s bamboo groves and gilded shrines, and 2 days savoring street takoyaki and nightlife in Osaka.',
        bullets: [
          'Tokyo: Urban energy, Michelin dining, teamLab digital art exhibitions',
          'Hakone: Relaxing traditional Ryokan stays, open-air hot springs (onsen), view of Mt. Fuji',
          'Kyoto: Over 2,000 temples and shrines, geisha districts in Gion, Arashiyama bamboo forest',
          'Osaka: Dotonbori neon canal, incredible street food stalls, friendly local culture'
        ]
      },
      {
        heading: '2. Connectivity & Transit Essentials',
        body: 'Order an eSIM or Pocket Wi-Fi before arriving at Haneda or Narita airport. Download Google Maps and Japan Travel by NAVITIME for precise train departure times and platform numbers. Add a digital Suica or Pasmo card to your Apple/Google Wallet for effortless contactless tapping on trains, buses, and 7-Eleven convenience stores.',
        bullets: [
          'No need for physical coins on subways—digital IC cards work nationwide.',
          'Shinkansen luggage rules: If your suitcase dimensions exceed 160 cm, reserve an oversized baggage seat in advance.'
        ]
      },
      {
        heading: '3. Essential Etiquette Rules to Avoid Culture Shock',
        body: 'Japanese culture places high value on collective consideration. Keep your voice quiet on commuter trains, avoid talking on cell phones, and never walk while eating (eat standing directly outside the vendor shop or stall).',
        bullets: [
          'Never tip at restaurants or in taxis; exceptional service is standard and included.',
          'Carry a small plastic bag for personal trash as street bins are deliberately rare.',
          'Remove your shoes when stepping onto tatami straw mats or inside traditional ryokans.'
        ]
      }
    ]
  },
  {
    id: 'hidden-gems-india-bengal',
    title: 'Beyond the Golden Triangle: Hidden Gems of India & West Bengal',
    slug: 'hidden-gems-india-bengal',
    excerpt: 'Discover offbeat mangrove frontiers in the Sundarbans, the French colonial charm of Chandannagar, the misty tea hills of Darjeeling, and terracotta temples of Bishnupur.',
    author: 'Suman Roy & TRIPORA Explorers',
    publishedDate: '2025-01-28',
    readTime: '6 min read',
    category: 'Hidden Gems',
    heroImage: 'https://images.unsplash.com/photo-1558431382-27e303142255?auto=format&fit=crop&w=1200&q=80',
    country: 'India',
    continent: 'asia',
    tags: ['India', 'West Bengal', 'Sundarbans', 'Darjeeling', 'Heritage', 'Offbeat'],
    contentSections: [
      {
        heading: '1. Sundarbans: The Mystical Mangrove Kingdom of the Royal Bengal Tiger',
        body: 'Located just a 3-hour journey from Kolkata, the Sundarbans is a UNESCO World Heritage biosphere consisting of 102 deltaic islands. Boarding an eco-friendly wooden boat safari allows you to drift through quiet creeks lined with breathing roots (pneumatophores), spotting saltwater crocodiles, spotted deer, kingfishers, and the legendary swimming tigers.',
        bullets: [
          'Best Time: November to February when migratory birds flock to Sajnekhali Sanctuary',
          'Experience: Night skies devoid of light pollution and traditional Baul folk music on river boats'
        ]
      },
      {
        heading: '2. Darjeeling & Kurseong: Queen of the Hills',
        body: 'Ride the century-old Darjeeling Himalayan Railway (the historic "Toy Train") winding up to 2,200 meters. Wake up at 4:30 AM at Tiger Hill to watch the sunrise illuminate the towering snow-covered peaks of Mount Kanchenjunga (8,586m) in shades of crimson and gold, followed by fresh First Flush Darjeeling tea tasting.',
        bullets: [
          'Stay at heritage British-era tea estate bungalows like Glenburn or Makaibari',
          'Sample piping hot Tibetan momos and thukpa soup on Mall Road'
        ]
      },
      {
        heading: '3. Terracotta Wonder of Bishnupur & Heritage of Shantiniketan',
        body: 'Bishnupur in Bankura is famed for its 17th-century Malla dynasty terracotta temples adorned with intricate scenes from the Ramayana and Mahabharata, alongside the weaving of opulent Baluchari silk sarees. Nearby Shantiniketan provides a peaceful glimpse into Nobel Laureate Rabindranath Tagore’s open-air Visva-Bharati University and vibrant Poush Mela folk festivals.',
        bullets: [
          'Pick up authentic Bankura terracotta horses and Dokra brass sculptures directly from artisan villages',
          'Savor traditional Bengali thalis served on banana leaves with seasonal freshwater fish and fragrant Gobindobhog rice'
        ]
      }
    ]
  },
  {
    id: 'paris-insider-secrets',
    title: 'Paris Like a Local: Hidden Passages, Secret Gardens & Rooftops',
    slug: 'paris-insider-secrets',
    excerpt: 'Escape the tourist queues and discover 19th-century glass-roofed arcades, tranquil canal-side wine bars, and the best secret panoramic viewpoints in the City of Light.',
    author: 'Clara Dubois',
    publishedDate: '2025-02-04',
    readTime: '5 min read',
    category: 'Travel Tips',
    heroImage: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80',
    country: 'France',
    continent: 'europe',
    tags: ['France', 'Paris', 'City Guide', 'Hidden Spots', 'Food', 'Culture'],
    contentSections: [
      {
        heading: '1. Wander the Covered Passages (Passages Couverts)',
        body: 'Tucked between grand boulevards in the 2nd and 9th arrondissements lie Paris’s 19th-century covered arcades. Galerie Vivienne, Passage des Panoramas, and Passage Jouffroy feature ornate mosaic tile floors, cast-iron glass skylights, antique bookstores, tea salons, and vintage doll shops.',
        bullets: [
          'Galerie Vivienne: Built in 1823, one of the most elegant neo-classical covered streets in Paris',
          'Passage des Panoramas: The oldest covered walkway, famous for historic stamp dealers and bistros'
        ]
      },
      {
        heading: '2. The Canals & Promenade Plantée',
        body: 'Instead of the crowded Seine banks near the Eiffel Tower, head to Canal Saint-Martin in the 10th arrondissement where young Parisians sit on iron footbridges drinking craft cider and eating fresh sourdough pizza from Pink Flamingo. Walk along Coulée Verte René-Dumont, a lush elevated linear railway trail that served as the inspiration for NYC’s High Line.',
        bullets: [
          'Watch historic canal locks open and close as barges navigate beneath arched bridges',
          'Picnic at Parc des Buttes-Chaumont with its suspension bridge and cliffside Temple de la Sibylle'
        ]
      }
    ]
  },
  {
    id: 'worlds-greatest-natural-wonders',
    title: 'Earth’s Most Surreal Landscapes: 10 Natural Wonders You Must Witness',
    slug: 'worlds-greatest-natural-wonders',
    excerpt: 'From the infinite salt mirror of Bolivia and fairy chimneys of Cappadocia to roaring Iguazu cataracts and the Northern Lights in Norway.',
    author: 'TRIPORA Nature Expeditions',
    publishedDate: '2025-01-15',
    readTime: '8 min read',
    category: 'Nature Wonders',
    heroImage: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1200&q=80',
    tags: ['Nature', 'Wonders', 'Landscape', 'Bucket List', 'Geology'],
    contentSections: [
      {
        heading: '1. Salar de Uyuni (Bolivia) — The World’s Largest Sky Mirror',
        body: 'Formed by transformed prehistoric lakes in the high Andes plateau, Uyuni stretches across 10,500 km² of pristine white salt. During the rainy season, a thin film of water creates an infinite reflection where horizon and clouds merge seamlessly.',
        bullets: ['Best visit: January to March for the reflective mirror phenomenon']
      },
      {
        heading: '2. Iguazu Falls (Argentina/Brazil) — Roaring Cataracts in the Jungle',
        body: 'Spanning nearly 3 kilometers with 275 individual cascades in the Atlantic Forest, Iguazu produces an overwhelming sensory roar, crowned by the gargantuan Devil’s Throat (Garganta del Diablo).',
        bullets: ['Take the Argentine walkway over the falls and the Brazilian side for the wide panoramic postcard view']
      },
      {
        heading: '3. Milford Sound (New Zealand) — Primeval Glacial Fjord',
        body: 'Sheer vertical cliffs plunging 1,200 meters into ink-black waters where permanent and temporary waterfalls tumble into the mist alongside fur seal rookeries.',
        bullets: ['Experience it in rainy weather when thousands of transient waterfalls come alive']
      }
    ]
  }
];
