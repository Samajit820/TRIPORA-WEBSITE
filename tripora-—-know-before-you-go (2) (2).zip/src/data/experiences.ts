import { ActivityExperience } from '../types';

export const EXPERIENCES_DATA: ActivityExperience[] = [
  {
    id: 'glacier-express',
    title: 'The Glacier Express: World\'s Slowest Express Train',
    country: 'Switzerland',
    location: 'Zermatt to St. Moritz',
    continent: 'europe',
    category: 'Scenic Train',
    difficulty: 'Easy',
    duration: '8 Hours (291 Bridges, 91 Tunnels)',
    description: 'An unforgettable panoramic journey through the heart of the Swiss Alps, crossing the 2,033m Oberalp Pass, the dramatic Rhine Gorge (Swiss Grand Canyon), and the iconic curved Landwasser Viaduct with floor-to-ceiling glass carriage windows.',
    highlights: ['Landwasser Viaduct stone arches', 'Rhine Gorge limestone cliffs', 'Three-course Swiss wine lunch served at your seat', 'Oberalp Pass summit alpine snowfields'],
    bestMonths: 'Year-round (December–April for snowy wonderland, June–September for lush green valleys)',
    tips: 'Reserve Excellence Class or panoramic seats at least 3 months in advance as tickets sell out quickly.',
    image: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'inca-trail-trek',
    title: 'Classic 4-Day Inca Trail to Machu Picchu',
    country: 'Peru',
    location: 'Cusco & Sacred Valley',
    continent: 'south-america',
    category: 'Hiking & Trekking',
    difficulty: 'Challenging',
    duration: '4 Days / 3 Nights (42 km / 26 miles)',
    description: 'The world\'s most iconic historic mountain trek, winding along original stone-paved Incan pathways across high Andean passes (Dead Woman\'s Pass at 4,215m), cloud forests, orchid-filled valleys, and ancient ruins before arriving through the Sun Gate (Inti Punku) into Machu Picchu.',
    highlights: ['Dead Woman\'s Pass (Warmiwañusqa) 4,215m summit', 'Wiñay Wayna cliffside agricultural ruins', 'Sunrise at the Sun Gate over Machu Picchu', 'Campsites beneath the Milky Way in high Andes'],
    bestMonths: 'May to September (Dry Andean winter season; Trail closed in February for maintenance)',
    tips: 'Only 500 permits (including guides/porters) are released per day; book 6 to 9 months ahead.',
    image: 'https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'cappadocia-balloon',
    title: 'Hot Air Balloon Flight at Sunrise over Fairy Chimneys',
    country: 'Turkey',
    location: 'Göreme Valley, Cappadocia',
    continent: 'europe',
    category: 'Adventure',
    difficulty: 'Easy',
    duration: '1 Hour Flight / 3 Hours Total',
    description: 'Drift serenely above the otherworldly volcanic landscape of Cappadocia as the rising sun paints honey-hued tuff valleys, ancient cave dwellings, and hundreds of vibrant balloons drifting across the sky.',
    highlights: ['Floating mere meters above Göreme fairy chimney pinnacles', 'Champagne celebration landing toast', 'Spectacular golden-hour 360° panorama', 'Exploring cave hotels and subterranean cities afterwards'],
    bestMonths: 'April to June & September to November (Mild winds and crystal-clear skies)',
    tips: 'Flights are strictly weather-dependent and subject to aviation authority wind clearance; stay at least 3 nights in Cappadocia to give yourself backup weather windows.',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'route-66-roadtrip',
    title: 'Historic Route 66 Road Trip ("The Mother Road")',
    country: 'United States',
    location: 'Chicago, IL to Santa Monica, CA',
    continent: 'north-america',
    category: 'Road Trip',
    difficulty: 'Moderate',
    duration: '2 to 3 Weeks (3,940 km / 2,448 miles)',
    description: 'The quintessential American open-road odyssey passing through 8 states, vintage neon motels, retro roadside diners, Cadillac Ranch, the Grand Canyon, and Mojave Desert before reaching the Santa Monica Pier.',
    highlights: ['Cadillac Ranch spray-paint art in Texas', 'Midpoint Café in Adrian, TX', 'Sedona Red Rocks and Grand Canyon detour', 'Classic neon signs and Wigwam Motel'],
    bestMonths: 'May to June & September to October (Avoids mid-summer desert heat in Arizona/California)',
    tips: 'Rent a convertible or classic American SUV, and use offline GPS maps as desert cell reception can be spotty.',
    image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'kyoto-tea-ceremony',
    title: 'Traditional Matcha Tea Ceremony in a Historic Machiya',
    country: 'Japan',
    location: 'Gion & Higashiyama, Kyoto',
    continent: 'asia',
    category: 'Cultural Immersion',
    difficulty: 'Easy',
    duration: '1.5 Hours',
    description: 'Immerse in the meditative aesthetic of Chado ("The Way of Tea") guided by a certified tea master in a 200-year-old preserved wooden machiya townhouse overlooking a moss-covered Japanese stone garden.',
    highlights: ['Learning the ritual choreography of whisking stone-ground Uji matcha', 'Savoring handmade seasonal wagashi confectioneries', 'Appreciating handcrafted ceramic chawan tea bowls', 'Dressing in an authentic silk kimono (optional)'],
    bestMonths: 'Year-round (Autumn foliage and spring cherry blossoms add enchanting garden views)',
    tips: 'Wear clean white socks (required for entering tatami tea rooms) and avoid wearing heavy perfumes that interfere with tea aromas.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80'
  }
];
