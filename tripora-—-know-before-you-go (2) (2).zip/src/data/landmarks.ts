import { Landmark } from '../types';

export const LANDMARKS_DATA: Landmark[] = [
  {
    id: 'burj-khalifa',
    name: 'Burj Khalifa',
    location: 'Downtown Dubai',
    country: 'United Arab Emirates',
    countryCode: 'AE',
    cityOrRegion: 'Dubai',
    continent: 'asia',
    category: 'Engineering Marvel',
    overview: 'Piercing the sky at a record-breaking 828 meters (2,716.5 ft), Burj Khalifa is the tallest building and freestanding structure in human history, featuring 163 habitable floors and world-class observation decks.',
    highlights: ['At the Top observation deck on Level 124, 125 & 148', 'Atmosphere luxury dining on Level 122', 'Spectacular Dubai Fountain choreographies at its base', 'Illuminated LED façade shows'],
    whatMakesItSpecial: 'An unprecedented feat of aerodynamic engineering inspired by the desert Hymenocallis flower, utilizing a Y-shaped buttressed core to resist high desert winds.',
    bestFor: ['Panoramic City Views', 'Architecture Enthusiasts', 'Luxury Dining', 'Sunset Photography'],
    nearbyPlaces: ['The Dubai Mall', 'Dubai Fountain', 'Dubai Opera', 'Souk Al Bahar', 'Museum of the Future'],
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1526495124232-a04e1849168c?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'The tip of the Burj Khalifa can be seen from up to 95 kilometers (60 miles) away.',
      'The building is so tall that people on the highest floors see the sun set several minutes later than people at ground level, altering their Ramadan fasting times.'
    ],
    entryTip: 'Book the "At The Top SKY" ticket for Level 148 to skip all queues and enjoy the world\'s highest outdoor observation terrace.',
    unescoYear: undefined
  },
  {
    id: 'mount-everest',
    name: 'Mount Everest (Sagarmatha / Chomolungma)',
    location: 'Mahalangur Himal, Himalayas',
    country: 'Nepal & China',
    countryCode: 'NP',
    cityOrRegion: 'Solukhumbu District / Tibet',
    continent: 'asia',
    category: 'Natural Wonder',
    overview: 'The roof of the world, Mount Everest stands at an official elevation of 8,848.86 meters (29,031.7 ft) above sea level, drawing elite mountaineers and adventurous trekkers to the Everest Base Camp.',
    highlights: ['Everest Base Camp (5,364m) trekking route', 'Kala Patthar panoramic viewpoint (5,644m)', 'Namche Bazaar Sherpa capital', 'Tengboche Monastery with mountain backdrops'],
    whatMakesItSpecial: 'Revered as the goddess mother of the world (Chomolungma in Tibetan, Sagarmatha in Nepali), it represents the pinnacle of geological uplift and human endurance.',
    bestFor: ['High-Altitude Trekking', 'Mountaineering', 'Photography', 'Himalayan Culture'],
    nearbyPlaces: ['Lhotse (8,516m)', 'Nuptse', 'Ama Dablam', 'Gokyo Lakes', 'Khumbu Glacier & Icefall'],
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'Due to tectonic collision between the Indian and Eurasian plates, Mount Everest is growing by roughly 4 millimeters every single year.',
      'Sir Edmund Hillary and Tenzing Norgay were the first confirmed climbers to reach the summit on May 29, 1953.'
    ],
    entryTip: 'Trek in October-November or April-May for crystal clear mountain visibility and stable weather.',
    unescoYear: 1979
  },
  {
    id: 'ha-long-bay',
    name: 'Ha Long Bay',
    location: 'Quang Ninh Province',
    country: 'Vietnam',
    countryCode: 'VN',
    cityOrRegion: 'Gulf of Tonkin',
    continent: 'asia',
    category: 'Natural Wonder',
    overview: 'A UNESCO World Heritage marvel, Ha Long Bay features over 1,600 towering limestone karsts, islets, emerald waters, hidden grottos, floating fishing villages, and tranquil sea-kayaking lagoons.',
    highlights: ['Overnight traditional junk boat cruises', 'Sung Sot (Surprise) Cave stalactite chambers', 'Ti Top Island panoramic viewpoint and beach', 'Kayaking through Luon Cave lagoon'],
    whatMakesItSpecial: 'According to Vietnamese legend, dragons descended from the heavens spitting jewels and jade that transformed into karst islands to defend the coast from invaders.',
    bestFor: ['Cruises & Boating', 'Kayaking', 'Cave Exploration', 'Island Photography'],
    nearbyPlaces: ['Cat Ba Island', 'Lan Ha Bay', 'Bai Tu Long Bay', 'Hanoi Old Quarter (2.5 hrs via expressway)'],
    image: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1506665531195-3566af2b4dfa?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'Most of the 1,600 islands are uninhabited and completely untouched by human development due to their sheer cliffs.',
      'The bay has been the film backdrop for numerous Hollywood films including Kong: Skull Island.'
    ],
    entryTip: 'Choose a 2-day/1-night or 3-day cruise that explores Lan Ha Bay or Bai Tu Long Bay to escape the crowded central boating lanes.',
    unescoYear: 1994
  },
  {
    id: 'swiss-alps-matterhorn',
    name: 'The Matterhorn & Swiss Alps',
    location: 'Zermatt, Valais',
    country: 'Switzerland & Italy',
    countryCode: 'CH',
    cityOrRegion: 'Zermatt / Cervinia',
    continent: 'europe',
    category: 'Natural Wonder',
    overview: 'The nearly symmetrical pyramid peak of the Matterhorn (4,478m) reigns over the car-free alpine resort of Zermatt, defining the spirit of Swiss mountaineering and iconic luxury chalets.',
    highlights: ['Gornergrat Cogwheel Railway (3,089m)', 'Matterhorn Glacier Paradise (Highest cable car station in Europe, 3,883m)', 'Five Lakes Trail (5-Seenweg) mirroring the peak', 'Year-round glacier skiing'],
    whatMakesItSpecial: 'Its four steep triangular faces align with the four cardinal points of the compass, instantly recognizable as the iconic shape on Toblerone chocolate bars.',
    bestFor: ['Alpine Skiing', 'Scenic Hiking', 'Cogwheel Train Journeys', 'Luxury Wellness'],
    nearbyPlaces: ['Gorner Glacier', 'Interlaken & Jungfrau region', 'Lake Geneva', 'St. Moritz'],
    image: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1527668752968-14dc70a27c95?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'Zermatt is an entirely combustion-engine-free village; only small electric buggies and horse carriages are permitted.',
      'More than 500 climbers have lost their lives attempting to summit the peak since the first ascent in 1865.'
    ],
    entryTip: 'Take the first morning Gornergrat train to catch Riffelsee lake before the morning breeze creates ripples on the reflection.',
    unescoYear: 2001
  },
  {
    id: 'amalfi-coast',
    name: 'Amalfi Coast (Costiera Amalfitana)',
    location: 'Campania',
    country: 'Italy',
    countryCode: 'IT',
    cityOrRegion: 'Salerno / Naples Province',
    continent: 'europe',
    category: 'Natural Wonder',
    overview: 'A 50-kilometer stretch of dramatic Mediterranean coastline where pastel-colored cliffside villages, fragrant terraced lemon orchards, azure coves, and cliff-clinging roads overlook the Tyrrhenian Sea.',
    highlights: ['Positano vertical pastel village & Spiaggia Grande', 'Ravello cliffside gardens at Villa Cimbrone & Villa Rufolo', 'Amalfi town and 9th-century Arab-Norman Cathedral', 'Path of the Gods (Sentiero degli Dei) hiking trail'],
    whatMakesItSpecial: 'An exquisite UNESCO cultural landscape where human architecture has adapted harmoniously to vertical limestone cliffs over two millennia.',
    bestFor: ['Romantic Getaways', 'Coastal Boat Charters', 'Gastronomy & Limoncello', 'Cliffside Hiking'],
    nearbyPlaces: ['Capri Island & Blue Grotto', 'Sorrento', 'Pompeii & Herculaneum archaeological ruins', 'Naples'],
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'The region\'s giant "Sfusato Amalfitano" lemons are so sweet and low-acid they can be eaten whole like apples, rind included.',
      'Driving the narrow cliff road SS163 requires navigating 1,000+ tight blind hairpins with sheer drops into the sea.'
    ],
    entryTip: 'Travel between towns using local passenger ferries instead of crowded buses to enjoy stunning cliffside views and avoid traffic.',
    unescoYear: 1997
  },
  {
    id: 'taj-mahal',
    name: 'Taj Mahal',
    location: 'Agra, Uttar Pradesh',
    country: 'India',
    countryCode: 'IN',
    cityOrRegion: 'Agra',
    continent: 'asia',
    category: 'Architectural',
    overview: 'An ivory-white marble mausoleum on the southern bank of the Yamuna River, commissioned in 1631 by Mughal Emperor Shah Jahan to house the tomb of his beloved wife Mumtaz Mahal. One of the New 7 Wonders of the World.',
    highlights: ['Pietra dura semi-precious stone inlay floral patterns', 'Perfect bilateral Islamic architectural symmetry', 'Mehtab Bagh sunset viewing gardens across the river', 'Changing color hues from dawn to moonlit nights'],
    whatMakesItSpecial: 'Described by poet Rabindranath Tagore as "a teardrop on the cheek of time", it is universally admired as the greatest architectural triumph of Indo-Islamic art.',
    bestFor: ['Romantic Heritage', 'Architectural Photography', 'Mughal History', 'UNESCO Sites'],
    nearbyPlaces: ['Agra Fort', 'Fatehpur Sikri', 'Itmad-ud-Daulah (Baby Taj)', 'Delhi (1 hr 40 mins via Gatimaan Express train)'],
    image: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'The four outer minarets were deliberately constructed leaning slightly outward so that in the event of an earthquake, they would collapse away from the central dome.',
      'Over 20,000 artisans, sculptors, calligraphers, and 1,000 elephants worked for 22 years to complete the complex.'
    ],
    entryTip: 'Visit at dawn (gates open 30 minutes before sunrise) on weekdays (closed on Fridays) for ethereal soft pink morning light and smaller crowds.',
    unescoYear: 1983
  },
  {
    id: 'machu-picchu',
    name: 'Machu Picchu',
    location: 'Cusco Region, Urubamba Province',
    country: 'Peru',
    countryCode: 'PE',
    cityOrRegion: 'Sacred Valley of the Incas',
    continent: 'south-america',
    category: 'Ancient Monument',
    overview: 'Perched 2,430 meters (7,970 ft) high on a mist-shrouded Andean mountain ridge above the Sacred Valley, this 15th-century Inca citadel is renowned for its polished dry-stone mortarless masonry and astronomical alignments.',
    highlights: ['Temple of the Sun & Intihuatana Sun Stone', 'Sun Gate (Inti Punku) view arriving from Inca Trail', 'Huayna Picchu & Machu Picchu Mountain summit hikes', 'Agricultural terraces overlooking cloud forests'],
    whatMakesItSpecial: 'Built at the height of the Incan Empire and abandoned during the Spanish conquest, it remained hidden from the outside world until American historian Hiram Bingham was guided to it in 1911.',
    bestFor: ['Archaeological Exploration', 'Inca Trail Trekking', 'High Andean Scenery', 'Mystical Heritage'],
    nearbyPlaces: ['Ollantaytambo', 'Cusco Imperial City', 'Moray Terraces & Maras Salt Mines', 'Vinicunca (Rainbow Mountain)'],
    image: 'https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1509299349698-dd22323b5963?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'The stones were fitted so precisely without mortar that not even a single razor blade can slide between the seams.',
      'Over 60% of the entire construction of Machu Picchu lies underground in the form of deep foundations and stone drainage channels to prevent landslides.'
    ],
    entryTip: 'Acclimatize in Cusco (3,400m) for at least 2 full days before tackling the steep stairs, and book entrance Circuit 1 or 2 tickets 3-4 months in advance.',
    unescoYear: 1983
  },
  {
    id: 'uluru',
    name: 'Uluru (Ayers Rock)',
    location: 'Red Centre, Northern Territory',
    country: 'Australia',
    countryCode: 'AU',
    cityOrRegion: 'Uluru-Kata Tjuta National Park',
    continent: 'oceania',
    category: 'Natural Wonder',
    overview: 'A massive 348-meter-tall sacred red sandstone monolith rising abruptly out of the flat desert sands of Central Australia, deeply sacred to the local Anangu Aboriginal Pitjantjatjara custodians.',
    highlights: ['Spectacular color shifts from fiery ochre to deep violet at sunrise and sunset', '10.6 km base walk past ancient caves and sacred waterholes', 'Kata Tjuta (The Olgas) 36 dome rock formations', 'Field of Light desert art installation by Bruce Munro'],
    whatMakesItSpecial: 'More than two-thirds of the monolith is buried deep underground like a terrestrial iceberg, extending down at least 2.5 kilometers beneath the desert floor.',
    bestFor: ['Aboriginal Culture & Astronomy', 'Desert Sunrises', 'Geological Wonders', 'Outback Adventures'],
    nearbyPlaces: ['Kata Tjuta (Valley of the Winds)', 'Kings Canyon (Watarrka)', 'Alice Springs'],
    image: 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'Climbing Uluru was permanently closed in October 2019 out of respect for Anangu traditional law and environmental protection.',
      'Uluru is estimated to be approximately 550 million years old.'
    ],
    entryTip: 'Visit during the Australian winter (May to September) when daytime temperatures hover around a pleasant 20-25°C.',
    unescoYear: 1987
  },
  {
    id: 'milford-sound',
    name: 'Milford Sound (Piopiotahi)',
    location: 'Fiordland National Park, South Island',
    country: 'New Zealand',
    countryCode: 'NZ',
    cityOrRegion: 'Te Anau / Queenstown',
    continent: 'oceania',
    category: 'Natural Wonder',
    overview: 'Hailed by Rudyard Kipling as the "Eighth Wonder of the World", Milford Sound is a dramatic glacier-carved fjord carved by sheer vertical rock faces rising 1,200 meters above dark ink-blue waters with cascading waterfalls.',
    highlights: ['Stirling Falls & Lady Bowen Falls', 'Mitre Peak rising 1,692 meters directly out of the fjord', 'Fiordland fur seals basking on seal rocks & bottlenose dolphins', 'Milford Track 4-day Great Walk'],
    whatMakesItSpecial: 'When it rains (which occurs nearly 200 days a year), hundreds of temporary vertical waterfalls emerge down the sheer granite cliffs, creating a surreal misty atmosphere.',
    bestFor: ['Fjord Scenic Cruises', 'Sea Kayaking', 'Scenic Helicopter Flights', 'Nature Photography'],
    nearbyPlaces: ['Doubtful Sound', 'Te Anau Glowworm Caves', 'Queenstown Adventure Capital (4 hrs drive / 40 min flight)'],
    image: 'https://images.unsplash.com/photo-1507699622108-4be3abd695ad?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'Milford Sound is one of the wettest inhabited places on Earth, receiving an astounding 6,800 millimeters (268 inches) of rainfall annually.',
      'The top layer of fresh rainwater creates a tannin-stained tea-colored barrier that allows deep-sea black coral to grow at depths as shallow as 10 meters.'
    ],
    entryTip: 'Don’t fear the rain—Milford Sound is actually at its most dramatic during heavy rain when thousands of temporary waterfalls roar off the cliffs.',
    unescoYear: 1990
  },
  {
    id: 'galapagos-islands',
    name: 'Galápagos Islands',
    location: 'Pacific Ocean (1,000 km west of Ecuador mainland)',
    country: 'Ecuador',
    countryCode: 'EC',
    cityOrRegion: 'Galápagos Province',
    continent: 'south-america',
    category: 'Natural Wonder',
    overview: 'A volcanic archipelago in the Pacific Ocean famous for its exceptionally fearless wildlife and unique evolutionary adaptations that directly inspired Charles Darwin’s theory of natural selection in 1835.',
    highlights: ['Giant Galápagos Tortoises living 150+ years', 'Marine Iguanas—the only ocean-foraging lizards on Earth', 'Blue-Footed Booby mating dances', 'Snorkeling with sea lions, penguins, and hammerhead sharks'],
    whatMakesItSpecial: 'Due to their isolated volcanic origin and strict national park conservation, the animals have no natural fear of humans, allowing incredible close-up ethical encounters.',
    bestFor: ['Wildlife Expeditions', 'Scuba Diving & Snorkeling', 'Evolutionary Science', 'Eco-Cruises'],
    nearbyPlaces: ['Santa Cruz Island', 'Isabela Island & Sierra Negra Volcano', 'San Cristóbal Island', 'Bartolomé Island Pinnacle Rock'],
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=800&q=80'
    ],
    interestingFacts: [
      'The Galápagos is home to the only penguin species living north of the equator (the Galápagos penguin).',
      'The name "Galápagos" comes from an old Spanish word for riding saddles, referencing the saddleback shape of the giant tortoise shells.'
    ],
    entryTip: 'Bring a certified waterproof action camera or underwater housing; the most memorable wildlife encounters happen just beneath the ocean surface.',
    unescoYear: 1978
  }
];
