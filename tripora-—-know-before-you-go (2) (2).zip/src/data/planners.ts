import { PackingItem, TravelFAQ } from '../types';

export const PACKING_ITEMS_DATABASE: PackingItem[] = [
  // Documents
  { id: 'doc-1', name: 'Valid Passport (6+ Months remaining validity)', category: 'Documents', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'doc-2', name: 'Printed Visas / Official eVisa confirmation', category: 'Documents', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'doc-3', name: 'International Travel Insurance Policy with emergency medical', category: 'Documents', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'doc-4', name: 'International Driving Permit (IDP) & National License', category: 'Documents', tripTypes: ['General', 'City', 'Backpacking'], essential: false },
  { id: 'doc-5', name: 'Hotel & Flight booking confirmations (digital & offline copy)', category: 'Documents', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'doc-6', name: 'Multi-currency travel debit/credit card (Zero foreign transaction fees)', category: 'Documents', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },

  // Electronics
  { id: 'el-1', name: 'Universal Travel Power Adapter (All-in-one plug)', category: 'Electronics', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'el-2', name: 'Portable Power Bank (10,000mAh - 20,000mAh airline-approved)', category: 'Electronics', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'el-3', name: 'Noise-canceling headphones / earbuds for long flights', category: 'Electronics', tripTypes: ['General', 'City', 'Backpacking'], essential: false },
  { id: 'el-4', name: 'Unlocked Smartphone with pre-installed eSIM', category: 'Electronics', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'el-5', name: 'Waterproof phone pouch / dry bag', category: 'Electronics', tripTypes: ['Beach', 'Hiking', 'Rainy'], essential: false },

  // Clothing
  { id: 'cl-1', name: 'Breathable, quick-dry t-shirts and base layers', category: 'Clothing', tripTypes: ['General', 'Beach', 'Hiking', 'City', 'Backpacking'], essential: true },
  { id: 'cl-2', name: 'Comfortable lightweight walking pants & shorts', category: 'Clothing', tripTypes: ['General', 'Beach', 'Hiking', 'City', 'Backpacking'], essential: true },
  { id: 'cl-3', name: 'Lightweight packable waterproof rain jacket / windbreaker', category: 'Clothing', tripTypes: ['General', 'Hiking', 'City', 'Rainy', 'Backpacking'], essential: true },
  { id: 'cl-4', name: 'Thermal base layers (Merino wool top & bottoms)', category: 'Clothing', tripTypes: ['Winter', 'Hiking'], essential: true },
  { id: 'cl-5', name: 'Insulated down puffer jacket & fleece sweater', category: 'Clothing', tripTypes: ['Winter', 'Hiking'], essential: true },
  { id: 'cl-6', name: 'Swimwear / Board shorts / UV Rashguard', category: 'Clothing', tripTypes: ['Beach'], essential: true },
  { id: 'cl-7', name: 'Modest temple clothing (covering shoulders & below knees)', category: 'Clothing', tripTypes: ['General', 'City', 'Backpacking'], essential: false },
  { id: 'cl-8', name: 'Warm wool beanie, neck gaiter, and touch-screen gloves', category: 'Clothing', tripTypes: ['Winter', 'Hiking'], essential: true },

  // Footwear
  { id: 'fw-1', name: 'Ergonomic cushioned walking sneakers (already broken-in)', category: 'Footwear', tripTypes: ['General', 'City', 'Backpacking'], essential: true },
  { id: 'fw-2', name: 'Waterproof ankle-support hiking boots with Vibram grip', category: 'Footwear', tripTypes: ['Hiking'], essential: true },
  { id: 'fw-3', name: 'Comfortable quick-drying sandals / flip-flops', category: 'Footwear', tripTypes: ['Beach', 'Backpacking'], essential: false },
  { id: 'fw-4', name: 'Moisture-wicking anti-blister merino wool socks', category: 'Footwear', tripTypes: ['Hiking', 'Winter', 'City'], essential: true },

  // Health & Toiletries
  { id: 'ht-1', name: 'Travel First Aid Kit (Bandages, antiseptic, pain relievers, antidiarrheals)', category: 'Health & Safety', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },
  { id: 'ht-2', name: 'Broad-spectrum Reef-safe Sunscreen SPF 50+', category: 'Health & Safety', tripTypes: ['Beach', 'Hiking', 'General'], essential: true },
  { id: 'ht-3', name: 'High-strength DEET / Picaridin Insect Repellent', category: 'Health & Safety', tripTypes: ['Beach', 'Hiking', 'Backpacking'], essential: true },
  { id: 'ht-4', name: 'Electrolyte rehydration powder sachets', category: 'Health & Safety', tripTypes: ['Beach', 'Hiking', 'Backpacking'], essential: false },
  { id: 'ht-5', name: 'Hand sanitizer & disinfectant wipes', category: 'Toiletries', tripTypes: ['General', 'Beach', 'Hiking', 'Winter', 'City', 'Backpacking'], essential: true },

  // Outdoor Gear
  { id: 'og-1', name: 'Daypack backpack (20-30L) with rain cover', category: 'Outdoor Gear', tripTypes: ['Hiking', 'City', 'Backpacking'], essential: true },
  { id: 'og-2', name: 'Insulated reusable water bottle / Hydration bladder', category: 'Outdoor Gear', tripTypes: ['Hiking', 'General', 'Backpacking'], essential: true },
  { id: 'og-3', name: 'UV Protection Sunglasses (Polarized)', category: 'Outdoor Gear', tripTypes: ['Beach', 'Hiking', 'Winter', 'General'], essential: true },
  { id: 'og-4', name: 'LED Headlamp with extra batteries / USB recharge', category: 'Outdoor Gear', tripTypes: ['Hiking', 'Backpacking'], essential: false }
];

export const VISA_DESTINATIONS_DATA = [
  { country: 'India', flag: '🇮🇳', visaType: 'e-Visa (30 days / 1 yr / 5 yr)', processingTime: '2-4 Days', feeUSD: '$25-$80', validPassports: '160+ Nations eligible online', officialUrl: 'https://indianvisaonline.gov.in', notes: 'Must apply at least 4 days before flight; biometrics captured at airport arrival.' },
  { country: 'Japan', flag: '🇯🇵', visaType: 'Visa-Free Exemption (up to 90 days)', processingTime: 'Instant at border', feeUSD: 'Free', validPassports: 'US, UK, EU, CAN, AUS, SG, KR and 68+ countries', officialUrl: 'https://www.mofa.go.jp', notes: 'Complete Visit Japan Web QR code prior to flight for fast-track immigration and customs.' },
  { country: 'France / Schengen Zone', flag: '🇫🇷', visaType: 'Schengen Visa-Free (90/180 days)', processingTime: 'Instant / 15 days for visa', feeUSD: 'Free / €90 (Visa)', validPassports: 'US, UK, CAN, AUS, JP, NZ, etc.', officialUrl: 'https://france-visas.gouv.fr', notes: 'Subject to the strict 90/180-day rolling rule across all 29 Schengen member states.' },
  { country: 'United States', flag: '🇺🇸', visaType: 'ESTA (Visa Waiver) / B1-B2 Visa', processingTime: 'ESTA: 72 hrs / B1-B2: Varies', feeUSD: '$21 (ESTA) / $185 (B1/B2)', validPassports: '41 Visa Waiver Countries (ESTA)', officialUrl: 'https://esta.cbp.dhs.gov', notes: 'ESTA is valid for 2 years or until passport expires for visits up to 90 days.' },
  { country: 'Thailand', flag: '🇹🇭', visaType: 'Visa Exemption (60 days)', processingTime: 'Instant at border', feeUSD: 'Free', validPassports: '93 Countries eligible', officialUrl: 'https://www.thaievisa.go.th', notes: 'Extended from 30 to 60 days in recent updates; extendable for another 30 days in-country.' },
  { country: 'Australia', flag: '🇦🇺', visaType: 'eVisitor (Subclass 651) / ETA (Subclass 601)', processingTime: 'Instant to 24 hrs', feeUSD: 'Free (eVisitor) / A$20 app fee (ETA)', validPassports: 'EU, US, UK, CAN, JP, SG, etc.', officialUrl: 'https://immi.homeaffairs.gov.au', notes: 'Apply via the official AustralianETA mobile smartphone app.' },
  { country: 'Egypt', flag: '🇪🇬', visaType: 'Visa on Arrival / Official eVisa', processingTime: 'Instant at Cairo airport / 3-5 days online', feeUSD: '$25 USD (Exact cash or card)', validPassports: '74+ Countries', officialUrl: 'https://visa2egypt.gov.eg', notes: 'Single entry valid for 30 days. Carry crisp USD bills for airport arrival desk.' },
  { country: 'United Arab Emirates', flag: '🇦🇪', visaType: 'Free 30-day / 90-day Visa on Arrival', processingTime: 'Instant at immigration', feeUSD: 'Free', validPassports: 'US, UK, EU, AUS, CAN, NZ, GCC and 70+ nations', officialUrl: 'https://u.ae', notes: 'Passports must be valid for at least 6 months from entry date.' }
];

export const GENERAL_TRAVEL_FAQS: TravelFAQ[] = [
  {
    id: 'faq-1',
    question: 'How do I check if I need a tourist visa before booking international flights?',
    answer: 'Always verify entry requirements on the official government immigration or embassy website of your destination country at least 6-8 weeks prior to departure. Ensure your passport has at least 6 months of validity beyond your planned return date and at least 2 entirely blank visa pages.',
    category: 'Visa'
  },
  {
    id: 'faq-2',
    question: 'What is the best way to handle foreign currency and avoid high bank fees abroad?',
    answer: 'Use travel-focused debit/credit cards that charge 0% foreign transaction fees and use mid-market exchange rates (such as Wise, Revolut, or Charles Schwab). Always choose to be charged in the "Local Currency" on card terminals rather than your home currency to avoid dynamic currency conversion markups of 5-10%. Carry a small emergency cash stash in USD or Euros.',
    category: 'Budget'
  },
  {
    id: 'faq-3',
    question: 'What should I do if my flight is canceled or significantly delayed?',
    answer: 'Under EU Regulation 261/2004 (for flights within or departing Europe) and UK regulations, you may be entitled to free meals, hotel accommodation, and compensation of €250 to €600. Keep all receipts and documentation, and contact your travel insurance provider immediately.',
    category: 'General'
  },
  {
    id: 'faq-4',
    question: 'How do I get mobile data and internet while traveling internationally?',
    answer: 'The most cost-effective and convenient method today is purchasing a digital travel eSIM (such as Airalo, Holafly, or Maya Mobile) before boarding your flight. You can activate it instantly upon landing without swapping physical SIM cards.',
    category: 'General'
  },
  {
    id: 'faq-5',
    question: 'What are the essential packing rules for carry-on luggage on international flights?',
    answer: 'All liquids, aerosols, and gels in carry-on luggage must be in containers of 100ml (3.4 oz) or less, placed inside a single clear resealable plastic quart bag. Never pack lithium-ion power banks, prescription medications, or expensive jewelry in checked baggage—they must always remain in your carry-on bag.',
    category: 'Packing'
  }
];
