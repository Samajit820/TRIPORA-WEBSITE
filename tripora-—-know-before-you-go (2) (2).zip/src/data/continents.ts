import { Continent, OceanSea, GeographicFeature } from '../types';

export const CONTINENTS: Continent[] = [
  {
    id: 'asia',
    name: 'Asia',
    tagline: 'The Largest & Most Populous Continent',
    countriesCount: 48,
    population: '4.75 Billion (59.5% of world)',
    area: '44,579,000 km²',
    highestPoint: 'Mount Everest (8,848.86 m, Nepal/China)',
    lowestPoint: 'Dead Sea (−430.5 m, Jordan/Israel)',
    largestCity: 'Tokyo, Japan (37.4M metro)',
    majorOceans: ['Pacific Ocean', 'Indian Ocean', 'Arctic Ocean'],
    climateSummary: 'Extremes from Arctic Siberia to tropical rainforests of Southeast Asia and Arabian deserts.',
    image: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1200&q=80',
    overview: 'Asia is Earth’s largest continent, home to ancient civilizations, futuristic megacities, the world’s tallest peaks, and immense cultural and biological diversity.',
    highlights: ['Himalayan Mountain Range', 'Great Wall of China', 'Taj Mahal & Indian Subcontinent', 'Kyoto & Tokyo Megalopolis', 'Southeast Asian Archipelago']
  },
  {
    id: 'europe',
    name: 'Europe',
    tagline: 'Cradle of Western Civilization & Historic Capitals',
    countriesCount: 44,
    population: '742 Million (9.3% of world)',
    area: '10,180,000 km²',
    highestPoint: 'Mount Elbrus (5,642 m, Russia) / Mont Blanc (4,808 m, Alps)',
    lowestPoint: 'Caspian Sea Shore (−28 m)',
    largestCity: 'Istanbul (15.8M) / London (9M)',
    majorOceans: ['Atlantic Ocean', 'Arctic Ocean', 'Mediterranean Sea'],
    climateSummary: 'Temperate oceanic in the west, Mediterranean in the south, subarctic/continental in the east & north.',
    image: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=1200&q=80',
    overview: 'Europe blends millennia of preserved architecture, artistic masterpieces, alpine wonderlands, and seamless rail-connected cross-border travel.',
    highlights: ['The Swiss & French Alps', 'Mediterranean Riviera', 'Historic Capitals (Rome, Paris, Vienna, Prague)', 'Nordic Fjords & Northern Lights', 'Castles of the Rhine']
  },
  {
    id: 'africa',
    name: 'Africa',
    tagline: 'The Mother Continent of Wild Wonders & Ancient Origins',
    countriesCount: 54,
    population: '1.43 Billion (18% of world)',
    area: '30,370,000 km²',
    highestPoint: 'Mount Kilimanjaro (5,895 m, Tanzania)',
    lowestPoint: 'Lake Assal (−155 m, Djibouti)',
    largestCity: 'Cairo, Egypt (22M metro)',
    majorOceans: ['Atlantic Ocean', 'Indian Ocean', 'Mediterranean Sea', 'Red Sea'],
    climateSummary: 'Tropical to arid; home to the immense Sahara desert, lush Congo basin, and Serengeti savannahs.',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1200&q=80',
    overview: 'Africa is a land of breathtaking wildlife migrations, endless golden dunes, vibrant tribal heritage, the Nile river, and rapidly expanding modern economic hubs.',
    highlights: ['Serengeti Great Migration', 'Pyramids of Giza & Luxor', 'Victoria Falls (Mosi-oa-Tunya)', 'Sahara & Namib Deserts', 'Cape Peninsula & Table Mountain']
  },
  {
    id: 'north-america',
    name: 'North America',
    tagline: 'Vast National Parks, Canyons & Modern Innovation',
    countriesCount: 23,
    population: '592 Million (7.5% of world)',
    area: '24,709,000 km²',
    highestPoint: 'Denali (6,190 m, Alaska, USA)',
    lowestPoint: 'Badwater Basin, Death Valley (−86 m, USA)',
    largestCity: 'Mexico City (22M metro)',
    majorOceans: ['Pacific Ocean', 'Atlantic Ocean', 'Arctic Ocean', 'Caribbean Sea'],
    climateSummary: 'Polar in Greenland and Northern Canada, temperate across mid-latitudes, subtropical in Florida, tropical in Central America & Caribbean.',
    image: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&w=1200&q=80',
    overview: 'North America stretches from Arctic ice sheets to turquoise Caribbean atolls, featuring iconic national parks, legendary road trips, and cultural epicenters.',
    highlights: ['Grand Canyon & Rocky Mountains', 'Canadian Rockies & Banff', 'Mayan & Aztec Ruins of Mexico', 'Pacific Coast Highway', 'Caribbean Coral Reefs']
  },
  {
    id: 'south-america',
    name: 'South America',
    tagline: 'The Amazon Lungs, Andes Heights & Passionate Rhythms',
    countriesCount: 12,
    population: '434 Million (5.5% of world)',
    area: '17,840,000 km²',
    highestPoint: 'Aconcagua (6,961 m, Argentina)',
    lowestPoint: 'Laguna del Carbón (−105 m, Argentina)',
    largestCity: 'São Paulo, Brazil (22.4M metro)',
    majorOceans: ['Pacific Ocean', 'Atlantic Ocean', 'Southern Ocean'],
    climateSummary: 'Lush tropical equatorial in Amazon, high-altitude Andean plateaus, hyper-arid Atacama desert, and sub-polar Patagonia.',
    image: 'https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=1200&q=80',
    overview: 'South America showcases the planet’s greatest rainforest, the longest continental mountain range (Andes), mystical Incan citadels, and vibrant Latin festivities.',
    highlights: ['Machu Picchu & Sacred Valley', 'Amazon Rainforest & Basin', 'Iguazu Falls (Argentina/Brazil)', 'Patagonia & Torres del Paine', 'Rio Carnival & Copacabana']
  },
  {
    id: 'oceania',
    name: 'Oceania & Australia',
    tagline: 'Island Paradises, Great Barrier Reef & Outback Horizons',
    countriesCount: 14,
    population: '44 Million (0.5% of world)',
    area: '8,525,989 km²',
    highestPoint: 'Puncak Jaya (4,884 m, Papua) / Mt Wilhelm (4,509 m, PNG) / Mt Cook (3,724 m, NZ)',
    lowestPoint: 'Lake Eyre (−15 m, Australia)',
    largestCity: 'Sydney, Australia (5.3M)',
    majorOceans: ['Pacific Ocean', 'Indian Ocean', 'Southern Ocean'],
    climateSummary: 'Tropical in Pacific islands, arid Outback desert in Australia, oceanic temperate in New Zealand.',
    image: 'https://images.unsplash.com/photo-1507699622108-4be3abd695ad?auto=format&fit=crop&w=1200&q=80',
    overview: 'Oceania encompasses the Australian continent, New Zealand’s fjords and geothermal wonders, and thousands of coral atolls scattered across the South Pacific.',
    highlights: ['Great Barrier Reef', 'Sydney Opera House & Harbor', 'Milford Sound & Southern Alps NZ', 'Fiji & Bora Bora Lagoons', 'Uluru Red Center']
  },
  {
    id: 'antarctica',
    name: 'Antarctica',
    tagline: 'The Frozen Frontier & Pristine Polar Wilderness',
    countriesCount: 0,
    population: '1,000 to 5,000 seasonal researchers',
    area: '14,200,000 km²',
    highestPoint: 'Vinson Massif (4,892 m)',
    lowestPoint: 'Bentley Subglacial Trench (−2,555 m)',
    largestCity: 'McMurdo Station (Research Base)',
    majorOceans: ['Southern (Antarctic) Ocean'],
    climateSummary: 'The coldest, windiest, and driest continent on Earth with extreme polar desert conditions.',
    image: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?auto=format&fit=crop&w=1200&q=80',
    overview: 'Antarctica is a colossal ice-covered continent dedicated to scientific research, teeming with penguins, seals, icebergs, and otherworldly glacial landscapes.',
    highlights: ['Drake Passage Crossing', 'Lemaire Channel & Glaciers', 'Emperor & Gentoo Penguin Rookeries', 'South Pole Research Station', 'Deception Island Caldera']
  }
];

export const OCEANS_SEAS: OceanSea[] = [
  {
    id: 'pacific-ocean',
    name: 'Pacific Ocean',
    type: 'Ocean',
    area: '165,250,000 km²',
    averageDepth: '4,280 m',
    deepestPoint: 'Challenger Deep, Mariana Trench (10,994 m)',
    borderingContinents: ['Asia', 'Australia / Oceania', 'North America', 'South America'],
    keyFacts: [
      'Covers more than 30% of the Earth’s surface, larger than all landmasses combined',
      'Encircles the Pacific "Ring of Fire" containing 75% of world’s active volcanoes',
      'Home to over 25,000 islands and immense marine biodiversity'
    ],
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'atlantic-ocean',
    name: 'Atlantic Ocean',
    type: 'Ocean',
    area: '106,460,000 km²',
    averageDepth: '3,646 m',
    deepestPoint: 'Milwaukee Deep, Puerto Rico Trench (8,376 m)',
    borderingContinents: ['Europe', 'Africa', 'North America', 'South America'],
    keyFacts: [
      'Second largest ocean, dividing the "Old World" from the "New World"',
      'Contains the Mid-Atlantic Ridge, the longest mountain range on Earth',
      'Crucial for global weather via the Gulf Stream conveyor belt'
    ],
    image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'indian-ocean',
    name: 'Indian Ocean',
    type: 'Ocean',
    area: '70,560,000 km²',
    averageDepth: '3,741 m',
    deepestPoint: 'Java (Sunda) Trench (7,290 m)',
    borderingContinents: ['Asia', 'Africa', 'Australia'],
    keyFacts: [
      'Warmest ocean on Earth, heavily dictating monsoon weather patterns in South Asia',
      'Historic maritime spice and silk trade routes between East and West',
      'Contains tropical paradises like Maldives, Seychelles, and Mauritius'
    ],
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'southern-ocean',
    name: 'Southern (Antarctic) Ocean',
    type: 'Ocean',
    area: '20,327,000 km²',
    averageDepth: '3,270 m',
    deepestPoint: 'South Sandwich Trench (7,434 m)',
    borderingContinents: ['Antarctica'],
    keyFacts: [
      'Encircles Antarctica with the powerful Antarctic Circumpolar Current',
      'Vital carbon sink and cooling regulator for planetary climate',
      'Home to colossal icebergs, krill blooms, and wandering albatrosses'
    ],
    image: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'arctic-ocean',
    name: 'Arctic Ocean',
    type: 'Ocean',
    area: '14,056,000 km²',
    averageDepth: '1,204 m',
    deepestPoint: 'Molloy Deep, Fram Strait (5,550 m)',
    borderingContinents: ['North America', 'Europe', 'Asia'],
    keyFacts: [
      'Smallest and shallowest ocean, covered in sea ice throughout the polar year',
      'Habitat for polar bears, narwhals, beluga whales, and walruses',
      'Features the Northwest Passage and Northern Sea Route'
    ],
    image: 'https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'mediterranean-sea',
    name: 'Mediterranean Sea',
    type: 'Sea',
    area: '2,500,000 km²',
    averageDepth: '1,500 m',
    deepestPoint: 'Calypso Deep, Ionian Sea (5,267 m)',
    borderingContinents: ['Europe', 'Africa', 'Asia'],
    keyFacts: [
      'Enclosed intercontinental sea connected to the Atlantic via Strait of Gibraltar',
      'Historic birthplace of Greek, Roman, Phoenician, and Egyptian maritime trade',
      'Famous for azure waters, olive groves, and healthy Mediterranean lifestyle'
    ],
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80'
  }
];

export const GEOGRAPHIC_FEATURES: GeographicFeature[] = [
  {
    id: 'himalayas',
    name: 'Himalayan Mountain Range',
    type: 'Mountain Range',
    location: 'Nepal, India, Bhutan, China, Pakistan',
    continent: 'Asia',
    keyMetric: '8,848.86 m highest peak, 2,400 km long',
    description: 'The "Abode of Snow", home to all 14 of the world\'s 8,000-meter peaks including Everest and K2.',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'amazon-basin',
    name: 'Amazon Rainforest & River Basin',
    type: 'Rainforest',
    location: 'Brazil, Peru, Colombia, Bolivia, Ecuador',
    continent: 'South America',
    keyMetric: '6.7 Million km² area, 20% of Earth\'s river water',
    description: 'The planet’s largest tropical rainforest harboring 10% of all known species and absorbing billions of tons of CO2.',
    image: 'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sahara-desert',
    name: 'Sahara Desert',
    type: 'Desert',
    location: 'North Africa across 11 nations',
    continent: 'Africa',
    keyMetric: '9.2 Million km² (size of USA)',
    description: 'The world\'s largest hot desert featuring shifting sand seas (ergs), rocky plateaus, and oasis cultures.',
    image: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'mariana-trench',
    name: 'Mariana Trench (Challenger Deep)',
    type: 'Trench',
    location: 'Western Pacific Ocean near Guam',
    continent: 'Asia / Oceania',
    keyMetric: '10,994 m depth (36,070 ft below sea level)',
    description: 'The deepest known point on Earth with crushing atmospheric pressure and unique hydrothermal vent life.',
    image: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'great-barrier-reef',
    name: 'Great Barrier Reef',
    type: 'Trench', // used as natural biome
    location: 'Coral Sea, Queensland, Australia',
    continent: 'Oceania',
    keyMetric: '2,300 km long, visible from space',
    description: 'The world\'s largest living coral organism system with 2,900 individual reefs and 900 islands.',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'grand-canyon',
    name: 'Grand Canyon',
    type: 'Plateau',
    location: 'Arizona, USA',
    continent: 'North America',
    keyMetric: '446 km long, 1.8 km deep',
    description: 'Carved by the Colorado River over 6 million years, exposing 2 billion years of Earth’s geological history.',
    image: 'https://images.unsplash.com/photo-1474044159687-1ee9f3a51722?auto=format&fit=crop&w=800&q=80'
  }
];

export const EARTH_LINES = [
  {
    name: 'Equator',
    lat: '0° Latitude',
    length: '40,075 km',
    passesThrough: '13 countries (Ecuador, Colombia, Brazil, Gabon, Congo, DRC, Uganda, Kenya, Somalia, Maldives, Indonesia, Kiribati, São Tomé)',
    description: 'The imaginary line dividing Earth into Northern and Southern Hemispheres, receiving direct sunlight year-round with equal 12-hour day and night.'
  },
  {
    name: 'Tropic of Cancer',
    lat: '23°26′10.7″ North',
    length: '36,788 km',
    passesThrough: '16 countries (Mexico, Bahamas, Egypt, Saudi Arabia, UAE, India, China, Taiwan, etc.)',
    description: 'The northernmost latitude where the Sun can be directly overhead at solar noon (June Solstice).'
  },
  {
    name: 'Tropic of Capricorn',
    lat: '23°26′10.7″ South',
    length: '36,788 km',
    passesThrough: '10 countries (Chile, Argentina, Paraguay, Brazil, Namibia, Botswana, South Africa, Mozambique, Madagascar, Australia)',
    description: 'The southernmost latitude where the Sun can be directly overhead at solar noon (December Solstice).'
  },
  {
    name: 'Prime Meridian',
    lat: '0° Longitude (Greenwich)',
    length: '20,004 km',
    passesThrough: 'UK, France, Spain, Algeria, Mali, Burkina Faso, Togo, Ghana, Antarctica',
    description: 'The universal reference line for world time zones (UTC/GMT), running through the Royal Observatory in Greenwich, London.'
  }
];
