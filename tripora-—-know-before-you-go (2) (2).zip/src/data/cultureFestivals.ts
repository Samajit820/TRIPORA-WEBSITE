import { FestivalItem, CultureItem } from '../types';

export const FESTIVALS_DATA: FestivalItem[] = [
  {
    id: 'durga-puja',
    name: 'Durga Puja (Sharodotsav)',
    nativeName: 'দুর্গাপূজা',
    country: 'India',
    region: 'Kolkata, West Bengal & Worldwide',
    timeOfYear: 'September / October (Autumn - Ashwin month)',
    monthIndex: 9,
    category: 'Cultural',
    historyBackground: 'Inscribed on the UNESCO Representative List of the Intangible Cultural Heritage of Humanity, Durga Puja celebrates the victory of goddess Durga over the shape-shifting demon Mahishasura, symbolizing the triumph of good over evil.',
    culturalSignificance: 'Transcends religion into the world\'s largest open-air contemporary installation art and design exhibition, where thousands of themed neighborhood pavilions ("pandals") are constructed with lighting spectacles.',
    visitorExperience: 'Pandal hopping throughout the night with friends, listening to the thunderous beats of the "Dhaak" drums, tasting street food, and joining the vibrant "Dhunuchi Naach" dance and Sindoor Khela immersion processions on the Hooghly river.',
    image: 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'rio-carnival',
    name: 'Rio de Janeiro Carnival',
    nativeName: 'Carnaval do Rio',
    country: 'Brazil',
    region: 'Rio de Janeiro',
    timeOfYear: 'February / March (Before Christian Lent)',
    monthIndex: 1,
    category: 'Cultural',
    historyBackground: 'Dating back to 1723 with Portuguese origins, the festival evolved into a massive Afro-Brazilian samba celebration driven by Rio\'s community samba schools competing in the purpose-built Sambadrome.',
    culturalSignificance: 'The biggest carnival in the world, bringing together 2 million people per day across the Sambadrome parades and hundreds of energetic free street parties ("blocos").',
    visitorExperience: 'Electrifying samba percussion rhythms, towering multi-story floats adorned with feathers and glitter, flamboyant costumes, and non-stop dancing along Copacabana and Ipanema streets.',
    image: 'https://images.unsplash.com/photo-1516306580124-9b444097bc31?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'hanami-sakura',
    name: 'Cherry Blossom Hanami Festival',
    nativeName: '花見 (Cherry Blossom Viewing)',
    country: 'Japan',
    region: 'Tokyo, Kyoto, Osaka & Nationwide',
    timeOfYear: 'Late March to Mid-April (Spring)',
    monthIndex: 3,
    category: 'Seasonal',
    historyBackground: 'Originating during the Nara Period (710–794), hanami is the thousand-year-old tradition of picnicking under blooming sakura trees, reflecting on the fleeting beauty of life (mono no aware).',
    culturalSignificance: 'National botanical celebration tracked closely by meteorological "sakura fronts" (sakurazensen), marking the start of the Japanese fiscal and academic spring year.',
    visitorExperience: 'Picnicking on blue tarps under pink canopies with bento boxes, sake, and tea; magical night illuminations (yozakura) at Meguro River, Ueno Park, and Maruyama Park in Kyoto.',
    image: 'https://images.unsplash.com/photo-1528164344705-475426879c0d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'diwali',
    name: 'Diwali (The Festival of Lights)',
    nativeName: 'दीपावली / দিওয়ালি',
    country: 'India',
    region: 'Pan-India & South Asian Diaspora',
    timeOfYear: 'October / November (Kartik Amavasya)',
    monthIndex: 10,
    category: 'Religious',
    historyBackground: 'Celebrates Lord Rama’s return to Ayodhya after 14 years of exile and the defeat of Ravana, as well as honoring Goddess Lakshmi, the deity of prosperity and auspicious new beginnings.',
    culturalSignificance: 'Homes, streets, and temples are illuminated with millions of clay oil lamps (diyas) and colorful rangoli geometric floor art to illuminate spiritual darkness.',
    visitorExperience: 'City skylines sparkling with fireworks, tasting assorted sweet mithai boxes, visiting vibrant lit-up bazaars in Delhi, Jaipur, and Varanasi, and experiencing the Ganga Aarti.',
    image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'dia-de-los-muertos',
    name: 'Day of the Dead (Día de los Muertos)',
    nativeName: 'Día de los Muertos',
    country: 'Mexico',
    region: 'Oaxaca, Michoacán & Mexico City',
    timeOfYear: 'November 1st & 2nd',
    monthIndex: 10,
    category: 'Cultural',
    historyBackground: 'An indigenous Mesoamerican tradition harmonized with Catholic All Saints\' Day, believing the border between the spirit world and living realm dissolves so departed souls can reunite with loved ones.',
    culturalSignificance: 'A joyful, poignant celebration rather than a mourning period, honoring memories with colorful ofrenda altars decorated with orange cempasúchil (marigolds) and sugar skulls (calaveras).',
    visitorExperience: 'Elaborate Catrina face paint, candle-lit cemetery vigils filled with guitar serenades, tasting sweet pan de muerto bread, and massive costumed street parades in Mexico City.',
    image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'songkran',
    name: 'Songkran Water Festival',
    nativeName: 'สงกรานต์ (Thai New Year)',
    country: 'Thailand',
    region: 'Bangkok, Chiang Mai, Phuket',
    timeOfYear: 'April 13th to 15th',
    monthIndex: 3,
    category: 'National',
    historyBackground: 'Traditional Thai Buddhist New Year where pouring water signifies cleansing misfortune, sins, and bad karma from the past year to welcome fortune and renewal.',
    culturalSignificance: 'Evolved into the world\'s largest countrywide water fight where streets turn into joyous aquatic arenas alongside morning temple merit-making ceremonies.',
    visitorExperience: 'Armed with super-soaker water guns and buckets of iced water, dancing in festive foam parties on Silom Road and Khao San Road under the hot tropical sun.',
    image: 'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80'
  }
];

export const CULTURES_DATA: CultureItem[] = [
  {
    id: 'japanese-omotenashi',
    title: 'Japanese Omotenashi & Bowing Etiquette',
    country: 'Japan',
    continent: 'asia',
    category: 'Social Etiquette',
    description: 'Omotenashi describes the selfless spirit of mindfulness, hospitality, and anticipation of a guest\'s needs without expecting anything in return.',
    culturalEtiquetteTips: [
      'Bow when greeting, thanking, or saying goodbye; slight head nod for casual encounters, deeper 30-45° bow for formal respect.',
      'Always remove your shoes when stepping onto tatami mat flooring or entering private homes and ryokan inns.',
      'Never stick chopsticks vertically into a bowl of rice, as this mirrors a Buddhist funeral incense rite.',
      'Maintain quiet voices on public commuter trains and avoid taking phone calls.'
    ],
    historicalContext: 'Rooted in the ancient Zen aesthetics of the Japanese Tea Ceremony (Chado), established by master Sen no Rikyu in the 16th century.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'bengali-adda',
    title: 'Bengali "Adda" & Literary Intellectualism',
    country: 'India',
    continent: 'asia',
    category: 'Traditions & Customs',
    description: 'Adda is the uniquely Bengali art of informal, unstructured, and spirited intellectual conversation spanning poetry, politics, philosophy, cinema, and world sports.',
    culturalEtiquetteTips: [
      'Gently join in conversational debates with curiosity—vigorous discussion is considered a supreme form of social warmth.',
      'Always accept when offered a cup of hot milk tea ("cha") and savories by a host.',
      'Touch the feet of elders ("Pranam") as a gesture of deep reverence and blessing.'
    ],
    historicalContext: 'Nurtured during the 19th-century Bengal Renaissance which birthed modern Indian literature, reform movements, and scientific achievements.',
    image: 'https://images.unsplash.com/photo-1558431382-27e303142255?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'italian-passeggiata',
    title: 'La Passeggiata & Dining Rhythm',
    country: 'Italy',
    continent: 'europe',
    category: 'Traditions & Customs',
    description: 'The sacred early evening tradition where locals dress elegantly and leisurely stroll through the central piazza before dinner to socialize, see, and be seen.',
    culturalEtiquetteTips: [
      'Never order a cappuccino after 11:00 AM; Italians drink milk-heavy coffees solely in the morning and switch to espresso (caffè) afterwards.',
      'Do not ask for parmesan cheese on seafood pasta dishes.',
      'Say "Buongiorno" (Good morning) or "Buonasera" (Good evening) upon entering any shop or trattoria.'
    ],
    historicalContext: 'An enduring element of Mediterranean civic life since classical Roman forum gatherings.',
    image: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=800&q=80'
  }
];
