import { CountryFact, ContinentCode } from '../types';

export interface SimpleCountry {
  id: string;
  name: string;
  code: string;
  flag: string;
  capital: string;
  continent: ContinentCode;
  region: string;
  population: string;
  currency: string;
}

// Full 195 UN Recognized Countries Database
export const ALL_195_COUNTRIES: SimpleCountry[] = [
  { id: 'afghanistan', name: 'Afghanistan', code: 'AF', flag: '🇦🇫', capital: 'Kabul', continent: 'asia', region: 'South Asia', population: '41.1M', currency: 'AFN' },
  { id: 'albania', name: 'Albania', code: 'AL', flag: '🇦🇱', capital: 'Tirana', continent: 'europe', region: 'Southern Europe', population: '2.8M', currency: 'ALL' },
  { id: 'algeria', name: 'Algeria', code: 'DZ', flag: '🇩🇿', capital: 'Algiers', continent: 'africa', region: 'North Africa', population: '44.9M', currency: 'DZD' },
  { id: 'andorra', name: 'Andorra', code: 'AD', flag: '🇦🇩', capital: 'Andorra la Vella', continent: 'europe', region: 'Southern Europe', population: '80K', currency: 'EUR' },
  { id: 'angola', name: 'Angola', code: 'AO', flag: '🇦🇴', capital: 'Luanda', continent: 'africa', region: 'Middle Africa', population: '35.6M', currency: 'AOA' },
  { id: 'antigua-and-barbuda', name: 'Antigua and Barbuda', code: 'AG', flag: '🇦🇬', capital: "Saint John's", continent: 'north-america', region: 'Caribbean', population: '94K', currency: 'XCD' },
  { id: 'argentina', name: 'Argentina', code: 'AR', flag: '🇦🇷', capital: 'Buenos Aires', continent: 'south-america', region: 'South America', population: '45.8M', currency: 'ARS' },
  { id: 'armenia', name: 'Armenia', code: 'AM', flag: '🇦🇲', capital: 'Yerevan', continent: 'asia', region: 'Western Asia', population: '2.8M', currency: 'AMD' },
  { id: 'australia', name: 'Australia', code: 'AU', flag: '🇦🇺', capital: 'Canberra', continent: 'oceania', region: 'Australia & NZ', population: '26.4M', currency: 'AUD' },
  { id: 'austria', name: 'Austria', code: 'AT', flag: '🇦🇹', capital: 'Vienna', continent: 'europe', region: 'Western Europe', population: '9.1M', currency: 'EUR' },
  { id: 'azerbaijan', name: 'Azerbaijan', code: 'AZ', flag: '🇦🇿', capital: 'Baku', continent: 'asia', region: 'Western Asia', population: '10.3M', currency: 'AZN' },
  { id: 'bahamas', name: 'Bahamas', code: 'BS', flag: '🇧🇸', capital: 'Nassau', continent: 'north-america', region: 'Caribbean', population: '410K', currency: 'BSD' },
  { id: 'bahrain', name: 'Bahrain', code: 'BH', flag: '🇧🇭', capital: 'Manama', continent: 'asia', region: 'Middle East', population: '1.5M', currency: 'BHD' },
  { id: 'bangladesh', name: 'Bangladesh', code: 'BD', flag: '🇧🇩', capital: 'Dhaka', continent: 'asia', region: 'South Asia', population: '171.2M', currency: 'BDT' },
  { id: 'barbados', name: 'Barbados', code: 'BB', flag: '🇧🇧', capital: 'Bridgetown', continent: 'north-america', region: 'Caribbean', population: '281K', currency: 'BBD' },
  { id: 'belarus', name: 'Belarus', code: 'BY', flag: '🇧🇾', capital: 'Minsk', continent: 'europe', region: 'Eastern Europe', population: '9.2M', currency: 'BYN' },
  { id: 'belgium', name: 'Belgium', code: 'BE', flag: '🇧🇪', capital: 'Brussels', continent: 'europe', region: 'Western Europe', population: '11.7M', currency: 'EUR' },
  { id: 'belize', name: 'Belize', code: 'BZ', flag: '🇧🇿', capital: 'Belmopan', continent: 'north-america', region: 'Central America', population: '405K', currency: 'BZD' },
  { id: 'benin', name: 'Benin', code: 'BJ', flag: '🇧🇯', capital: 'Porto-Novo', continent: 'africa', region: 'West Africa', population: '13.3M', currency: 'XOF' },
  { id: 'bhutan', name: 'Bhutan', code: 'BT', flag: '🇧🇹', capital: 'Thimphu', continent: 'asia', region: 'South Asia', population: '782K', currency: 'BTN' },
  { id: 'bolivia', name: 'Bolivia', code: 'BO', flag: '🇧🇴', capital: 'Sucre / La Paz', continent: 'south-america', region: 'South America', population: '12.2M', currency: 'BOB' },
  { id: 'bosnia-and-herzegovina', name: 'Bosnia and Herzegovina', code: 'BA', flag: '🇧🇦', capital: 'Sarajevo', continent: 'europe', region: 'Southern Europe', population: '3.2M', currency: 'BAM' },
  { id: 'botswana', name: 'Botswana', code: 'BW', flag: '🇧🇼', capital: 'Gaborone', continent: 'africa', region: 'Southern Africa', population: '2.6M', currency: 'BWP' },
  { id: 'brazil', name: 'Brazil', code: 'BR', flag: '🇧🇷', capital: 'Brasília', continent: 'south-america', region: 'South America', population: '216.4M', currency: 'BRL' },
  { id: 'brunei', name: 'Brunei', code: 'BN', flag: '🇧🇳', capital: 'Bandar Seri Begawan', continent: 'asia', region: 'Southeast Asia', population: '450K', currency: 'BND' },
  { id: 'bulgaria', name: 'Bulgaria', code: 'BG', flag: '🇧🇬', capital: 'Sofia', continent: 'europe', region: 'Eastern Europe', population: '6.4M', currency: 'BGN' },
  { id: 'burkina-faso', name: 'Burkina Faso', code: 'BF', flag: '🇧🇫', capital: 'Ouagadougou', continent: 'africa', region: 'West Africa', population: '22.7M', currency: 'XOF' },
  { id: 'burundi', name: 'Burundi', code: 'BI', flag: '🇧🇮', capital: 'Gitega', continent: 'africa', region: 'Eastern Africa', population: '12.9M', currency: 'BIF' },
  { id: 'cabo-verde', name: 'Cabo Verde', code: 'CV', flag: '🇨🇻', capital: 'Praia', continent: 'africa', region: 'West Africa', population: '593K', currency: 'CVE' },
  { id: 'cambodia', name: 'Cambodia', code: 'KH', flag: '🇰🇭', capital: 'Phnom Penh', continent: 'asia', region: 'Southeast Asia', population: '16.8M', currency: 'KHR' },
  { id: 'cameroon', name: 'Cameroon', code: 'CM', flag: '🇨🇲', capital: 'Yaoundé', continent: 'africa', region: 'Middle Africa', population: '27.9M', currency: 'XAF' },
  { id: 'canada', name: 'Canada', code: 'CA', flag: '🇨🇦', capital: 'Ottawa', continent: 'north-america', region: 'Northern America', population: '39.8M', currency: 'CAD' },
  { id: 'central-african-republic', name: 'Central African Republic', code: 'CF', flag: '🇨🇫', capital: 'Bangui', continent: 'africa', region: 'Middle Africa', population: '5.6M', currency: 'XAF' },
  { id: 'chad', name: 'Chad', code: 'TD', flag: '🇹🇩', capital: "N'Djamena", continent: 'africa', region: 'Middle Africa', population: '17.7M', currency: 'XAF' },
  { id: 'chile', name: 'Chile', code: 'CL', flag: '🇨🇱', capital: 'Santiago', continent: 'south-america', region: 'South America', population: '19.6M', currency: 'CLP' },
  { id: 'china', name: 'China', code: 'CN', flag: '🇨🇳', capital: 'Beijing', continent: 'asia', region: 'Eastern Asia', population: '1.41B', currency: 'CNY' },
  { id: 'colombia', name: 'Colombia', code: 'CO', flag: '🇨🇴', capital: 'Bogotá', continent: 'south-america', region: 'South America', population: '52.1M', currency: 'COP' },
  { id: 'comoros', name: 'Comoros', code: 'KM', flag: '🇰🇲', capital: 'Moroni', continent: 'africa', region: 'Eastern Africa', population: '836K', currency: 'KMF' },
  { id: 'congo-brazzaville', name: 'Congo (Republic)', code: 'CG', flag: '🇨🇬', capital: 'Brazzaville', continent: 'africa', region: 'Middle Africa', population: '5.9M', currency: 'XAF' },
  { id: 'congo-kinshasa', name: 'DR Congo', code: 'CD', flag: '🇨🇩', capital: 'Kinshasa', continent: 'africa', region: 'Middle Africa', population: '99M', currency: 'CDF' },
  { id: 'costa-rica', name: 'Costa Rica', code: 'CR', flag: '🇨🇷', capital: 'San José', continent: 'north-america', region: 'Central America', population: '5.2M', currency: 'CRC' },
  { id: 'croatia', name: 'Croatia', code: 'HR', flag: '🇭🇷', capital: 'Zagreb', continent: 'europe', region: 'Southern Europe', population: '3.9M', currency: 'EUR' },
  { id: 'cuba', name: 'Cuba', code: 'CU', flag: '🇨🇺', capital: 'Havana', continent: 'north-america', region: 'Caribbean', population: '11.2M', currency: 'CUP' },
  { id: 'cyprus', name: 'Cyprus', code: 'CY', flag: '🇨🇾', capital: 'Nicosia', continent: 'europe', region: 'Southern Europe', population: '1.25M', currency: 'EUR' },
  { id: 'czechia', name: 'Czechia (Czech Republic)', code: 'CZ', flag: '🇨🇿', capital: 'Prague', continent: 'europe', region: 'Central Europe', population: '10.5M', currency: 'CZK' },
  { id: 'denmark', name: 'Denmark', code: 'DK', flag: '🇩🇰', capital: 'Copenhagen', continent: 'europe', region: 'Northern Europe', population: '5.9M', currency: 'DKK' },
  { id: 'djibouti', name: 'Djibouti', code: 'DJ', flag: '🇩🇯', capital: 'Djibouti City', continent: 'africa', region: 'Eastern Africa', population: '1.1M', currency: 'DJF' },
  { id: 'dominica', name: 'Dominica', code: 'DM', flag: '🇩🇲', capital: 'Roseau', continent: 'north-america', region: 'Caribbean', population: '72K', currency: 'XCD' },
  { id: 'dominican-republic', name: 'Dominican Republic', code: 'DO', flag: '🇩🇴', capital: 'Santo Domingo', continent: 'north-america', region: 'Caribbean', population: '11.3M', currency: 'DOP' },
  { id: 'ecuador', name: 'Ecuador', code: 'EC', flag: '🇪🇨', capital: 'Quito', continent: 'south-america', region: 'South America', population: '18M', currency: 'USD' },
  { id: 'egypt', name: 'Egypt', code: 'EG', flag: '🇪🇬', capital: 'Cairo', continent: 'africa', region: 'North Africa', population: '110.9M', currency: 'EGP' },
  { id: 'el-salvador', name: 'El Salvador', code: 'SV', flag: '🇸🇻', capital: 'San Salvador', continent: 'north-america', region: 'Central America', population: '6.3M', currency: 'USD' },
  { id: 'equatorial-guinea', name: 'Equatorial Guinea', code: 'GQ', flag: '🇬🇶', capital: 'Malabo', continent: 'africa', region: 'Middle Africa', population: '1.7M', currency: 'XAF' },
  { id: 'eritrea', name: 'Eritrea', code: 'ER', flag: '🇪🇷', capital: 'Asmara', continent: 'africa', region: 'Eastern Africa', population: '3.6M', currency: 'ERN' },
  { id: 'estonia', name: 'Estonia', code: 'EE', flag: '🇪🇪', capital: 'Tallinn', continent: 'europe', region: 'Northern Europe', population: '1.3M', currency: 'EUR' },
  { id: 'eswatini', name: 'Eswatini', code: 'SZ', flag: '🇸🇿', capital: 'Mbabane', continent: 'africa', region: 'Southern Africa', population: '1.2M', currency: 'SZL' },
  { id: 'ethiopia', name: 'Ethiopia', code: 'ET', flag: '🇪🇹', capital: 'Addis Ababa', continent: 'africa', region: 'Eastern Africa', population: '123.4M', currency: 'ETB' },
  { id: 'fiji', name: 'Fiji', code: 'FJ', flag: '🇫🇯', capital: 'Suva', continent: 'oceania', region: 'Melanesia', population: '930K', currency: 'FJD' },
  { id: 'finland', name: 'Finland', code: 'FI', flag: '🇫🇮', capital: 'Helsinki', continent: 'europe', region: 'Northern Europe', population: '5.6M', currency: 'EUR' },
  { id: 'france', name: 'France', code: 'FR', flag: '🇫🇷', capital: 'Paris', continent: 'europe', region: 'Western Europe', population: '68M', currency: 'EUR' },
  { id: 'gabon', name: 'Gabon', code: 'GA', flag: '🇬🇦', capital: 'Libreville', continent: 'africa', region: 'Middle Africa', population: '2.4M', currency: 'XAF' },
  { id: 'gambia', name: 'Gambia', code: 'GM', flag: '🇬🇲', capital: 'Banjul', continent: 'africa', region: 'West Africa', population: '2.7M', currency: 'GMD' },
  { id: 'georgia', name: 'Georgia', code: 'GE', flag: '🇬🇪', capital: 'Tbilisi', continent: 'asia', region: 'Western Asia', population: '3.7M', currency: 'GEL' },
  { id: 'germany', name: 'Germany', code: 'DE', flag: '🇩🇪', capital: 'Berlin', continent: 'europe', region: 'Western Europe', population: '84.4M', currency: 'EUR' },
  { id: 'ghana', name: 'Ghana', code: 'GH', flag: '🇬🇭', capital: 'Accra', continent: 'africa', region: 'West Africa', population: '33.5M', currency: 'GHS' },
  { id: 'greece', name: 'Greece', code: 'GR', flag: '🇬🇷', capital: 'Athens', continent: 'europe', region: 'Southern Europe', population: '10.4M', currency: 'EUR' },
  { id: 'grenada', name: 'Grenada', code: 'GD', flag: '🇬🇩', capital: "St. George's", continent: 'north-america', region: 'Caribbean', population: '125K', currency: 'XCD' },
  { id: 'guatemala', name: 'Guatemala', code: 'GT', flag: '🇬🇹', capital: 'Guatemala City', continent: 'north-america', region: 'Central America', population: '17.8M', currency: 'GTQ' },
  { id: 'guinea', name: 'Guinea', code: 'GN', flag: '🇬🇳', capital: 'Conakry', continent: 'africa', region: 'West Africa', population: '13.9M', currency: 'GNF' },
  { id: 'guinea-bissau', name: 'Guinea-Bissau', code: 'GW', flag: '🇬🇼', capital: 'Bissau', continent: 'africa', region: 'West Africa', population: '2.1M', currency: 'XOF' },
  { id: 'guyana', name: 'Guyana', code: 'GY', flag: '🇬🇾', capital: 'Georgetown', continent: 'south-america', region: 'South America', population: '808K', currency: 'GYD' },
  { id: 'haiti', name: 'Haiti', code: 'HT', flag: '🇭🇹', capital: 'Port-au-Prince', continent: 'north-america', region: 'Caribbean', population: '11.6M', currency: 'HTG' },
  { id: 'honduras', name: 'Honduras', code: 'HN', flag: '🇭🇳', capital: 'Tegucigalpa', continent: 'north-america', region: 'Central America', population: '10.4M', currency: 'HNL' },
  { id: 'hungary', name: 'Hungary', code: 'HU', flag: '🇭🇺', capital: 'Budapest', continent: 'europe', region: 'Central Europe', population: '9.7M', currency: 'HUF' },
  { id: 'iceland', name: 'Iceland', code: 'IS', flag: '🇮🇸', capital: 'Reykjavik', continent: 'europe', region: 'Northern Europe', population: '388K', currency: 'ISK' },
  { id: 'india', name: 'India', code: 'IN', flag: '🇮🇳', capital: 'New Delhi', continent: 'asia', region: 'South Asia', population: '1.43B', currency: 'INR' },
  { id: 'indonesia', name: 'Indonesia', code: 'ID', flag: '🇮🇩', capital: 'Jakarta / Nusantara', continent: 'asia', region: 'Southeast Asia', population: '277.5M', currency: 'IDR' },
  { id: 'iran', name: 'Iran', code: 'IR', flag: '🇮🇷', capital: 'Tehran', continent: 'asia', region: 'Middle East', population: '88.5M', currency: 'IRR' },
  { id: 'iraq', name: 'Iraq', code: 'IQ', flag: '🇮🇶', capital: 'Baghdad', continent: 'asia', region: 'Middle East', population: '44.5M', currency: 'IQD' },
  { id: 'ireland', name: 'Ireland', code: 'IE', flag: '🇮🇪', capital: 'Dublin', continent: 'europe', region: 'Northern Europe', population: '5.1M', currency: 'EUR' },
  { id: 'israel', name: 'Israel', code: 'IL', flag: '🇮🇱', capital: 'Jerusalem', continent: 'asia', region: 'Middle East', population: '9.8M', currency: 'ILS' },
  { id: 'italy', name: 'Italy', code: 'IT', flag: '🇮🇹', capital: 'Rome', continent: 'europe', region: 'Southern Europe', population: '58.8M', currency: 'EUR' },
  { id: 'jamaica', name: 'Jamaica', code: 'JM', flag: '🇯🇲', capital: 'Kingston', continent: 'north-america', region: 'Caribbean', population: '2.8M', currency: 'JMD' },
  { id: 'japan', name: 'Japan', code: 'JP', flag: '🇯🇵', capital: 'Tokyo', continent: 'asia', region: 'Eastern Asia', population: '124.5M', currency: 'JPY' },
  { id: 'jordan', name: 'Jordan', code: 'JO', flag: '🇯🇴', capital: 'Amman', continent: 'asia', region: 'Middle East', population: '11.3M', currency: 'JOD' },
  { id: 'kazakhstan', name: 'Kazakhstan', code: 'KZ', flag: '🇰🇿', capital: 'Astana', continent: 'asia', region: 'Central Asia', population: '19.9M', currency: 'KZT' },
  { id: 'kenya', name: 'Kenya', code: 'KE', flag: '🇰🇪', capital: 'Nairobi', continent: 'africa', region: 'Eastern Africa', population: '54M', currency: 'KES' },
  { id: 'kiribati', name: 'Kiribati', code: 'KI', flag: '🇰🇮', capital: 'South Tarawa', continent: 'oceania', region: 'Micronesia', population: '131K', currency: 'AUD' },
  { id: 'kuwait', name: 'Kuwait', code: 'KW', flag: '🇰🇼', capital: 'Kuwait City', continent: 'asia', region: 'Middle East', population: '4.3M', currency: 'KWD' },
  { id: 'kyrgyzstan', name: 'Kyrgyzstan', code: 'KG', flag: '🇰🇬', capital: 'Bishkek', continent: 'asia', region: 'Central Asia', population: '6.9M', currency: 'KGS' },
  { id: 'laos', name: 'Laos', code: 'LA', flag: '🇱🇦', capital: 'Vientiane', continent: 'asia', region: 'Southeast Asia', population: '7.5M', currency: 'LAK' },
  { id: 'latvia', name: 'Latvia', code: 'LV', flag: '🇱🇻', capital: 'Riga', continent: 'europe', region: 'Northern Europe', population: '1.88M', currency: 'EUR' },
  { id: 'lebanon', name: 'Lebanon', code: 'LB', flag: '🇱🇧', capital: 'Beirut', continent: 'asia', region: 'Middle East', population: '5.5M', currency: 'LBP' },
  { id: 'lesotho', name: 'Lesotho', code: 'LS', flag: '🇱🇸', capital: 'Maseru', continent: 'africa', region: 'Southern Africa', population: '2.3M', currency: 'LSL' },
  { id: 'liberia', name: 'Liberia', code: 'LR', flag: '🇱🇷', capital: 'Monrovia', continent: 'africa', region: 'West Africa', population: '5.4M', currency: 'LRD' },
  { id: 'libya', name: 'Libya', code: 'LY', flag: '🇱🇾', capital: 'Tripoli', continent: 'africa', region: 'North Africa', population: '6.9M', currency: 'LYD' },
  { id: 'liechtenstein', name: 'Liechtenstein', code: 'LI', flag: '🇱🇮', capital: 'Vaduz', continent: 'europe', region: 'Western Europe', population: '39K', currency: 'CHF' },
  { id: 'lithuania', name: 'Lithuania', code: 'LT', flag: '🇱🇹', capital: 'Vilnius', continent: 'europe', region: 'Northern Europe', population: '2.8M', currency: 'EUR' },
  { id: 'luxembourg', name: 'Luxembourg', code: 'LU', flag: '🇱🇺', capital: 'Luxembourg City', continent: 'europe', region: 'Western Europe', population: '660K', currency: 'EUR' },
  { id: 'madagascar', name: 'Madagascar', code: 'MG', flag: '🇲🇬', capital: 'Antananarivo', continent: 'africa', region: 'Eastern Africa', population: '29.6M', currency: 'MGA' },
  { id: 'malawi', name: 'Malawi', code: 'MW', flag: '🇲🇼', capital: 'Lilongwe', continent: 'africa', region: 'Eastern Africa', population: '20.4M', currency: 'MWK' },
  { id: 'malaysia', name: 'Malaysia', code: 'MY', flag: '🇲🇾', capital: 'Kuala Lumpur', continent: 'asia', region: 'Southeast Asia', population: '34.3M', currency: 'MYR' },
  { id: 'maldives', name: 'Maldives', code: 'MV', flag: '🇲🇻', capital: 'Malé', continent: 'asia', region: 'South Asia', population: '521K', currency: 'MVR' },
  { id: 'mali', name: 'Mali', code: 'ML', flag: '🇲🇱', capital: 'Bamako', continent: 'africa', region: 'West Africa', population: '22.6M', currency: 'XOF' },
  { id: 'malta', name: 'Malta', code: 'MT', flag: '🇲🇹', capital: 'Valletta', continent: 'europe', region: 'Southern Europe', population: '533K', currency: 'EUR' },
  { id: 'marshall-islands', name: 'Marshall Islands', code: 'MH', flag: '🇲🇭', capital: 'Majuro', continent: 'oceania', region: 'Micronesia', population: '42K', currency: 'USD' },
  { id: 'mauritania', name: 'Mauritania', code: 'MR', flag: '🇲🇷', capital: 'Nouakchott', continent: 'africa', region: 'West Africa', population: '4.7M', currency: 'MRU' },
  { id: 'mauritius', name: 'Mauritius', code: 'MU', flag: '🇲🇺', capital: 'Port Louis', continent: 'africa', region: 'Eastern Africa', population: '1.26M', currency: 'MUR' },
  { id: 'mexico', name: 'Mexico', code: 'MX', flag: '🇲🇽', capital: 'Mexico City', continent: 'north-america', region: 'Central America', population: '128.5M', currency: 'MXN' },
  { id: 'micronesia', name: 'Micronesia', code: 'FM', flag: '🇫🇲', capital: 'Palikir', continent: 'oceania', region: 'Micronesia', population: '114K', currency: 'USD' },
  { id: 'moldova', name: 'Moldova', code: 'MD', flag: '🇲🇩', capital: 'Chisinau', continent: 'europe', region: 'Eastern Europe', population: '2.5M', currency: 'MDL' },
  { id: 'monaco', name: 'Monaco', code: 'MC', flag: '🇲🇨', capital: 'Monaco', continent: 'europe', region: 'Western Europe', population: '39K', currency: 'EUR' },
  { id: 'mongolia', name: 'Mongolia', code: 'MN', flag: '🇲🇳', capital: 'Ulaanbaatar', continent: 'asia', region: 'Eastern Asia', population: '3.4M', currency: 'MNT' },
  { id: 'montenegro', name: 'Montenegro', code: 'ME', flag: '🇲🇪', capital: 'Podgorica', continent: 'europe', region: 'Southern Europe', population: '620K', currency: 'EUR' },
  { id: 'morocco', name: 'Morocco', code: 'MA', flag: '🇲🇦', capital: 'Rabat', continent: 'africa', region: 'North Africa', population: '37.8M', currency: 'MAD' },
  { id: 'mozambique', name: 'Mozambique', code: 'MZ', flag: '🇲🇿', capital: 'Maputo', continent: 'africa', region: 'Eastern Africa', population: '33.9M', currency: 'MZN' },
  { id: 'myanmar', name: 'Myanmar', code: 'MM', flag: '🇲🇲', capital: 'Naypyidaw', continent: 'asia', region: 'Southeast Asia', population: '54.2M', currency: 'MMK' },
  { id: 'namibia', name: 'Namibia', code: 'NA', flag: '🇳🇦', capital: 'Windhoek', continent: 'africa', region: 'Southern Africa', population: '2.6M', currency: 'NAD' },
  { id: 'nauru', name: 'Nauru', code: 'NR', flag: '🇳🇷', capital: 'Yaren (de facto)', continent: 'oceania', region: 'Micronesia', population: '12K', currency: 'AUD' },
  { id: 'nepal', name: 'Nepal', code: 'NP', flag: '🇳🇵', capital: 'Kathmandu', continent: 'asia', region: 'South Asia', population: '30.5M', currency: 'NPR' },
  { id: 'netherlands', name: 'Netherlands', code: 'NL', flag: '🇳🇱', capital: 'Amsterdam', continent: 'europe', region: 'Western Europe', population: '17.9M', currency: 'EUR' },
  { id: 'new-zealand', name: 'New Zealand', code: 'NZ', flag: '🇳🇿', capital: 'Wellington', continent: 'oceania', region: 'Australia & NZ', population: '5.2M', currency: 'NZD' },
  { id: 'nicaragua', name: 'Nicaragua', code: 'NI', flag: '🇳🇮', capital: 'Managua', continent: 'north-america', region: 'Central America', population: '7M', currency: 'NIO' },
  { id: 'niger', name: 'Niger', code: 'NE', flag: '🇳🇪', capital: 'Niamey', continent: 'africa', region: 'West Africa', population: '26.2M', currency: 'XOF' },
  { id: 'nigeria', name: 'Nigeria', code: 'NG', flag: '🇳🇬', capital: 'Abuja', continent: 'africa', region: 'West Africa', population: '223.8M', currency: 'NGN' },
  { id: 'north-korea', name: 'North Korea', code: 'KP', flag: '🇰🇵', capital: 'Pyongyang', continent: 'asia', region: 'Eastern Asia', population: '26M', currency: 'KPW' },
  { id: 'north-macedonia', name: 'North Macedonia', code: 'MK', flag: '🇲🇰', capital: 'Skopje', continent: 'europe', region: 'Southern Europe', population: '2M', currency: 'MKD' },
  { id: 'norway', name: 'Norway', code: 'NO', flag: '🇳🇴', capital: 'Oslo', continent: 'europe', region: 'Northern Europe', population: '5.5M', currency: 'NOK' },
  { id: 'oman', name: 'Oman', code: 'OM', flag: '🇴🇲', capital: 'Muscat', continent: 'asia', region: 'Middle East', population: '4.6M', currency: 'OMR' },
  { id: 'pakistan', name: 'Pakistan', code: 'PK', flag: '🇵🇰', capital: 'Islamabad', continent: 'asia', region: 'South Asia', population: '240.5M', currency: 'PKR' },
  { id: 'palau', name: 'Palau', code: 'PW', flag: '🇵🇼', capital: 'Ngerulmud', continent: 'oceania', region: 'Micronesia', population: '18K', currency: 'USD' },
  { id: 'palestine', name: 'Palestine', code: 'PS', flag: '🇵🇸', capital: 'Ramallah / East Jerusalem', continent: 'asia', region: 'Middle East', population: '5.4M', currency: 'ILS' },
  { id: 'panama', name: 'Panama', code: 'PA', flag: '🇵🇦', capital: 'Panama City', continent: 'north-america', region: 'Central America', population: '4.4M', currency: 'PAB / USD' },
  { id: 'papua-new-guinea', name: 'Papua New Guinea', code: 'PG', flag: '🇵🇬', capital: 'Port Moresby', continent: 'oceania', region: 'Melanesia', population: '10.1M', currency: 'PGK' },
  { id: 'paraguay', name: 'Paraguay', code: 'PY', flag: '🇵🇾', capital: 'Asunción', continent: 'south-america', region: 'South America', population: '6.8M', currency: 'PYG' },
  { id: 'peru', name: 'Peru', code: 'PE', flag: '🇵🇪', capital: 'Lima', continent: 'south-america', region: 'South America', population: '34M', currency: 'PEN' },
  { id: 'philippines', name: 'Philippines', code: 'PH', flag: '🇵🇭', capital: 'Manila', continent: 'asia', region: 'Southeast Asia', population: '117.3M', currency: 'PHP' },
  { id: 'poland', name: 'Poland', code: 'PL', flag: '🇵🇱', capital: 'Warsaw', continent: 'europe', region: 'Central Europe', population: '37.8M', currency: 'PLN' },
  { id: 'portugal', name: 'Portugal', code: 'PT', flag: '🇵🇹', capital: 'Lisbon', continent: 'europe', region: 'Southern Europe', population: '10.4M', currency: 'EUR' },
  { id: 'qatar', name: 'Qatar', code: 'QA', flag: '🇶🇦', capital: 'Doha', continent: 'asia', region: 'Middle East', population: '2.7M', currency: 'QAR' },
  { id: 'romania', name: 'Romania', code: 'RO', flag: '🇷🇴', capital: 'Bucharest', continent: 'europe', region: 'Eastern Europe', population: '19M', currency: 'RON' },
  { id: 'russia', name: 'Russia', code: 'RU', flag: '🇷🇺', capital: 'Moscow', continent: 'europe', region: 'Eastern Europe / North Asia', population: '144.2M', currency: 'RUB' },
  { id: 'rwanda', name: 'Rwanda', code: 'RW', flag: '🇷🇼', capital: 'Kigali', continent: 'africa', region: 'Eastern Africa', population: '13.8M', currency: 'RWF' },
  { id: 'saint-kitts-and-nevis', name: 'Saint Kitts and Nevis', code: 'KN', flag: '🇰🇳', capital: 'Basseterre', continent: 'north-america', region: 'Caribbean', population: '48K', currency: 'XCD' },
  { id: 'saint-lucia', name: 'Saint Lucia', code: 'LC', flag: '🇱🇨', capital: 'Castries', continent: 'north-america', region: 'Caribbean', population: '180K', currency: 'XCD' },
  { id: 'saint-vincent', name: 'Saint Vincent & Grenadines', code: 'VC', flag: '🇻🇨', capital: 'Kingstown', continent: 'north-america', region: 'Caribbean', population: '104K', currency: 'XCD' },
  { id: 'samoa', name: 'Samoa', code: 'WS', flag: '🇼🇸', capital: 'Apia', continent: 'oceania', region: 'Polynesia', population: '222K', currency: 'WST' },
  { id: 'san-marino', name: 'San Marino', code: 'SM', flag: '🇸🇲', capital: 'San Marino', continent: 'europe', region: 'Southern Europe', population: '34K', currency: 'EUR' },
  { id: 'sao-tome-and-principe', name: 'Sao Tome and Principe', code: 'ST', flag: '🇸🇹', capital: 'São Tomé', continent: 'africa', region: 'Middle Africa', population: '227K', currency: 'STN' },
  { id: 'saudi-arabia', name: 'Saudi Arabia', code: 'SA', flag: '🇸🇦', capital: 'Riyadh', continent: 'asia', region: 'Middle East', population: '36.4M', currency: 'SAR' },
  { id: 'senegal', name: 'Senegal', code: 'SN', flag: '🇸🇳', capital: 'Dakar', continent: 'africa', region: 'West Africa', population: '17.3M', currency: 'XOF' },
  { id: 'serbia', name: 'Serbia', code: 'RS', flag: '🇷🇸', capital: 'Belgrade', continent: 'europe', region: 'Southern Europe', population: '6.6M', currency: 'RSD' },
  { id: 'seychelles', name: 'Seychelles', code: 'SC', flag: '🇸🇨', capital: 'Victoria', continent: 'africa', region: 'Eastern Africa', population: '100K', currency: 'SCR' },
  { id: 'sierra-leone', name: 'Sierra Leone', code: 'SL', flag: '🇸🇱', capital: 'Freetown', continent: 'africa', region: 'West Africa', population: '8.6M', currency: 'SLE' },
  { id: 'singapore', name: 'Singapore', code: 'SG', flag: '🇸🇬', capital: 'Singapore', continent: 'asia', region: 'Southeast Asia', population: '5.9M', currency: 'SGD' },
  { id: 'slovakia', name: 'Slovakia', code: 'SK', flag: '🇸🇰', capital: 'Bratislava', continent: 'europe', region: 'Central Europe', population: '5.4M', currency: 'EUR' },
  { id: 'slovenia', name: 'Slovenia', code: 'SI', flag: '🇸🇮', capital: 'Ljubljana', continent: 'europe', region: 'Southern Europe', population: '2.1M', currency: 'EUR' },
  { id: 'solomon-islands', name: 'Solomon Islands', code: 'SB', flag: '🇸🇧', capital: 'Honiara', continent: 'oceania', region: 'Melanesia', population: '724K', currency: 'SBD' },
  { id: 'somalia', name: 'Somalia', code: 'SO', flag: '🇸🇴', capital: 'Mogadishu', continent: 'africa', region: 'Eastern Africa', population: '17.6M', currency: 'SOS' },
  { id: 'south-africa', name: 'South Africa', code: 'ZA', flag: '🇿🇦', capital: 'Pretoria / Cape Town', continent: 'africa', region: 'Southern Africa', population: '60.4M', currency: 'ZAR' },
  { id: 'south-korea', name: 'South Korea', code: 'KR', flag: '🇰🇷', capital: 'Seoul', continent: 'asia', region: 'Eastern Asia', population: '51.7M', currency: 'KRW' },
  { id: 'south-sudan', name: 'South Sudan', code: 'SS', flag: '🇸🇸', capital: 'Juba', continent: 'africa', region: 'Eastern Africa', population: '11M', currency: 'SSP' },
  { id: 'spain', name: 'Spain', code: 'ES', flag: '🇪🇸', capital: 'Madrid', continent: 'europe', region: 'Southern Europe', population: '48.3M', currency: 'EUR' },
  { id: 'sri-lanka', name: 'Sri Lanka', code: 'LK', flag: '🇱🇰', capital: 'Sri Jayawardenepura Kotte / Colombo', continent: 'asia', region: 'South Asia', population: '22.2M', currency: 'LKR' },
  { id: 'sudan', name: 'Sudan', code: 'SD', flag: '🇸🇩', capital: 'Khartoum', continent: 'africa', region: 'North Africa', population: '46.9M', currency: 'SDG' },
  { id: 'suriname', name: 'Suriname', code: 'SR', flag: '🇸🇷', capital: 'Paramaribo', continent: 'south-america', region: 'South America', population: '618K', currency: 'SRD' },
  { id: 'sweden', name: 'Sweden', code: 'SE', flag: '🇸🇪', capital: 'Stockholm', continent: 'europe', region: 'Northern Europe', population: '10.5M', currency: 'SEK' },
  { id: 'switzerland', name: 'Switzerland', code: 'CH', flag: '🇨🇭', capital: 'Bern', continent: 'europe', region: 'Western Europe', population: '8.8M', currency: 'CHF' },
  { id: 'syria', name: 'Syria', code: 'SY', flag: '🇸🇾', capital: 'Damascus', continent: 'asia', region: 'Middle East', population: '22.1M', currency: 'SYP' },
  { id: 'taiwan', name: 'Taiwan', code: 'TW', flag: '🇹🇼', capital: 'Taipei', continent: 'asia', region: 'Eastern Asia', population: '23.4M', currency: 'TWD' },
  { id: 'tajikistan', name: 'Tajikistan', code: 'TJ', flag: '🇹🇯', capital: 'Dushanbe', continent: 'asia', region: 'Central Asia', population: '10.1M', currency: 'TJS' },
  { id: 'tanzania', name: 'Tanzania', code: 'TZ', flag: '🇹🇿', capital: 'Dodoma / Dar es Salaam', continent: 'africa', region: 'Eastern Africa', population: '65.5M', currency: 'TZS' },
  { id: 'thailand', name: 'Thailand', code: 'TH', flag: '🇹🇭', capital: 'Bangkok', continent: 'asia', region: 'Southeast Asia', population: '71.8M', currency: 'THB' },
  { id: 'timor-leste', name: 'Timor-Leste', code: 'TL', flag: '🇹🇱', capital: 'Dili', continent: 'asia', region: 'Southeast Asia', population: '1.34M', currency: 'USD' },
  { id: 'togo', name: 'Togo', code: 'TG', flag: '🇹🇬', capital: 'Lomé', continent: 'africa', region: 'West Africa', population: '8.8M', currency: 'XOF' },
  { id: 'tonga', name: 'Tonga', code: 'TO', flag: '🇹🇴', capital: "Nuku'alofa", continent: 'oceania', region: 'Polynesia', population: '107K', currency: 'TOP' },
  { id: 'trinidad-and-tobago', name: 'Trinidad and Tobago', code: 'TT', flag: '🇹🇹', capital: 'Port of Spain', continent: 'north-america', region: 'Caribbean', population: '1.5M', currency: 'TTD' },
  { id: 'tunisia', name: 'Tunisia', code: 'TN', flag: '🇹🇳', capital: 'Tunis', continent: 'africa', region: 'North Africa', population: '12.4M', currency: 'TND' },
  { id: 'turkey', name: 'Turkey (Türkiye)', code: 'TR', flag: '🇹🇷', capital: 'Ankara', continent: 'europe', region: 'Southern Europe / Western Asia', population: '85.3M', currency: 'TRY' },
  { id: 'turkmenistan', name: 'Turkmenistan', code: 'TM', flag: '🇹🇲', capital: 'Ashgabat', continent: 'asia', region: 'Central Asia', population: '6.4M', currency: 'TMT' },
  { id: 'tuvalu', name: 'Tuvalu', code: 'TV', flag: '🇹🇻', capital: 'Funafuti', continent: 'oceania', region: 'Polynesia', population: '11K', currency: 'AUD' },
  { id: 'uganda', name: 'Uganda', code: 'UG', flag: '🇺🇬', capital: 'Kampala', continent: 'africa', region: 'Eastern Africa', population: '47.2M', currency: 'UGX' },
  { id: 'ukraine', name: 'Ukraine', code: 'UA', flag: '🇺🇦', capital: 'Kyiv', continent: 'europe', region: 'Eastern Europe', population: '38M', currency: 'UAH' },
  { id: 'united-arab-emirates', name: 'United Arab Emirates', code: 'AE', flag: '🇦🇪', capital: 'Abu Dhabi', continent: 'asia', region: 'Middle East', population: '9.4M', currency: 'AED' },
  { id: 'united-kingdom', name: 'United Kingdom', code: 'GB', flag: '🇬🇧', capital: 'London', continent: 'europe', region: 'Northern Europe', population: '67.7M', currency: 'GBP' },
  { id: 'united-states', name: 'United States', code: 'US', flag: '🇺🇸', capital: 'Washington, D.C.', continent: 'north-america', region: 'Northern America', population: '335M', currency: 'USD' },
  { id: 'uruguay', name: 'Uruguay', code: 'UY', flag: '🇺🇾', capital: 'Montevideo', continent: 'south-america', region: 'South America', population: '3.4M', currency: 'UYU' },
  { id: 'uzbekistan', name: 'Uzbekistan', code: 'UZ', flag: '🇺🇿', capital: 'Tashkent', continent: 'asia', region: 'Central Asia', population: '35.6M', currency: 'UZS' },
  { id: 'vanuatu', name: 'Vanuatu', code: 'VU', flag: '🇻🇺', capital: 'Port Vila', continent: 'oceania', region: 'Melanesia', population: '326K', currency: 'VUV' },
  { id: 'vatican-city', name: 'Vatican City', code: 'VA', flag: '🇻🇦', capital: 'Vatican City', continent: 'europe', region: 'Southern Europe', population: '800', currency: 'EUR' },
  { id: 'venezuela', name: 'Venezuela', code: 'VE', flag: '🇻🇪', capital: 'Caracas', continent: 'south-america', region: 'South America', population: '28.8M', currency: 'VES' },
  { id: 'vietnam', name: 'Vietnam', code: 'VN', flag: '🇻🇳', capital: 'Hanoi', continent: 'asia', region: 'Southeast Asia', population: '98.8M', currency: 'VND' },
  { id: 'yemen', name: 'Yemen', code: 'YE', flag: '🇾🇪', capital: "Sana'a", continent: 'asia', region: 'Middle East', population: '33.7M', currency: 'YER' },
  { id: 'zambia', name: 'Zambia', code: 'ZM', flag: '🇿🇲', capital: 'Lusaka', continent: 'africa', region: 'Eastern Africa', population: '20M', currency: 'ZMW' },
  { id: 'zimbabwe', name: 'Zimbabwe', code: 'ZW', flag: '🇿🇼', capital: 'Harare', continent: 'africa', region: 'Eastern Africa', population: '16.3M', currency: 'ZWL' }
];

// Deep Dive Featured Profiles for Top Tourist Nations
export const DETAILED_COUNTRIES: CountryFact[] = [
  {
    id: 'india',
    name: 'India',
    code: 'IN',
    flag: '🇮🇳',
    capital: 'New Delhi',
    continent: 'asia',
    region: 'South Asia',
    subregion: 'Indian Subcontinent',
    population: '1.43 Billion',
    area: '3,287,263 km²',
    languages: ['Hindi', 'English', 'Bengali', 'Tamil', 'Telugu', '22 Official Languages'],
    currency: {
      name: 'Indian Rupee',
      code: 'INR',
      symbol: '₹',
      rateToUSD: 86.5
    },
    timeZone: 'UTC+05:30 (IST)',
    callingCode: '+91',
    drivingSide: 'Left',
    government: 'Federal Parliamentary Democratic Republic',
    nationalSymbols: {
      animal: 'Bengal Tiger (Panthera tigris)',
      flower: 'Lotus (Nelumbo nucifera)',
      bird: 'Indian Peacock (Pavo cristatus)',
      motto: 'Satyameva Jayate ("Truth Alone Triumphs")'
    },
    heroImage: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506461883276-594a12b11cf3?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'India is a breathtaking subcontinent of ancient spirituality, majestic royal palaces, snow-capped Himalayan ridges, golden Thar deserts, vibrant regional festivals, and unparalleled culinary diversity.',
    interestingFacts: [
      'India is the birthplace of four major world religions: Hinduism, Buddhism, Jainism, and Sikhism.',
      'Kumbh Mela is the largest human gathering on Earth, visible from space.',
      'Varanasi is one of the oldest continuously inhabited cities in human history (~3,000+ years).',
      'The Indian Railway network employs over 1.3 million people and carries 23 million passengers daily.',
      'Meghalaya state houses Mawsynram, the wettest place on planet Earth.'
    ],
    popularCities: ['Kolkata', 'New Delhi', 'Mumbai', 'Jaipur', 'Varanasi', 'Bengaluru', 'Kochi', 'Agra'],
    topLandmarks: ['Taj Mahal', 'Varanasi Ghats', 'Hawa Mahal', 'Victoria Memorial', 'Qutub Minar', 'Kerala Backwaters'],
    famousFoods: ['Biryani', 'Butter Chicken', 'Masala Dosa', 'Roshogolla & Sandesh', 'Pani Puri', 'Dal Makhani', 'Chai'],
    bestTimeToVisit: {
      peakSeason: 'October to March (Pleasant, sunny winters across golden triangle & South)',
      shoulderSeason: 'April & September (Great for Himalayan trekking in Ladakh & Himachal)',
      lowSeason: 'May to August (Hot summers & lush monsoon season)',
      summary: 'Winter (Nov-Feb) offers ideal temperatures for Rajasthan, Delhi, Kerala, and golden sands.'
    },
    visaSummary: {
      difficulty: 'Easy eVisa',
      note: 'Over 160 countries are eligible for 30-day, 1-year, or 5-year online Indian e-Visas.',
      officialPortalUrl: 'https://indianvisaonline.gov.in'
    },
    budgetTier: 'Budget ($)',
    averageDailyCostUSD: {
      budget: 25,
      midRange: 60,
      luxury: 180
    },
    safetyScore: 8.2,
    plugTypes: ['Type C', 'Type D', 'Type M'],
    isFeatured: true
  },
  {
    id: 'japan',
    name: 'Japan',
    code: 'JP',
    flag: '🇯🇵',
    capital: 'Tokyo',
    continent: 'asia',
    region: 'Eastern Asia',
    subregion: 'Japanese Archipelago',
    population: '124.5 Million',
    area: '377,975 km²',
    languages: ['Japanese'],
    currency: {
      name: 'Japanese Yen',
      code: 'JPY',
      symbol: '¥',
      rateToUSD: 154
    },
    timeZone: 'UTC+09:00 (JST)',
    callingCode: '+81',
    drivingSide: 'Left',
    government: 'Unitary Parliamentary Constitutional Monarchy',
    nationalSymbols: {
      animal: 'Green Pheasant / Japanese Macaque',
      flower: 'Cherry Blossom (Sakura) & Chrysanthemum',
      bird: 'Green Pheasant (Kiji)',
      motto: 'Peace and Harmony'
    },
    heroImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1528164344705-475426879c0d?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1492571350019-22de08371fd3?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'Japan is a hyper-futuristic yet deeply traditional island nation where neon-lit skyscraper districts coexist harmoniously with millennium-old Zen temples, sacred onsens, and bamboo groves.',
    interestingFacts: [
      'Japan consists of 6,852 islands, with Honshu, Hokkaido, Kyushu, and Shikoku being the largest four.',
      'Tokyo’s Shinjuku Station is the busiest train station in the world, handling 3.5M travelers daily.',
      'There is roughly 1 vending machine for every 23 people in Japan.',
      'Mount Fuji is an active volcano with its last eruption recorded in 1707.',
      'Over 68% of Japan’s territory is covered by dense mountain forests.'
    ],
    popularCities: ['Tokyo', 'Kyoto', 'Osaka', 'Sapporo', 'Hiroshima', 'Nara', 'Fukuoka'],
    topLandmarks: ['Mount Fuji', 'Fushimi Inari Shrine', 'Kinkaku-ji (Golden Pavilion)', 'Tokyo Skytree', 'Arashiyama Bamboo Grove'],
    famousFoods: ['Sushi & Sashimi', 'Ramen', 'Tempura', 'Wagyu Beef', 'Takoyaki', 'Matcha Sweets'],
    bestTimeToVisit: {
      peakSeason: 'March to May (Cherry Blossom Season) & Oct to Nov (Autumn foliage)',
      shoulderSeason: 'June & September (Warm, occasional rain)',
      lowSeason: 'January to February (Peak for Hokkaido powder skiing)',
      summary: 'Spring (Sakura) and Autumn (Koyo) offer the most picturesque conditions across the country.'
    },
    visaSummary: {
      difficulty: 'Visa-Free / VoA',
      note: 'Passport holders from 70+ countries enjoy visa-free entry for tourism up to 90 days.',
      officialPortalUrl: 'https://www.mofa.go.jp'
    },
    budgetTier: 'Moderate ($$)',
    averageDailyCostUSD: {
      budget: 55,
      midRange: 140,
      luxury: 360
    },
    safetyScore: 9.8,
    plugTypes: ['Type A', 'Type B'],
    isFeatured: true
  },
  {
    id: 'france',
    name: 'France',
    code: 'FR',
    flag: '🇫🇷',
    capital: 'Paris',
    continent: 'europe',
    region: 'Western Europe',
    subregion: 'Western Europe',
    population: '68 Million',
    area: '643,801 km²',
    languages: ['French'],
    currency: {
      name: 'Euro',
      code: 'EUR',
      symbol: '€',
      rateToUSD: 0.94
    },
    timeZone: 'UTC+01:00 (CET) / UTC+02:00 (CEST)',
    callingCode: '+33',
    drivingSide: 'Right',
    government: 'Semi-Presidential Republic',
    nationalSymbols: {
      animal: 'Gallic Rooster',
      flower: 'Iris / Fleur-de-lis',
      bird: 'Gallic Rooster',
      motto: 'Liberté, Égalité, Fraternité'
    },
    heroImage: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'The most visited country in the world, France enchants travelers with iconic Parisian boulevards, world-class art collections, fairy-tale Loire Valley châteaux, lavender-scented Provence, and French Riviera glamour.',
    interestingFacts: [
      'The Louvre in Paris is the world\'s largest art museum; seeing every piece for 30 seconds takes 100 days.',
      'France produces over 1,500 distinct registered cheese varieties.',
      'France spans 12 different time zones when including its overseas departments and territories.',
      'The Eiffel Tower was originally intended as a temporary 20-year installation for the 1889 World’s Fair.'
    ],
    popularCities: ['Paris', 'Nice', 'Lyon', 'Marseille', 'Bordeaux', 'Strasbourg', 'Toulouse'],
    topLandmarks: ['Eiffel Tower', 'Louvre Museum', 'Mont Saint-Michel', 'Palace of Versailles', 'French Riviera (Côte d\'Azur)'],
    famousFoods: ['Croissants & Baguettes', 'Coq au Vin', 'Boeuf Bourguignon', 'Crème Brûlée', 'Macarons', 'Bordeaux Wines'],
    bestTimeToVisit: {
      peakSeason: 'June to August (Warm sunny summer on Riviera & Paris)',
      shoulderSeason: 'April to May & September to October (Mild weather, harvest festivals)',
      lowSeason: 'November to February (Great for Alps skiing & festive Christmas markets)',
      summary: 'Spring (April-May) and early Autumn (Sept-Oct) offer comfortable weather with fewer crowds.'
    },
    visaSummary: {
      difficulty: 'Visa-Free / VoA',
      note: 'Part of Schengen Area. EU/US/UK/CAN passport holders enter visa-free for 90/180 days.',
      officialPortalUrl: 'https://france-visas.gouv.fr'
    },
    budgetTier: 'Upper-Mid ($$$)',
    averageDailyCostUSD: {
      budget: 70,
      midRange: 160,
      luxury: 400
    },
    safetyScore: 8.9,
    plugTypes: ['Type C', 'Type E'],
    isFeatured: true
  },
  {
    id: 'italy',
    name: 'Italy',
    code: 'IT',
    flag: '🇮🇹',
    capital: 'Rome',
    continent: 'europe',
    region: 'Southern Europe',
    subregion: 'Apennine Peninsula',
    population: '58.8 Million',
    area: '301,340 km²',
    languages: ['Italian'],
    currency: {
      name: 'Euro',
      code: 'EUR',
      symbol: '€',
      rateToUSD: 0.94
    },
    timeZone: 'UTC+01:00 (CET) / UTC+02:00 (CEST)',
    callingCode: '+39',
    drivingSide: 'Right',
    government: 'Unitary Parliamentary Republic',
    nationalSymbols: {
      animal: 'Italian Wolf',
      flower: 'White Lily / Stella Alpina',
      bird: 'Italian Sparrow',
      motto: 'L\'Italia è una Repubblica democratica, fondata sul lavoro'
    },
    heroImage: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1520175480921-4edfa2983e0f?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'Italy boasts the world’s highest number of UNESCO World Heritage Sites, from the Roman Colosseum and Renaissance Florence to the romantic canals of Venice, Amalfi cliffs, and culinary perfection in Tuscany.',
    interestingFacts: [
      'Italy has 59 UNESCO World Heritage Sites, the most of any country on Earth.',
      'San Marino and Vatican City are two sovereign microstates completely enclosed within Italy.',
      'Over 500 varieties of pasta shapes are produced across different Italian regions.',
      'Mount Etna in Sicily is Europe\'s highest and most active volcano.'
    ],
    popularCities: ['Rome', 'Florence', 'Venice', 'Milan', 'Naples', 'Bologna', 'Palermo'],
    topLandmarks: ['Colosseum & Roman Forum', 'Amalfi Coast', 'Venice Grand Canal', 'Florence Duomo', 'Leaning Tower of Pisa', 'Cinque Terre'],
    famousFoods: ['Neapolitan Pizza', 'Pasta Carbonara', 'Gelato', 'Tiramisu', 'Risotto alla Milanese', 'Espresso'],
    bestTimeToVisit: {
      peakSeason: 'June to August (Busy beach resorts, warm sun)',
      shoulderSeason: 'April to May & September to October (Ideal touring temperatures)',
      lowSeason: 'November to February (Fewer crowds in museums, Dolomite skiing)',
      summary: 'May and September provide the absolute best weather for sightseeing without extreme heat.'
    },
    visaSummary: {
      difficulty: 'Visa-Free / VoA',
      note: 'Schengen zone rules apply: 90 days visa-free for eligible passport holders.',
      officialPortalUrl: 'https://vistoperitalia.esteri.it'
    },
    budgetTier: 'Moderate ($$)',
    averageDailyCostUSD: {
      budget: 65,
      midRange: 150,
      luxury: 380
    },
    safetyScore: 8.8,
    plugTypes: ['Type C', 'Type F', 'Type L'],
    isFeatured: true
  },
  {
    id: 'brazil',
    name: 'Brazil',
    code: 'BR',
    flag: '🇧🇷',
    capital: 'Brasília',
    continent: 'south-america',
    region: 'South America',
    population: '216.4 Million',
    area: '8,515,767 km²',
    languages: ['Portuguese'],
    currency: {
      name: 'Brazilian Real',
      code: 'BRL',
      symbol: 'R$',
      rateToUSD: 5.8
    },
    timeZone: 'UTC−05:00 to UTC−02:00',
    callingCode: '+55',
    drivingSide: 'Right',
    government: 'Federal Presidential Republic',
    nationalSymbols: {
      animal: 'Jaguar (Onça-pintada)',
      flower: 'Corsage Orchid (Cattleya labiata)',
      bird: 'Rufous-bellied Thrush',
      motto: 'Ordem e Progresso ("Order and Progress")'
    },
    heroImage: 'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1516306580124-9b444097bc31?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'Brazil is a continent-sized paradise of samba rhythms, the roaring Iguazu Falls, Rio de Janeiro’s dramatic granite peaks, and the immense biodiversity of the Amazon basin.',
    interestingFacts: [
      'Brazil is the fifth-largest nation in the world by both area and population.',
      'The Amazon River produces roughly 20% of all river water entering the world\'s oceans.',
      'Brazil has been the world’s largest coffee exporter for over 150 consecutive years.'
    ],
    popularCities: ['Rio de Janeiro', 'São Paulo', 'Salvador', 'Brasília', 'Manaus', 'Florianópolis'],
    topLandmarks: ['Christ the Redeemer', 'Iguazu Falls (Foz do Iguaçu)', 'Sugarloaf Mountain', 'Amazon River & Pantanal'],
    famousFoods: ['Feijoada', 'Pão de Queijo', 'Churrasco BBQ', 'Açaí Bowl', 'Caipirinha'],
    bestTimeToVisit: {
      peakSeason: 'December to March (Summer & Rio Carnival)',
      shoulderSeason: 'April to May & September to November',
      lowSeason: 'June to August (Milder southern winter, dry season in Amazon)',
      summary: 'Visit in February/March for Carnival or July-October for Pantanal wildlife safaris.'
    },
    visaSummary: {
      difficulty: 'Easy eVisa',
      note: 'US, Canadian, and Australian citizens use simple eVisa; EU/UK citizens enjoy visa-free entry.',
      officialPortalUrl: 'https://www.gov.br'
    },
    budgetTier: 'Moderate ($$)',
    averageDailyCostUSD: {
      budget: 40,
      midRange: 95,
      luxury: 250
    },
    safetyScore: 7.5,
    plugTypes: ['Type C', 'Type N'],
    isFeatured: true
  },
  {
    id: 'australia',
    name: 'Australia',
    code: 'AU',
    flag: '🇦🇺',
    capital: 'Canberra',
    continent: 'oceania',
    region: 'Australia & NZ',
    population: '26.4 Million',
    area: '7,692,024 km²',
    languages: ['English'],
    currency: {
      name: 'Australian Dollar',
      code: 'AUD',
      symbol: 'A$',
      rateToUSD: 1.55
    },
    timeZone: 'UTC+08:00 to UTC+10:30',
    callingCode: '+61',
    drivingSide: 'Left',
    government: 'Federal Parliamentary Constitutional Monarchy',
    nationalSymbols: {
      animal: 'Red Kangaroo',
      flower: 'Golden Wattle',
      bird: 'Emu',
      motto: 'Advance Australia'
    },
    heroImage: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1523482580672-f109ba8cb9be?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'Australia is a land of vibrant coastal cities, the sacred red desert monolith of Uluru, unique marsupial wildlife, surf beaches, and the world’s largest coral reef.',
    interestingFacts: [
      'Australia is home to over 10,000 beaches; visiting a new one every day would take 27 years.',
      'Over 80% of Australia’s flora and fauna are unique to the continent and found nowhere else.',
      'The Great Barrier Reef is the only living structure visible from space.'
    ],
    popularCities: ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Cairns', 'Gold Coast'],
    topLandmarks: ['Sydney Opera House', 'Great Barrier Reef', 'Uluru-Kata Tjuta', 'Great Ocean Road & 12 Apostles'],
    famousFoods: ['Meat Pies', 'Vegemite on Toast', 'Barramundi', 'Lamingtons', 'Pavlova', 'Flat White Coffee'],
    bestTimeToVisit: {
      peakSeason: 'December to February (Southern Summer, sunny beaches)',
      shoulderSeason: 'September to November & March to May (Mild touring weather)',
      lowSeason: 'June to August (Winter in south, ideal dry season in tropical north/Reef)',
      summary: 'Visit the South in Dec-Feb and the Tropical North/Reef in May-October.'
    },
    visaSummary: {
      difficulty: 'Easy eVisa',
      note: 'Most tourists need an electronic Travel Authority (eTA / eVisitor Subclass 651/601).',
      officialPortalUrl: 'https://immi.homeaffairs.gov.au'
    },
    budgetTier: 'Upper-Mid ($$$)',
    averageDailyCostUSD: {
      budget: 75,
      midRange: 170,
      luxury: 420
    },
    safetyScore: 9.4,
    plugTypes: ['Type I'],
    isFeatured: true
  },
  {
    id: 'egypt',
    name: 'Egypt',
    code: 'EG',
    flag: '🇪🇬',
    capital: 'Cairo',
    continent: 'africa',
    region: 'North Africa',
    population: '110.9 Million',
    area: '1,002,450 km²',
    languages: ['Arabic'],
    currency: {
      name: 'Egyptian Pound',
      code: 'EGP',
      symbol: 'E£',
      rateToUSD: 50.5
    },
    timeZone: 'UTC+02:00 (EET) / UTC+03:00 (EEST)',
    callingCode: '+20',
    drivingSide: 'Right',
    government: 'Unitary Semi-Presidential Republic',
    nationalSymbols: {
      animal: 'Steppe Eagle',
      flower: 'Egyptian Lotus',
      bird: 'Steppe Eagle',
      motto: 'Beladi, Beladi, Beladi'
    },
    heroImage: 'https://images.unsplash.com/photo-1503177119275-0aa32b3a9368?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1539650116574-8efeb43e2750?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1568322445389-f64ac2515020?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'The cradle of 5,000 years of civilization, Egypt is home to the Pyramids of Giza, the tomb-lined Valley of the Kings in Luxor, serene Nile feluccas, and Red Sea coral reefs.',
    interestingFacts: [
      'The Great Pyramid of Giza was the tallest man-made structure on Earth for over 3,800 years.',
      'Ancient Egyptians invented one of the earliest calendars, 365 days divided into 12 months.',
      'The Nile River flows south to north, terminating in the fertile Mediterranean delta.'
    ],
    popularCities: ['Cairo', 'Luxor', 'Aswan', 'Alexandria', 'Hurghada', 'Sharm El Sheikh'],
    topLandmarks: ['Great Pyramids of Giza & Sphinx', 'Karnak & Luxor Temples', 'Abu Simbel', 'Valley of the Kings', 'Nile River Cruise'],
    famousFoods: ['Koshari', 'Ful Medames', 'Ta\'ameya (Egyptian Falafel)', 'Shawarma', 'Umm Ali'],
    bestTimeToVisit: {
      peakSeason: 'October to April (Cool, comfortable desert temperatures)',
      shoulderSeason: 'May & September',
      lowSeason: 'June to August (Extreme desert heat reaching 40°C+)',
      summary: 'Winter (Nov-Feb) is optimum for exploring Cairo and Luxor archaeological sites.'
    },
    visaSummary: {
      difficulty: 'Easy eVisa',
      note: 'Visa on Arrival or official eVisa available for over 74 nationalities for $25 USD.',
      officialPortalUrl: 'https://visa2egypt.gov.eg'
    },
    budgetTier: 'Budget ($)',
    averageDailyCostUSD: {
      budget: 30,
      midRange: 75,
      luxury: 210
    },
    safetyScore: 7.9,
    plugTypes: ['Type C', 'Type F'],
    isFeatured: true
  },
  {
    id: 'united-states',
    name: 'United States of America',
    code: 'US',
    flag: '🇺🇸',
    capital: 'Washington, D.C.',
    continent: 'north-america',
    region: 'Northern America',
    population: '335 Million',
    area: '9,833,520 km²',
    languages: ['English', 'Spanish'],
    currency: {
      name: 'US Dollar',
      code: 'USD',
      symbol: '$',
      rateToUSD: 1.0
    },
    timeZone: 'UTC−04:00 to UTC−10:00',
    callingCode: '+1',
    drivingSide: 'Right',
    government: 'Federal Presidential Constitutional Republic',
    nationalSymbols: {
      animal: 'American Bison',
      flower: 'Rose',
      bird: 'Bald Eagle',
      motto: 'In God We Trust / E Pluribus Unum'
    },
    heroImage: 'https://images.unsplash.com/photo-1485738422979-f5c462d49f74?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1474044159687-1ee9f3a51722?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506146332389-18140dc7b2fb?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'Spanning from the Atlantic to Pacific and Arctic Alaska to tropical Hawaii, the USA offers iconic national parks, legendary road trips like Route 66, global entertainment hubs, and skyline megacities.',
    interestingFacts: [
      'The US features 63 officially designated National Parks, including Yellowstone, the world’s first national park (1872).',
      'Lake Superior contains 10% of the world’s surface fresh water.'
    ],
    popularCities: ['New York City', 'Los Angeles', 'San Francisco', 'Las Vegas', 'Miami', 'Chicago', 'New Orleans'],
    topLandmarks: ['Statue of Liberty', 'Grand Canyon', 'Yellowstone National Park', 'Golden Gate Bridge', 'Times Square'],
    famousFoods: ['New York Pizza', 'Smoked Texas BBQ', 'Cheeseburgers', 'Clam Chowder', 'Key Lime Pie'],
    bestTimeToVisit: {
      peakSeason: 'June to August & Holidays (Summer vacations & national parks)',
      shoulderSeason: 'April to May & September to October (Pleasant weather throughout)',
      lowSeason: 'January to February (Cold winters except Florida/Hawaii)',
      summary: 'Spring and Autumn provide great road trip conditions across all coasts.'
    },
    visaSummary: {
      difficulty: 'Easy eVisa',
      note: 'ESTA available for 40+ Visa Waiver Program nations; standard B1/B2 visa for others.',
      officialPortalUrl: 'https://esta.cbp.dhs.gov'
    },
    budgetTier: 'Upper-Mid ($$$)',
    averageDailyCostUSD: {
      budget: 85,
      midRange: 190,
      luxury: 450
    },
    safetyScore: 8.4,
    plugTypes: ['Type A', 'Type B'],
    isFeatured: true
  },
  {
    id: 'switzerland',
    name: 'Switzerland',
    code: 'CH',
    flag: '🇨🇭',
    capital: 'Bern',
    continent: 'europe',
    region: 'Western Europe',
    population: '8.8 Million',
    area: '41,285 km²',
    languages: ['German', 'French', 'Italian', 'Romansh'],
    currency: {
      name: 'Swiss Franc',
      code: 'CHF',
      symbol: 'CHF',
      rateToUSD: 0.89
    },
    timeZone: 'UTC+01:00 (CET)',
    callingCode: '+41',
    drivingSide: 'Right',
    government: 'Federal Semi-Direct Democracy',
    nationalSymbols: {
      animal: 'St. Bernard / Cow',
      flower: 'Edelweiss',
      bird: 'Bearded Vulture',
      motto: 'Unus pro omnibus, omnes pro uno ("One for all, all for one")'
    },
    heroImage: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1527668752968-14dc70a27c95?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1502784444187-359ac186c5bb?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'Switzerland is a pristine alpine country world-famous for the soaring Matterhorn, crystal turquoise lakes, luxury watches, chocolates, and the world’s most scenic panoramic train rides.',
    interestingFacts: [
      'Switzerland has over 7,000 lakes and over 200 mountains exceeding 3,000 meters in height.',
      'Swiss trains operate with legendary 98%+ on-time punctuality.'
    ],
    popularCities: ['Zurich', 'Geneva', 'Lucerne', 'Interlaken', 'Zermatt', 'Basel'],
    topLandmarks: ['The Matterhorn', 'Jungfraujoch (Top of Europe)', 'Lake Geneva & Chillon Castle', 'Glacier Express Route'],
    famousFoods: ['Cheese Fondue', 'Raclette', 'Rösti', 'Swiss Chocolate', 'Zürcher Geschnetzeltes'],
    bestTimeToVisit: {
      peakSeason: 'July to August (Summer hiking) & Dec to March (Skiing)',
      shoulderSeason: 'May to June & September to October',
      lowSeason: 'April & November (Inter-season mountain closures)',
      summary: 'Summer for wildflowers and alpine trails, Winter for world-class skiing.'
    },
    visaSummary: {
      difficulty: 'Visa-Free / VoA',
      note: 'Part of Schengen Area. 90 days visa-free for eligible passport holders.',
      officialPortalUrl: 'https://www.sem.admin.ch'
    },
    budgetTier: 'Luxury ($$$$)',
    averageDailyCostUSD: {
      budget: 110,
      midRange: 240,
      luxury: 600
    },
    safetyScore: 9.9,
    plugTypes: ['Type J'],
    isFeatured: true
  },
  {
    id: 'thailand',
    name: 'Thailand',
    code: 'TH',
    flag: '🇹🇭',
    capital: 'Bangkok',
    continent: 'asia',
    region: 'Southeast Asia',
    population: '71.8 Million',
    area: '513,120 km²',
    languages: ['Thai'],
    currency: {
      name: 'Thai Baht',
      code: 'THB',
      symbol: '฿',
      rateToUSD: 34.2
    },
    timeZone: 'UTC+07:00 (ICT)',
    callingCode: '+66',
    drivingSide: 'Left',
    government: 'Constitutional Monarchy',
    nationalSymbols: {
      animal: 'Elephant (Chang Thai)',
      flower: 'Ratchaphruek (Golden Shower)',
      bird: 'Siamese Fireback',
      motto: 'Nation, Religion, King'
    },
    heroImage: 'https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506665531195-3566af2b4dfa?auto=format&fit=crop&w=800&q=80'
    ],
    overview: 'The "Land of Smiles", Thailand is a vibrant tapestry of gilded Buddhist temples, bustling night street food markets, emerald limestone islands in the Andaman Sea, and peaceful northern jungle hills.',
    interestingFacts: [
      'Thailand is the only Southeast Asian nation never colonized by European powers.',
      'Bangkok’s ceremonial name contains 168 letters, the longest place name in the world.'
    ],
    popularCities: ['Bangkok', 'Chiang Mai', 'Phuket', 'Pattaya', 'Krabi', 'Ayutthaya'],
    topLandmarks: ['Grand Palace & Wat Phra Kaew', 'Phi Phi Islands & Maya Bay', 'Wat Arun', 'Doi Inthanon National Park'],
    famousFoods: ['Pad Thai', 'Tom Yum Goong', 'Green Curry', 'Mango Sticky Rice', 'Som Tum (Papaya Salad)'],
    bestTimeToVisit: {
      peakSeason: 'November to February (Cool, dry and sunny season)',
      shoulderSeason: 'March to May (Hot season, Songkran Water Festival)',
      lowSeason: 'June to October (Monsoon rains, lush greenery, lower prices)',
      summary: 'November to February is the most popular time with clear skies and calm seas.'
    },
    visaSummary: {
      difficulty: 'Visa-Free / VoA',
      note: '93 countries enjoy 60-day visa exemption as of recent updates.',
      officialPortalUrl: 'https://www.thaievisa.go.th'
    },
    budgetTier: 'Budget ($)',
    averageDailyCostUSD: {
      budget: 30,
      midRange: 70,
      luxury: 200
    },
    safetyScore: 8.5,
    plugTypes: ['Type A', 'Type B', 'Type C', 'Type O'],
    isFeatured: true
  }
];
