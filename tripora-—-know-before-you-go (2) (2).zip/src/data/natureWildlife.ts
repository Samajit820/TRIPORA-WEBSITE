import { WildlifeItem } from '../types';

export const WILDLIFE_DATA: WildlifeItem[] = [
  {
    id: 'bengal-tiger',
    name: 'Royal Bengal Tiger',
    scientificName: 'Panthera tigris tigris',
    category: 'Endangered Species',
    primaryHabitats: ['Mangrove Forests', 'Tropical Moist Deciduous Forests', 'Alluvial Grasslands'],
    countriesFound: ['India', 'Bangladesh', 'Nepal', 'Bhutan'],
    conservationStatus: 'Endangered',
    bestPlacesToSpot: ['Sundarbans National Park (West Bengal/Bangladesh)', 'Ranthambore National Park (Rajasthan)', 'Bandhavgarh (Madhya Pradesh)', 'Jim Corbett National Park (Uttarakhand)'],
    interestingFacts: [
      'Bengal tigers are exceptional swimmers; in the Sundarbans, they frequently swim across 5 km wide tidal rivers.',
      'No two tigers have the exact same stripe pattern, functioning just like human fingerprints.'
    ],
    image: 'https://images.unsplash.com/photo-1561731216-c3a4d99437d5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'african-lion',
    name: 'African Lion',
    scientificName: 'Panthera leo',
    category: 'Mammals',
    primaryHabitats: ['Savannah Grasslands', 'Open Woodlands', 'Scrublands'],
    countriesFound: ['Tanzania', 'Kenya', 'South Africa', 'Botswana', 'Namibia', 'Zambia'],
    conservationStatus: 'Vulnerable',
    bestPlacesToSpot: ['Serengeti National Park (Tanzania)', 'Masai Mara National Reserve (Kenya)', 'Kruger National Park (South Africa)', 'Okavango Delta (Botswana)'],
    interestingFacts: [
      'A lion\'s roar can be heard up to 8 kilometers (5 miles) away across the savannah.',
      'Female lions (lionesses) perform roughly 85-90% of the hunting for the pride.'
    ],
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'giant-panda',
    name: 'Giant Panda',
    scientificName: 'Ailuropoda melanoleuca',
    category: 'Mammals',
    primaryHabitats: ['Montane Bamboo Forests'],
    countriesFound: ['China'],
    conservationStatus: 'Vulnerable',
    bestPlacesToSpot: ['Chengdu Giant Panda Breeding Research Base (Sichuan)', 'Wolong National Nature Reserve (Sichuan)', 'Dujiangyan Panda Base'],
    interestingFacts: [
      'An adult giant panda spends 12 to 16 hours a day eating up to 38 kilograms of bamboo.',
      'Pandas have an elongated wrist bone known as a "pseudo-thumb" to grip bamboo stalks.'
    ],
    image: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'humpback-whale',
    name: 'Humpback Whale',
    scientificName: 'Megaptera novaeangliae',
    category: 'Marine Life',
    primaryHabitats: ['Polar and Tropical Oceans'],
    countriesFound: ['Australia', 'Iceland', 'Norway', 'United States (Hawaii & Alaska)', 'Costa Rica', 'South Africa'],
    conservationStatus: 'Least Concern',
    bestPlacesToSpot: ['Hervey Bay & Sydney (Australia)', 'Húsavík (Iceland - Whale Capital of Europe)', 'Maui (Hawaii)', 'Hermanus (South Africa)'],
    interestingFacts: [
      'Male humpbacks compose complex songs that can last up to 20 minutes and travel hundreds of miles underwater.',
      'They undertake annual migrations of up to 16,000 kilometers from icy polar feeding grounds to warm tropical breeding lagoons.'
    ],
    image: 'https://images.unsplash.com/photo-1568430462989-44163eb1752f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'emperor-penguin',
    name: 'Emperor Penguin',
    scientificName: 'Aptenodytes forsteri',
    category: 'Birds',
    primaryHabitats: ['Antarctic Pack Ice & Southern Ocean'],
    countriesFound: ['Antarctica'],
    conservationStatus: 'Vulnerable',
    bestPlacesToSpot: ['Snow Hill Island (Weddell Sea)', 'Ross Sea Coast', 'Atka Bay (Queen Maud Land)'],
    interestingFacts: [
      'The tallest and heaviest of all penguin species, standing up to 122 cm (48 in) tall.',
      'Male emperors incubate a single egg on their feet under a brood pouch for over 65 freezing days without eating in temperatures as low as −60°C.'
    ],
    image: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?auto=format&fit=crop&w=800&q=80'
  }
];

export const BIOMES_SUMMARY = [
  {
    id: 'rainforest',
    title: 'Tropical Rainforests',
    coverage: '6% of Earth surface',
    biodiversity: 'Houses >50% of terrestrial plant and animal species',
    keyRegions: 'Amazon Basin (South America), Congo Basin (Africa), Southeast Asian Sundaland',
    icon: 'TreePine',
    image: 'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'savannah',
    title: 'Tropical Savannahs & Grasslands',
    coverage: '20% of Earth landmass',
    biodiversity: 'Greatest concentration of large grazing mammals and terrestrial predators',
    keyRegions: 'Serengeti & Masai Mara (East Africa), Pantanal (Brazil), Australian Bush',
    icon: 'Sun',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'coral-reefs',
    title: 'Coral Reef Systems',
    coverage: '<0.1% of ocean floor',
    biodiversity: 'Nurtures 25% of all marine life ("Rainforests of the Sea")',
    keyRegions: 'Great Barrier Reef (Australia), Coral Triangle (Indonesia/Philippines), Mesoamerican Reef (Belize)',
    icon: 'Waves',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'alpine',
    title: 'Alpine & High Mountain Biomes',
    coverage: '12% of land area',
    biodiversity: 'Specialized cold-hardy fauna: Snow Leopards, Ibex, Tibetan Antelopes, Vicuñas',
    keyRegions: 'Himalayas, Alps, Andes, Rocky Mountains',
    icon: 'Mountain',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80'
  }
];
